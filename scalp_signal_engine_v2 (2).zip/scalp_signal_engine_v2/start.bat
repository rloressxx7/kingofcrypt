@echo off
REM ============================================
REM  Scalp Signal Engine - Baslatic
REM ============================================

REM --- WALLET ---
REM Asagidaki satirlardan birini ac:

REM Yontem 1: Base58 Private Key (Phantom/Solflare export)
REM set SOLANA_PRIVATE_KEY=BURAYA_BASE58_PRIVATE_KEY_YAZ

REM Yontem 2: PumpAPI API Key (Lightning - en hizli)
REM set PUMPAPI_API_KEY=BURAYA_PUMPAPI_API_KEY_YAZ

REM --- TRADING MODE ---
REM Paper trading icin asagidaki satiri YORUM yap:
set LIVE_TRADING=true

REM --- OLLAMA ---
set OLLAMA_URL=http://127.0.0.1:11434
set OLLAMA_MODEL=local-jev

REM --- RISK LIMITS ---
set MAX_POSITION_SOL=0.001
set MAX_DAILY_LOSS_SOL=0.5
set MAX_OPEN_POSITIONS=1
set DEFAULT_POSITION_SOL=0.001
set PRIORITY_FEE_SOL=0.000005

REM ============================================
REM  CALISTIR
REM ============================================
echo.
echo ========================================
echo   SCALP SIGNAL ENGINE
echo   Mode: %LIVE_TRADING%
echo   Model: %OLLAMA_MODEL%
echo   Position: %DEFAULT_POSITION_SOL% SOL
echo   Max Position: %MAX_POSITION_SOL% SOL
echo   Max Daily Loss: %MAX_DAILY_LOSS_SOL% SOL
echo ========================================
echo.

python main.py live

pause
