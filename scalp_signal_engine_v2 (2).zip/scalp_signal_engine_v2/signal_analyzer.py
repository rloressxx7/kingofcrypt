"""
Signal Analyzer — Measures which features actually predict profitable trades.
Computes correlation between feature values and trade outcomes.
"""
import logging
from collections import defaultdict
from dataclasses import dataclass
from typing import Optional

import numpy as np

logger = logging.getLogger("analyzer")


@dataclass
class FeatureAnalysis:
    feature_name: str
    threshold: float
    direction: str  # ">" or "<"
    trades: int
    win_rate: float
    avg_pnl: float
    median_pnl: float
    total_pnl: float
    max_drawdown: float


class SignalAnalyzer:
    """Analyzes which features predict profitable trades."""

    def __init__(self):
        self._records: list[dict] = []

    def record_trade(self, entry_features: dict, exit_features: dict,
                     net_pnl: float, roi: float):
        """Record a completed trade with its entry features and outcome."""
        self._records.append({
            "entry_features": entry_features,
            "exit_features": exit_features,
            "net_pnl": net_pnl,
            "roi": roi,
            "profitable": net_pnl > 0,
        })

    def analyze_feature(self, feature_name: str, thresholds: list[float],
                        direction: str = ">") -> list[FeatureAnalysis]:
        """
        Analyze how a single feature correlates with trade outcomes.
        direction: ">" means we check if feature > threshold
        """
        results = []

        for threshold in thresholds:
            matching = []
            for rec in self._records:
                val = rec["entry_features"].get(feature_name, 0)
                if direction == ">" and val > threshold:
                    matching.append(rec)
                elif direction == "<" and val < threshold:
                    matching.append(rec)

            if not matching:
                continue

            pnls = [r["net_pnl"] for r in matching]
            wins = sum(1 for p in pnls if p > 0)

            # Max drawdown
            cumulative = 0
            peak = 0
            max_dd = 0
            for p in pnls:
                cumulative += p
                peak = max(peak, cumulative)
                dd = peak - cumulative
                max_dd = max(max_dd, dd)

            sorted_pnls = sorted(pnls)
            median = sorted_pnls[len(sorted_pnls) // 2] if sorted_pnls else 0

            results.append(FeatureAnalysis(
                feature_name=feature_name,
                threshold=threshold,
                direction=direction,
                trades=len(matching),
                win_rate=wins / len(matching),
                avg_pnl=sum(pnls) / len(matching),
                median_pnl=median,
                total_pnl=sum(pnls),
                max_drawdown=max_dd,
            ))

        return results

    def analyze_all(self) -> dict[str, list[FeatureAnalysis]]:
        """Analyze all key features."""
        analyses = {}

        # Buy/Sell ratio
        analyses["buy_sell_ratio"] = self.analyze_feature(
            "buy_sell_ratio", [1.0, 1.5, 2.0, 3.0, 5.0], ">"
        )

        # Volume acceleration
        analyses["volume_acceleration"] = self.analyze_feature(
            "volume_acceleration", [0.0, 0.5, 1.0, 2.0], ">"
        )

        # Buyer velocity
        analyses["new_buyer_velocity"] = self.analyze_feature(
            "new_buyer_velocity", [0.5, 1.0, 2.0, 5.0], ">"
        )

        # Consecutive buys
        analyses["consecutive_buys"] = self.analyze_feature(
            "consecutive_buys", [2, 3, 5, 8], ">"
        )

        # Liquidity
        analyses["liquidity"] = self.analyze_feature(
            "liquidity", [3.0, 5.0, 10.0, 20.0], ">"
        )

        # Slippage
        analyses["estimated_slippage"] = self.analyze_feature(
            "estimated_slippage", [0.01, 0.02, 0.05], "<"
        )

        # Wallet concentration
        analyses["wallet_concentration"] = self.analyze_feature(
            "wallet_concentration", [0.3, 0.5, 0.7], "<"
        )

        # Price change 5s
        analyses["price_change_5s"] = self.analyze_feature(
            "price_change_5s", [0.0, 0.02, 0.05, 0.10], ">"
        )

        # Unique buyers
        analyses["unique_buyers"] = self.analyze_feature(
            "unique_buyers", [3, 5, 10, 20], ">"
        )

        return analyses

    def analyze_combinations(self) -> list[FeatureAnalysis]:
        """Test feature combinations."""
        results = []
        records = self._records

        combos = [
            ("BSR>2 AND VA>0.5", lambda r: (
                r["entry_features"].get("buy_sell_ratio", 0) > 2.0 and
                r["entry_features"].get("volume_acceleration", 0) > 0.5
            )),
            ("BSR>1.5 AND NBV>1", lambda r: (
                r["entry_features"].get("buy_sell_ratio", 0) > 1.5 and
                r["entry_features"].get("new_buyer_velocity", 0) > 1.0
            )),
            ("BSR>2 AND liq>5", lambda r: (
                r["entry_features"].get("buy_sell_ratio", 0) > 2.0 and
                r["entry_features"].get("liquidity", 0) > 5.0
            )),
            ("VA>1 AND CB>3", lambda r: (
                r["entry_features"].get("volume_acceleration", 0) > 1.0 and
                r["entry_features"].get("consecutive_buys", 0) > 3
            )),
            ("liq>10 AND slip<0.02", lambda r: (
                r["entry_features"].get("liquidity", 0) > 10.0 and
                r["entry_features"].get("estimated_slippage", 1) < 0.02
            )),
        ]

        for name, check_fn in combos:
            matching = [r for r in records if check_fn(r)]
            if not matching:
                continue
            pnls = [r["net_pnl"] for r in matching]
            wins = sum(1 for p in pnls if p > 0)
            results.append(FeatureAnalysis(
                feature_name=name,
                threshold=0,
                direction="combo",
                trades=len(matching),
                win_rate=wins / len(matching),
                avg_pnl=sum(pnls) / len(matching),
                median_pnl=sorted(pnls)[len(pnls) // 2] if pnls else 0,
                total_pnl=sum(pnls),
                max_drawdown=0,
            ))

        return results

    def print_report(self):
        """Print full analysis report."""
        if not self._records:
            print("No trade records to analyze.")
            return

        print(f"\n{'═' * 60}")
        print(f"  SIGNAL ANALYSIS REPORT ({len(self._records)} trades)")
        print(f"{'═' * 60}")

        # Single features
        analyses = self.analyze_all()
        for feature_name, results in analyses.items():
            if not results:
                continue
            print(f"\n── {feature_name} ──")
            print(f"{'Threshold':>12} {'Trades':>7} {'WinRate':>8} {'AvgPnL':>10} {'TotalPnL':>10}")
            for r in results:
                print(f"  {r.direction}{r.threshold:<10.2f} {r.trades:>5} {r.win_rate:>7.1%} "
                      f"{r.avg_pnl:>+9.5f} {r.total_pnl:>+9.5f}")

        # Combinations
        combos = self.analyze_combinations()
        if combos:
            print(f"\n── Feature Combinations ──")
            print(f"{'Combination':>30} {'Trades':>7} {'WinRate':>8} {'AvgPnL':>10} {'TotalPnL':>10}")
            for r in combos:
                print(f"  {r.feature_name:<28} {r.trades:>5} {r.win_rate:>7.1%} "
                      f"{r.avg_pnl:>+9.5f} {r.total_pnl:>+9.5f}")

        print(f"\n{'═' * 60}")
