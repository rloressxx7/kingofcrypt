"""
Feature Engine — Real-time feature computation per mint.
Computes price, volume, buy/sell, wallet, liquidity, and MC features.
Uses sliding time windows for efficient incremental computation.
"""
import logging
import time
from collections import defaultdict, deque
from dataclasses import dataclass, field
from typing import Optional

import config

logger = logging.getLogger("features")


@dataclass
class MintFeatures:
    """Snapshot of computed features for a mint at a point in time."""
    mint: str = ""
    timestamp: float = 0.0

    # ── Price ──────────────────────────────────────────────────────────
    price: float = 0.0
    price_change_1s: float = 0.0
    price_change_3s: float = 0.0
    price_change_5s: float = 0.0
    price_change_10s: float = 0.0
    price_change_30s: float = 0.0

    # ── Volume ─────────────────────────────────────────────────────────
    volume_1s: float = 0.0
    volume_3s: float = 0.0
    volume_5s: float = 0.0
    volume_10s: float = 0.0
    volume_30s: float = 0.0
    volume_acceleration: float = 0.0

    # ── Buy/Sell ───────────────────────────────────────────────────────
    buy_volume: float = 0.0
    sell_volume: float = 0.0
    buy_sell_ratio: float = 0.0
    buy_count: int = 0
    sell_count: int = 0
    buy_velocity: float = 0.0      # buys per second
    sell_velocity: float = 0.0     # sells per second
    consecutive_buys: int = 0
    consecutive_sells: int = 0

    # ── Wallet behavior ────────────────────────────────────────────────
    unique_buyers: int = 0
    unique_sellers: int = 0
    new_buyer_velocity: float = 0.0
    repeat_buyer_ratio: float = 0.0
    wallet_concentration: float = 0.0  # top wallet % of volume
    whale_activity: float = 0.0        # large single-trade ratio
    creator_activity: int = 0

    # ── Liquidity ──────────────────────────────────────────────────────
    liquidity: float = 0.0
    liquidity_change: float = 0.0
    sol_reserve_change: float = 0.0
    price_impact: float = 0.0
    estimated_slippage: float = 0.0

    # ── Market Cap ─────────────────────────────────────────────────────
    market_cap: float = 0.0
    mc_zone: str = ""              # "10K", "15K", "20K" etc.

    # ── Token Safety ──────────────────────────────────────────────────
    mayhem_mode: bool = False
    holder_rewards_rate: float = 0.0
    migration_status: str = ""      # "", "migrating", "migrated"
    burned_liquidity_pct: float = 0.0
    mint_authority: bool = False    # True = red flag
    freeze_authority: bool = False  # True = red flag

    # ── Metadata ───────────────────────────────────────────────────────
    pool_fee_rate: float = 0.0
    event_count: int = 0
    age_seconds: float = 0.0
    tx_velocity: float = 0.0       # transactions per second

    def to_dict(self) -> dict:
        return {k: v for k, v in self.__dict__.items() if not k.startswith('_')}

    def compact_str(self) -> str:
        """Compact string for LLM input — minimal tokens."""
        mh = 1 if self.mayhem_mode else 0
        mg = {"": 0, "migrating": 1, "migrated": 2}.get(self.migration_status, 0)
        return (
            f"p={self.price:.2e},"
            f"pc1={self.price_change_1s:.3f},"
            f"pc5={self.price_change_5s:.3f},"
            f"pc10={self.price_change_10s:.3f},"
            f"v1={self.volume_1s:.0f},"
            f"v5={self.volume_5s:.0f},"
            f"v10={self.volume_10s:.0f},"
            f"va={self.volume_acceleration:.3f},"
            f"bs={self.buy_sell_ratio:.2f},"
            f"bc={self.buy_count},"
            f"sc={self.sell_count},"
            f"cb={self.consecutive_buys},"
            f"cs={self.consecutive_sells},"
            f"ub={self.unique_buyers},"
            f"us={self.unique_sellers},"
            f"nbv={self.new_buyer_velocity:.2f},"
            f"wc={self.wallet_concentration:.2f},"
            f"wh={self.whale_activity:.3f},"
            f"liq={self.liquidity:.0f},"
            f"liqc={self.liquidity_change:.3f},"
            f"slip={self.estimated_slippage:.4f},"
            f"mc={self.market_cap:.0f},"
            f"fee={self.pool_fee_rate:.4f},"
            f"age={self.age_seconds:.0f},"
            f"txv={self.tx_velocity:.2f},"
            f"mh={mh},"
            f"mg={mg},"
            f"bl={self.burned_liquidity_pct:.0f}"
        )


class TradeRecord:
    """Lightweight trade record for windowed computation."""
    __slots__ = ['ts', 'action', 'trader', 'token_amt', 'quote_amt', 'price', 'mc', 'liquidity']

    def __init__(self, ts, action, trader, token_amt, quote_amt, price, mc, liquidity):
        self.ts = ts
        self.action = action
        self.trader = trader
        self.token_amt = token_amt
        self.quote_amt = quote_amt
        self.price = price
        self.mc = mc
        self.liquidity = liquidity


class FeatureEngine:
    """Computes real-time features for each mint based on incoming events."""

    def __init__(self):
        # Per-mint state
        self._trades: dict[str, deque[TradeRecord]] = defaultdict(
            lambda: deque(maxlen=5000)
        )
        self._last_features: dict[str, MintFeatures] = {}
        self._first_event_time: dict[str, float] = {}
        self._creator_address: dict[str, str] = {}

    def update_from_event(self, event: dict) -> Optional[MintFeatures]:
        """Process an event and return updated features for the mint."""
        mint = event.get("mint")
        if not mint:
            return None

        action = event.get("action", "")
        ts = event.get("timestamp", 0) / 1000.0 if event.get("timestamp") else time.time()

        # Track first event time
        if mint not in self._first_event_time:
            self._first_event_time[mint] = ts

        # Track creator
        if action == "create":
            self._creator_address[mint] = event.get("txSigner", "")

        # Extract trade info
        price = event.get("price", 0.0) or 0.0
        mc = event.get("marketCapQuote", 0.0) or 0.0
        liquidity = self._get_liquidity(event)

        # Process breakdown for individual trades
        breakdown = event.get("breakdown") or []
        if breakdown and action in ("buy", "sell", "create"):
            for bd in breakdown:
                tr = TradeRecord(
                    ts=ts,
                    action=bd.get("action", action),
                    trader=bd.get("trader", ""),
                    token_amt=bd.get("tokenAmount", 0) or 0,
                    quote_amt=bd.get("quoteAmount", 0) or 0,
                    price=price,
                    mc=mc,
                    liquidity=liquidity,
                )
                self._trades[mint].append(tr)
        elif action in ("buy", "sell", "create"):
            traders = event.get("tradersInvolved") or {}
            trader = list(traders.keys())[0] if traders else ""
            tr = TradeRecord(
                ts=ts,
                action=action,
                trader=trader,
                token_amt=event.get("tokenAmount", 0) or 0,
                quote_amt=event.get("quoteAmount", 0) or 0,
                price=price,
                mc=mc,
                liquidity=liquidity,
            )
            self._trades[mint].append(tr)

        # Compute features
        features = self._compute_features(mint, ts, price, mc, liquidity, event)
        self._last_features[mint] = features
        return features

    def _get_liquidity(self, event: dict) -> float:
        """Estimate available liquidity in quote token."""
        vquote = event.get("vQuoteInBondingCurve")
        if vquote is not None:
            return float(vquote)
        qi = event.get("quoteInPool")
        if qi is not None:
            return float(qi)
        return 0.0

    def _compute_features(self, mint: str, now: float, price: float,
                          mc: float, liquidity: float, event: dict) -> MintFeatures:
        """Compute all features for a mint at current time."""
        f = MintFeatures(mint=mint, timestamp=now)
        trades = self._trades.get(mint)
        if not trades:
            return f

        # ── Basic ──────────────────────────────────────────────────────
        f.price = price
        f.market_cap = mc
        f.liquidity = liquidity
        f.pool_fee_rate = event.get("poolFeeRate", 0) or 0
        f.event_count = len(trades)
        f.age_seconds = max(now - self._first_event_time.get(mint, now), 0.001)
        f.mc_zone = self._get_mc_zone(mc)

        # ── Windowed computations ──────────────────────────────────────
        windows = {w: [] for w in config.FEATURE_WINDOWS}
        for tr in trades:
            age = now - tr.ts
            for w in config.FEATURE_WINDOWS:
                if age <= w:
                    windows[w].append(tr)

        # ── Price changes ──────────────────────────────────────────────
        for w in config.FEATURE_WINDOWS:
            w_trades = windows.get(w, [])
            if w_trades and len(w_trades) > 0:
                old_price = w_trades[0].price
                if old_price and old_price > 0:
                    change = (price - old_price) / old_price
                else:
                    change = 0.0
            else:
                change = 0.0

            if w == 1:
                f.price_change_1s = change
            elif w == 3:
                f.price_change_3s = change
            elif w == 5:
                f.price_change_5s = change
            elif w == 10:
                f.price_change_10s = change
            elif w == 30:
                f.price_change_30s = change

        # ── Volume ─────────────────────────────────────────────────────
        vol_windows = {}
        for w in config.FEATURE_WINDOWS:
            vol = sum(abs(tr.quote_amt) for tr in windows.get(w, []))
            vol_windows[w] = vol
            if w == 1:
                f.volume_1s = vol
            elif w == 3:
                f.volume_3s = vol
            elif w == 5:
                f.volume_5s = vol
            elif w == 10:
                f.volume_10s = vol
            elif w == 30:
                f.volume_30s = vol

        # Volume acceleration: compare recent volume rate vs older
        if vol_windows.get(5, 0) > 0 and vol_windows.get(30, 0) > 0:
            recent_rate = vol_windows[5] / 5.0
            older_rate = vol_windows[30] / 30.0
            if older_rate > 0:
                f.volume_acceleration = (recent_rate - older_rate) / older_rate
            else:
                f.volume_acceleration = 1.0 if recent_rate > 0 else 0.0

        # ── Buy/Sell ───────────────────────────────────────────────────
        # Use 30s window for buy/sell stats
        trades_30s = windows.get(30, [])
        buys = [tr for tr in trades_30s if tr.action == "buy"]
        sells = [tr for tr in trades_30s if tr.action == "sell"]

        f.buy_volume = sum(tr.quote_amt for tr in buys)
        f.sell_volume = sum(tr.quote_amt for tr in sells)
        f.buy_count = len(buys)
        f.sell_count = len(sells)
        f.buy_sell_ratio = f.buy_volume / max(f.sell_volume, 0.0001)
        f.buy_velocity = f.buy_count / max(f.age_seconds, 1.0) * 30  # normalize to 30s
        f.sell_velocity = f.sell_count / max(f.age_seconds, 1.0) * 30

        # Consecutive buys/sells (look at last N trades)
        f.consecutive_buys = 0
        f.consecutive_sells = 0
        for tr in reversed(list(trades)[-20:]):
            if tr.action == "buy":
                if f.consecutive_sells == 0:
                    f.consecutive_buys += 1
                else:
                    break
            elif tr.action == "sell":
                if f.consecutive_buys == 0:
                    f.consecutive_sells += 1
                else:
                    break

        # ── Wallet behavior ────────────────────────────────────────────
        buyer_wallets = set()
        seller_wallets = set()
        all_wallets = set()
        wallet_volumes = defaultdict(float)
        max_single_trade = 0.0
        total_vol_30s = f.buy_volume + f.sell_volume

        for tr in trades_30s:
            if tr.trader:
                all_wallets.add(tr.trader)
                wallet_volumes[tr.trader] += abs(tr.quote_amt)
                if tr.action == "buy":
                    buyer_wallets.add(tr.trader)
                elif tr.action == "sell":
                    seller_wallets.add(tr.trader)
                max_single_trade = max(max_single_trade, abs(tr.quote_amt))

        f.unique_buyers = len(buyer_wallets)
        f.unique_sellers = len(seller_wallets)

        # New buyer velocity (buyers in last 10s)
        recent_buyers = set()
        for tr in windows.get(10, []):
            if tr.action == "buy" and tr.trader:
                recent_buyers.add(tr.trader)
        f.new_buyer_velocity = len(recent_buyers) / 10.0

        # Repeat buyer ratio
        if f.unique_buyers > 0:
            repeat = len(all_wallets - buyer_wallets - seller_wallets)
            # Actually count wallets that appear more than once
            wallet_count = defaultdict(int)
            for tr in trades_30s:
                if tr.trader:
                    wallet_count[tr.trader] += 1
            repeat_count = sum(1 for c in wallet_count.values() if c > 1)
            f.repeat_buyer_ratio = repeat_count / max(len(wallet_count), 1)

        # Wallet concentration
        if total_vol_30s > 0 and wallet_volumes:
            top_vol = max(wallet_volumes.values())
            f.wallet_concentration = top_vol / total_vol_30s

        # Whale activity
        if total_vol_30s > 0:
            f.whale_activity = max_single_trade / total_vol_30s

        # Creator activity
        creator = self._creator_address.get(mint, "")
        if creator:
            for tr in trades_30s:
                if tr.trader == creator:
                    f.creator_activity += 1

        # ── Liquidity ──────────────────────────────────────────────────
        # Liquidity change over 30s
        old_liq = trades_30s[0].liquidity if trades_30s else liquidity
        if old_liq and old_liq > 0:
            f.liquidity_change = (liquidity - old_liq) / old_liq
        f.sol_reserve_change = f.liquidity_change

        # Price impact estimate
        if f.liquidity > 0:
            f.price_impact = total_vol_30s / f.liquidity
            # Estimated slippage for a 0.1 SOL trade
            trade_size = config.DEFAULT_POSITION_SOL
            f.estimated_slippage = trade_size / max(f.liquidity, 0.001)

        # ── Token Safety ──────────────────────────────────────────────
        f.mayhem_mode = bool(event.get("mayhemMode", False))
        f.holder_rewards_rate = float(event.get("holderRewardsRate", 0) or 0)

        # Migration status
        pool = event.get("pool", "")
        if event.get("action") == "migrate":
            f.migration_status = "migrating"
        elif pool in ("pump-amm", "raydium-cpmm", "meteora-damm-v1",
                      "meteora-damm-v2", "meteora-dlmm"):
            f.migration_status = "migrated"

        # Burned liquidity
        burned = event.get("burnedLiquidity")
        if burned:
            try:
                f.burned_liquidity_pct = float(str(burned).replace("%", ""))
            except (ValueError, TypeError):
                pass

        # Authority flags (red flags for scams)
        f.mint_authority = event.get("mintAuthority") is not None
        f.freeze_authority = event.get("freezeAuthority") is not None

        # ── Transaction velocity ───────────────────────────────────────
        f.tx_velocity = len(trades_30s) / 30.0 if trades_30s else 0.0

        return f

    def _get_mc_zone(self, mc: float) -> str:
        """Determine which MC zone the token is in."""
        if mc <= 5000:
            return "<5K"
        elif mc <= 10000:
            return "5K-10K"
        elif mc <= 15000:
            return "10K-15K"
        elif mc <= 20000:
            return "15K-20K"
        elif mc <= 25000:
            return "20K-25K"
        elif mc <= 30000:
            return "25K-30K"
        else:
            return ">30K"

    def get_features(self, mint: str) -> Optional[MintFeatures]:
        return self._last_features.get(mint)

    def cleanup(self, mint: str):
        """Remove all data for a mint."""
        self._trades.pop(mint, None)
        self._last_features.pop(mint, None)
        self._first_event_time.pop(mint, None)
        self._creator_address.pop(mint, None)
