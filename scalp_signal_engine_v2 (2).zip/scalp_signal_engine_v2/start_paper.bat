@echo off
REM ============================================
REM  Scalp Signal Engine - Paper Trading
REM  (Gercek islem yok, sadece test)
REM ============================================

set LIVE_TRADING=false
set OLLAMA_URL=http://127.0.0.1:11434
set OLLAMA_MODEL=local-jev
set DEFAULT_POSITION_SOL=0.1

echo.
echo ========================================
echo   SCALP SIGNAL ENGINE - PAPER MODE
echo   (No real transactions)
echo ========================================
echo.

python main.py live --paper

pause
