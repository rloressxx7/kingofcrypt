"""
Mint Recorder — Records full lifecycle of each mint.
Stores events in memory (active mints) and persists to JSON (completed).
"""
import asyncio
import logging
import os
import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Optional

import orjson

import config

logger = logging.getLogger("recorder")


@dataclass
class MintLifecycle:
    """Complete lifecycle record for a single mint."""
    mint: str
    created_at: float = 0.0
    first_seen: float = 0.0
    last_seen: float = 0.0
    events: list = field(default_factory=list)
    name: str = ""
    symbol: str = ""
    pool_id: str = ""
    pool_type: str = ""
    creator: str = ""
    supply: float = 0.0
    decimals: int = 6
    is_migrated: bool = False
    is_active: bool = True
    # Price history for feature engine
    price_history: list = field(default_factory=list)  # [(timestamp, price, mc, liq)]
    # Trade history
    trade_history: list = field(default_factory=list)  # [(timestamp, action, trader, token_amt, quote_amt)]

    def add_event(self, event: dict):
        """Record an event in this mint's lifecycle."""
        ts = event.get("timestamp", 0) / 1000.0 if event.get("timestamp") else time.time()

        # Store raw event (trimmed for storage)
        self.events.append({
            "ts": ts,
            "action": event.get("action"),
            "signature": event.get("signature", "")[:20],
            "mint": event.get("mint", "")[:12],
            "price": event.get("price"),
            "marketCapQuote": event.get("marketCapQuote"),
            "tokenAmount": event.get("tokenAmount"),
            "quoteAmount": event.get("quoteAmount"),
            "tokensInPool": event.get("tokensInPool"),
            "quoteInPool": event.get("quoteInPool"),
            "vTokensInBondingCurve": event.get("vTokensInBondingCurve"),
            "vQuoteInBondingCurve": event.get("vQuoteInBondingCurve"),
            "breakdown": event.get("breakdown"),
            "tradersInvolved": list((event.get("tradersInvolved") or {}).keys()),
            "pool": event.get("pool"),
            "poolFeeRate": event.get("poolFeeRate"),
            "priorityFee": event.get("priorityFee"),
        })

        # Update price history
        price = event.get("price")
        mc = event.get("marketCapQuote")
        # Liquidity estimation
        liq = self._estimate_liquidity(event)
        if price is not None:
            self.price_history.append((ts, price, mc, liq))

        # Update trade history
        action = event.get("action")
        if action in ("buy", "sell", "create"):
            breakdown = event.get("breakdown") or []
            if breakdown:
                for bd in breakdown:
                    self.trade_history.append((
                        ts,
                        bd.get("action", action),
                        bd.get("trader", ""),
                        bd.get("tokenAmount", 0),
                        bd.get("quoteAmount", 0),
                    ))
            else:
                trader = ""
                traders = event.get("tradersInvolved") or {}
                if traders:
                    trader = list(traders.keys())[0]
                self.trade_history.append((
                    ts,
                    action,
                    trader,
                    event.get("tokenAmount", 0),
                    event.get("quoteAmount", 0),
                ))

        self.last_seen = ts

        # Update metadata from create event
        if action == "create":
            self.name = event.get("name", "")
            self.symbol = event.get("symbol", "")
            self.pool_id = event.get("poolId", "")
            self.pool_type = event.get("pool", "")
            self.creator = event.get("txSigner", "")
            self.supply = event.get("supply", 0)
            self.decimals = event.get("decimals", 6)
            self.created_at = ts
            self.first_seen = ts

        if action == "migrate":
            self.is_migrated = True

    def _estimate_liquidity(self, event: dict) -> float:
        """Estimate liquidity in quote token (usually SOL)."""
        # For pump/raydium-launchpad: use bonding curve
        vquote = event.get("vQuoteInBondingCurve")
        if vquote is not None:
            return float(vquote)
        # For AMM pools
        qi = event.get("quoteInPool")
        if qi is not None:
            return float(qi)
        return 0.0

    def to_dict(self) -> dict:
        return {
            "mint": self.mint,
            "name": self.name,
            "symbol": self.symbol,
            "pool_id": self.pool_id,
            "pool_type": self.pool_type,
            "creator": self.creator,
            "supply": self.supply,
            "decimals": self.decimals,
            "created_at": self.created_at,
            "first_seen": self.first_seen,
            "last_seen": self.last_seen,
            "is_migrated": self.is_migrated,
            "event_count": len(self.events),
            "trade_count": len(self.trade_history),
            "events": self.events,
            "price_history": self.price_history[-500:],  # keep last 500
            "trade_history": self.trade_history[-1000:],  # keep last 1000
        }


class MintRecorder:
    """Records lifecycle of all observed mints."""

    def __init__(self):
        self._mints: dict[str, MintLifecycle] = {}
        self._completed: list[str] = []
        self._lock = asyncio.Lock()

    async def record_event(self, event: dict) -> Optional[MintLifecycle]:
        """Process an event and update mint lifecycle."""
        mint = event.get("mint")
        if not mint:
            return None

        async with self._lock:
            if mint not in self._mints:
                self._mints[mint] = MintLifecycle(mint=mint)
            lc = self._mints[mint]
            lc.add_event(event)
            return lc

    def get_mint(self, mint: str) -> Optional[MintLifecycle]:
        return self._mints.get(mint)

    def get_active_mints(self) -> list[str]:
        return [m for m, lc in self._mints.items() if lc.is_active]

    async def save_mint(self, mint: str):
        """Persist a mint's lifecycle to JSON file."""
        lc = self._mints.get(mint)
        if not lc:
            return
        path = os.path.join(config.MINTS_DIR, f"{mint}.json")
        data = orjson.dumps(lc.to_dict(), option=orjson.OPT_INDENT_2)
        with open(path, "wb") as f:
            f.write(data)
        logger.info(f"Saved mint lifecycle: {mint[:12]}.. ({len(lc.events)} events)")

    async def mark_inactive(self, mint: str):
        """Mark a mint as inactive and save."""
        lc = self._mints.get(mint)
        if lc:
            lc.is_active = False
            self._completed.append(mint)
            await self.save_mint(mint)

    def cleanup_old(self, max_age_seconds: float = 3600):
        """Remove old completed mints from memory."""
        now = time.time()
        to_remove = []
        for mint, lc in self._mints.items():
            if not lc.is_active and (now - lc.last_seen) > max_age_seconds:
                to_remove.append(mint)
        for mint in to_remove:
            del self._mints[mint]

    @property
    def stats(self) -> dict:
        active = sum(1 for lc in self._mints.values() if lc.is_active)
        return {
            "total_mints": len(self._mints),
            "active_mints": active,
            "completed": len(self._completed),
        }

    @staticmethod
    def load_mint(mint_address: str) -> Optional[dict]:
        """Load a saved mint lifecycle from disk."""
        path = os.path.join(config.MINTS_DIR, f"{mint_address}.json")
        if not os.path.exists(path):
            return None
        with open(path, "rb") as f:
            return orjson.loads(f.read())
