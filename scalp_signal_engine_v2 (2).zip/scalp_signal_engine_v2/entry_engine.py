"""
Entry Engine — Multi-stage entry pipeline with calibrated probabilities.
Stages: MC filter → Liquidity → Slippage → Risk → Buy/Sell → Volume →
         Wallet → Qwen → Historical Probability → EV → Final Decision
"""
import logging
import time
from dataclasses import dataclass, field
from typing import Optional

import config
from feature_engine import MintFeatures
from qwen_client import QwenClient
from probability_calibrator import ProbabilityCalibrator

logger = logging.getLogger("entry")


@dataclass
class EntrySignal:
    mint: str
    action: str             # BUY, WAIT, SKIP
    score: float            # deterministic score
    confidence: float       # Qwen confidence
    risk: float             # Qwen risk
    p5_raw: float = 0.0    # raw model p5
    p10_raw: float = 0.0
    p20_raw: float = 0.0
    p5_cal: float = 0.0    # calibrated p5
    p10_cal: float = 0.0
    p20_cal: float = 0.0
    cal_confidence: float = 0.0  # calibration confidence
    expected_value: float = 0.0
    reasons: list = field(default_factory=list)
    qwen_called: bool = False
    qwen_latency_ms: float = 0.0


class EntryEngine:
    """Multi-stage entry: deterministic filters → Qwen → calibration → EV."""

    def __init__(self, qwen: Optional[QwenClient],
                 calibrator: Optional[ProbabilityCalibrator] = None):
        self.qwen = qwen
        self.calibrator = calibrator or ProbabilityCalibrator()
        self._signal_count = 0
        self._entry_count = 0

    def deterministic_filter(self, f: MintFeatures) -> tuple[bool, float, list[str]]:
        """
        Fast multi-stage deterministic pre-filter.
        Returns: (is_candidate, score, reasons)
        """
        reasons = []
        score = 0.0

        # ── Stage 1: MC zone ──────────────────────────────────────────
        mc = f.market_cap
        if mc < config.MC_TARGET_LOW * 0.8:
            return False, 0.0, ["MC too low"]
        if mc > config.MC_TARGET_HIGH * 1.2:
            return False, 0.0, ["MC too high"]

        # ── Stage 2: Liquidity ────────────────────────────────────────
        if f.liquidity < config.ENTRY_MIN_LIQUIDITY_SOL:
            return False, 0.0, [f"Liquidity too low ({f.liquidity:.1f} SOL)"]

        # ── Stage 3: Slippage ─────────────────────────────────────────
        if f.estimated_slippage > config.MAX_SLIPPAGE_PCT:
            return False, 0.0, [f"Slippage too high ({f.estimated_slippage:.4f})"]

        # ── Stage 4: Pool fee / risk ──────────────────────────────────
        if f.pool_fee_rate > config.ENTRY_MAX_POOL_FEE_RATE:
            return False, 0.0, ["pool fee too high"]

        # mayhemMode check
        if getattr(f, 'mayhem_mode', False):
            return False, 0.0, ["mayhemMode=True — too risky"]

        # migration check — don't enter during migration
        if getattr(f, 'migration_status', '') == 'migrating':
            return False, 0.0, ["migration in progress"]

        # ── Stage 4b: ACTIVITY CHECK — Only active tokens ─────────────
        # Must have recent transaction activity
        if f.tx_velocity < 0.3:
            return False, 0.0, [f"too inactive tx_vel={f.tx_velocity:.2f}"]

        # Must have at least 2 unique buyers (not just 1 whale)
        if f.unique_buyers < 2:
            return False, 0.0, [f"too few buyers unique={f.unique_buyers}"]

        # Must have positive buy volume (actual buying happening)
        if f.buy_volume <= 0:
            return False, 0.0, ["no buy volume"]

        # ── Stage 5: Buy/Sell flow ────────────────────────────────────
        if f.buy_sell_ratio >= config.ENTRY_MIN_BUY_SELL_RATIO:
            score += 0.15 * min(f.buy_sell_ratio / 3.0, 1.0)
            reasons.append(f"BSR={f.buy_sell_ratio:.2f}")
        else:
            reasons.append(f"BSR low={f.buy_sell_ratio:.2f}")

        # ── Stage 6: Volume acceleration ──────────────────────────────
        if f.volume_acceleration > config.ENTRY_MIN_VOLUME_ACCEL:
            score += 0.12 * min(f.volume_acceleration / 2.0, 1.0)
            reasons.append(f"VA={f.volume_acceleration:.2f}")

        # ── Stage 7: Wallet behavior ──────────────────────────────────
        if f.new_buyer_velocity >= config.ENTRY_MIN_BUYER_VELOCITY:
            score += 0.10 * min(f.new_buyer_velocity / 3.0, 1.0)
            reasons.append(f"NBV={f.new_buyer_velocity:.2f}")

        if f.consecutive_buys >= 3:
            score += 0.08 * min(f.consecutive_buys / 8.0, 1.0)
            reasons.append(f"CB={f.consecutive_buys}")

        if f.unique_buyers >= 3:
            score += 0.05 * min(f.unique_buyers / 10.0, 1.0)

        # ── Stage 8: Momentum (STRONGER requirement) ──────────────────
        if f.price_change_5s > 0.01:  # Was 0.0, now requires +1% in 5s
            score += 0.12 * min(f.price_change_5s / 0.1, 1.0)
            reasons.append(f"mom5s={f.price_change_5s:.4f}")
        elif f.price_change_5s < -0.01:
            # Penalize negative momentum
            score -= 0.10
            reasons.append(f"mom5s_NEG={f.price_change_5s:.4f}")

        # ── Stage 9: Wallet concentration / whale ─────────────────────
        if f.wallet_concentration <= config.ENTRY_MAX_WHALE_CONCENTRATION:
            score += 0.05
        else:
            reasons.append(f"wc high={f.wallet_concentration:.2f}")

        # ── Stage 10: Transaction velocity ────────────────────────────
        if f.tx_velocity > 0.5:
            score += 0.05 * min(f.tx_velocity / 3.0, 1.0)

        # ── Stage 11: Liquidity (bonus for good liquidity) ────────────
        if f.liquidity >= config.ENTRY_MIN_LIQUIDITY_SOL * 2:
            score += 0.05
            reasons.append(f"liq={f.liquidity:.1f}")

        # ── Stage 12: Creator behavior ────────────────────────────────
        if f.creator_activity > 0:
            reasons.append(f"creator_active={f.creator_activity}")
            score -= 0.05  # creator selling is bearish

        # Price impact check
        if f.price_impact > config.MAX_PRICE_IMPACT_PCT * 10:
            reasons.append(f"price_impact high={f.price_impact:.4f}")
            score -= 0.10

        # Candidate threshold — higher = more selective
        is_candidate = score >= 0.35

        return is_candidate, score, reasons

    async def evaluate(self, f: MintFeatures) -> EntrySignal:
        """Full entry evaluation pipeline."""
        is_candidate, score, reasons = self.deterministic_filter(f)

        signal = EntrySignal(
            mint=f.mint,
            action="SKIP",
            score=score,
            confidence=0.0,
            risk=0.0,
            reasons=reasons,
        )

        if not is_candidate:
            logger.debug(f"[ENTRY] {f.mint[:12]}.. REJECTED by filter: score={score:.3f}, reasons={reasons}")
            self._signal_count += 1
            return signal

        # ── Call Qwen (only for candidates) ───────────────────────────
        if self.qwen:
            prompt = f.compact_str()
            result = await self.qwen.ask(prompt)

            if result:
                signal.qwen_called = True
                signal.qwen_latency_ms = result.get("latency_ms", 0)
                signal.confidence = result["c"]
                signal.risk = result["r"]
                signal.p5_raw = result.get("p5", 0.0)
                signal.p10_raw = result.get("p10", 0.0)
                signal.p20_raw = result.get("p20", 0.0)

                # Log JEV response for debugging
                logger.info(f"[ENTRY] {f.mint[:12]}.. JEV: action={result['a']} conf={result['c']:.2f} risk={result['r']:.2f} p5={result.get('p5',0):.2f} p10={result.get('p10',0):.2f} p20={result.get('p20',0):.2f} score={score:.2f} mc={f.market_cap:.0f}")

                # ── Calibrate probabilities ────────────────────────────
                cal = self.calibrator.calibrate_all(
                    signal.p5_raw, signal.p10_raw, signal.p20_raw
                )
                signal.p5_cal = cal["p5_cal"]
                signal.p10_cal = cal["p10_cal"]
                signal.p20_cal = cal["p20_cal"]
                signal.cal_confidence = min(cal["p5_conf"], cal["p10_conf"], cal["p20_conf"])

                # ── Expected Value ─────────────────────────────────────
                signal.expected_value = self.calibrator.compute_expected_value(
                    cal, config.DEFAULT_POSITION_SOL
                )

                # ── Final Decision ─────────────────────────────────────
                if result["a"] == "BUY":
                    # JEV said BUY — enter if deterministic score is STRONG
                    if score >= 0.40:
                        # Also require positive momentum
                        if f.price_change_5s > 0:
                            signal.action = "BUY"
                            self._entry_count += 1
                            logger.info(f"[ENTRY] {f.mint[:12]}.. BUY | score={score:.2f} conf={signal.confidence:.2f} risk={signal.risk:.2f} mc={f.market_cap:.0f} mom={f.price_change_5s:.4f}")
                        else:
                            signal.action = "WAIT"
                            logger.info(f"[ENTRY] {f.mint[:12]}.. JEV BUY but no momentum: mom5s={f.price_change_5s:.4f}")
                    else:
                        signal.action = "WAIT"
                        logger.info(f"[ENTRY] {f.mint[:12]}.. JEV BUY but score too low: {score:.2f}<0.40")
                elif result["a"] == "WAIT":
                    # If deterministic score is very high, enter anyway
                    if score >= 0.50:  # Was 0.45, now 0.50
                        signal.action = "BUY"
                        self._entry_count += 1
                        logger.info(f"[ENTRY] {f.mint[:12]}.. BUY (JEV WAIT but high score={score:.2f})")
                    else:
                        signal.action = "WAIT"
                else:
                    signal.action = "SKIP"
            else:
                # Qwen failed — fallback to deterministic if score very high
                if score >= 0.70:
                    signal.action = "BUY"
                    signal.confidence = score
                    signal.risk = 0.3
                    self._entry_count += 1
                    reasons.append("qwen_failed_fallback")
                else:
                    signal.action = "WAIT"
                    reasons.append("qwen_failed")
        else:
            # No Qwen — deterministic only
            if score >= 0.60:
                signal.action = "BUY"
                signal.confidence = score
                signal.risk = 0.3
                self._entry_count += 1
            else:
                signal.action = "WAIT"

        self._signal_count += 1
        return signal

    @property
    def stats(self) -> dict:
        return {
            "signals_evaluated": self._signal_count,
            "entries_triggered": self._entry_count,
        }
