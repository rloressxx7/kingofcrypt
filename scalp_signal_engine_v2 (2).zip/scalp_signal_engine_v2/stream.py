"""
PumpAPI WebSocket Stream Handler
- Auto-reconnect with exponential backoff
- Duplicate event filtering by signature+action+mint
- Event routing to mint recorder
"""
import asyncio
import logging
import time
from collections import OrderedDict
from typing import Callable, Optional

import orjson
import websockets
import websockets.exceptions

import config

logger = logging.getLogger("stream")


class PumpStream:
    """Connects to PumpAPI WS, parses events, routes to callbacks."""

    def __init__(self, on_event: Callable):
        self.on_event = on_event  # async callable(event: dict)
        self._seen: OrderedDict[str, bool] = OrderedDict()
        self._running = False
        self._reconnect_delay = config.WS_RECONNECT_DELAY
        self._event_count = 0
        self._dup_count = 0
        self._ws = None

    @property
    def stats(self) -> dict:
        return {
            "events_processed": self._event_count,
            "duplicates_dropped": self._dup_count,
            "cache_size": len(self._seen),
            "connected": self._ws is not None,
        }

    def _is_duplicate(self, event: dict) -> bool:
        """Check and record event signature to drop duplicates."""
        sig = event.get("signature", "")
        action = event.get("action", "")
        mint = event.get("mint", "")
        key = f"{sig}:{action}:{mint}"
        if key in self._seen:
            return True
        self._seen[key] = True
        # Evict oldest
        while len(self._seen) > config.DUPLICATE_CACHE_MAX:
            self._seen.popitem(last=False)
        return False

    async def _connect_and_stream(self):
        """Single connection attempt — reads until disconnect."""
        uri = config.PUMPAPI_WS_URL
        logger.info(f"Connecting to {uri}...")

        async with websockets.connect(
            uri,
            ping_interval=config.WS_PING_INTERVAL,
            ping_timeout=config.WS_PING_TIMEOUT,
            close_timeout=5,
            max_size=10 * 1024 * 1024,  # 10MB
        ) as ws:
            self._ws = ws
            self._reconnect_delay = config.WS_RECONNECT_DELAY
            logger.info("Connected to PumpAPI stream")

            async for raw in ws:
                try:
                    if isinstance(raw, bytes):
                        event = orjson.loads(raw)
                    else:
                        event = orjson.loads(raw.encode())
                except Exception:
                    logger.warning(f"Failed to parse event: {raw[:200]}")
                    continue

                # Filter: only pump.fun related events
                action = event.get("action", "")
                pool = event.get("pool", "")

                # Skip transfer-only events and createConfig
                if action in ("transfer", "createConfig", "distributeFees"):
                    continue

                # Skip non-pump pools (we focus on pump.fun ecosystem)
                if pool and pool not in (
                    "pump", "pump-amm",
                    "raydium-launchpad", "raydium-cpmm",
                    "meteora-launchpad", "meteora-damm-v1",
                    "meteora-damm-v2", "meteora-dlmm",
                ):
                    continue

                # Duplicate check
                if self._is_duplicate(event):
                    self._dup_count += 1
                    continue

                self._event_count += 1

                # Route to handler
                try:
                    await self.on_event(event)
                except Exception as e:
                    logger.error(f"Event handler error: {e}", exc_info=True)

    async def run(self):
        """Main loop with auto-reconnect."""
        self._running = True
        while self._running:
            try:
                await self._connect_and_stream()
            except (
                websockets.exceptions.ConnectionClosed,
                websockets.exceptions.WebSocketException,
                ConnectionRefusedError,
                OSError,
            ) as e:
                self._ws = None
                logger.warning(f"Connection lost: {e}. Reconnecting in {self._reconnect_delay:.1f}s")
                await asyncio.sleep(self._reconnect_delay)
                self._reconnect_delay = min(
                    self._reconnect_delay * 2,
                    config.WS_MAX_RECONNECT_DELAY,
                )
            except asyncio.CancelledError:
                self._running = False
                break
            except Exception as e:
                self._ws = None
                logger.error(f"Unexpected stream error: {e}", exc_info=True)
                await asyncio.sleep(self._reconnect_delay)
                self._reconnect_delay = min(
                    self._reconnect_delay * 2,
                    config.WS_MAX_RECONNECT_DELAY,
                )

    def stop(self):
        self._running = False
