"""
Real Executor — Solana mainnet execution via PumpAPI Trade API.
https://api.pumpapi.io

Two modes:
  1. Lightning — send apiKey (encrypted private key), PumpAPI signs+broadcasts
  2. Local    — send publicKey only, get unsigned tx, sign locally, broadcast yourself

IMPORTANT: Private keys are NEVER logged or exposed in responses.
"""
import asyncio
import base64
import logging
import os
import time
from typing import Optional

import aiohttp
import orjson

import config
from execution_interface import BaseExecutor, ExecutionMode, ExecutionResult

logger = logging.getLogger("real_exec")

PUMPAPI_TRADE_URL = "https://api.pumpapi.io"
PUMPAPI_WALLET_URL = "https://wallet.pumpapi.io"

# Lazy imports for Solana signing (only needed for Local mode)
_solders_available = False
try:
    from solders.keypair import Keypair
    from solders.transaction import VersionedTransaction
    from solders.message import to_bytes_versioned
    _solders_available = True
except ImportError:
    pass


def _load_keypair_local():
    """Load keypair for Local mode. NEVER logs private key."""
    if not _solders_available:
        raise RuntimeError("solders not installed. pip install solders")

    if config.SOLANA_KEYPAIR_PATH and os.path.exists(config.SOLANA_KEYPAIR_PATH):
        with open(config.SOLANA_KEYPAIR_PATH) as f:
            data = orjson.loads(f.read())
        if isinstance(data, list):
            return Keypair.from_bytes(bytes(data))
        raise ValueError("Invalid keypair file format (expected JSON array of bytes)")

    if config.SOLANA_PRIVATE_KEY:
        return Keypair.from_base58_string(config.SOLANA_PRIVATE_KEY)

    raise RuntimeError(
        "No wallet configured. Set SOLANA_KEYPAIR_PATH or SOLANA_PRIVATE_KEY."
    )


class RealExecutor(BaseExecutor):
    """
    Executes real Solana transactions via PumpAPI Trade API.

    Execution mode is chosen based on available credentials:
      - PUMPAPI_API_KEY set → Lightning mode (fastest)
      - SOLANA_KEYPAIR_PATH or SOLANA_PRIVATE_KEY set → Local mode (most secure)
    """

    def __init__(self):
        super().__init__(ExecutionMode.LIVE)
        self._mode: str = ""              # "lightning" or "local"
        self._api_key: str = ""           # encrypted key for Lightning mode
        self._public_key: str = ""        # wallet public key
        self._keypair = None              # Keypair for Local mode (never logged)
        self._http: Optional[aiohttp.ClientSession] = None
        self._rpc_http: Optional[aiohttp.ClientSession] = None
        self._sent_signatures: set[str] = set()

    async def initialize(self):
        """Detect mode, load wallet, create HTTP sessions."""
        self._http = aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=30)
        )
        self._rpc_http = aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=30)
        )

        # Determine mode
        self._api_key = os.environ.get("PUMPAPI_API_KEY", "")

        if self._api_key:
            # ── Lightning mode ────────────────────────────────────────
            self._mode = "lightning"
            # We still need the public key for balance checks.
            # Generate apiKey from privateKey to get publicKey if needed.
            kp_env = os.environ.get("SOLANA_PRIVATE_KEY", "")
            if kp_env and _solders_available:
                kp = Keypair.from_base58_string(kp_env)
                self._public_key = str(kp.pubkey())
                self._keypair = kp  # keep for local fallback
            elif config.SOLANA_KEYPAIR_PATH and _solders_available:
                kp = _load_keypair_local()
                self._public_key = str(kp.pubkey())
                self._keypair = kp
            else:
                # Try to get public key from environment
                self._public_key = os.environ.get("SOLANA_PUBLIC_KEY", "")
                if not self._public_key:
                    raise RuntimeError(
                        "Lightning mode: need SOLANA_PUBLIC_KEY or a keypair "
                        "to derive it. Set PUMPAPI_API_KEY + SOLANA_PUBLIC_KEY."
                    )
            logger.info(
                f"⚡ Lightning mode | Wallet: {self._public_key[:8]}..{self._public_key[-8:]}"
            )
        else:
            # ── Local mode ────────────────────────────────────────────
            self._mode = "local"
            if not _solders_available:
                raise RuntimeError(
                    "Local mode requires solders. pip install solders"
                )
            self._keypair = _load_keypair_local()
            self._public_key = str(self._keypair.pubkey())
            logger.info(
                f"🔐 Local mode | Wallet: {self._public_key[:8]}..{self._public_key[-8:]}"
            )

        # Verify balance
        balance = await self.get_sol_balance()
        logger.info(f"Wallet balance: {balance:.6f} SOL")

    async def close(self):
        for session in (self._http, self._rpc_http):
            if session and not session.closed:
                await session.close()

    async def get_wallet_address(self) -> str:
        return self._public_key

    # ── Balance queries (via Solana RPC) ──────────────────────────────

    async def _rpc_call(self, method: str, params: list) -> dict:
        """Make a JSON-RPC call to Solana RPC."""
        payload = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params}
        async with self._rpc_http.post(
            config.SOLANA_RPC_URL,
            json=payload,
            headers={"Content-Type": "application/json"},
        ) as resp:
            data = await resp.read()
            return orjson.loads(data)

    async def get_sol_balance(self) -> float:
        try:
            result = await self._rpc_call("getBalance", [self._public_key])
            lamports = result.get("result", {}).get("value", 0)
            return lamports / 1e9
        except Exception as e:
            logger.error(f"Balance check failed: {e}")
            return 0.0

    async def get_token_balance(self, mint: str) -> float:
        try:
            result = await self._rpc_call(
                "getTokenAccountsByOwner",
                [
                    self._public_key,
                    {"mint": mint},
                    {"encoding": "jsonParsed"},
                ],
            )
            accounts = result.get("result", {}).get("value", [])
            total = 0.0
            for acct in accounts:
                info = acct.get("account", {}).get("data", {}).get("parsed", {}).get("info", {})
                amount = info.get("tokenAmount", {})
                ui_amount = amount.get("uiAmount", 0)
                if ui_amount:
                    total += float(ui_amount)
            return total
        except Exception as e:
            logger.error(f"Token balance check failed for {mint[:12]}: {e}")
            return 0.0

    async def has_ata(self, mint: str) -> bool:
        balance = await self.get_token_balance(mint)
        # If query succeeds and returns anything, ATA exists (even 0 balance)
        return True  # conservative — assume exists if query works

    async def check_tx_status(self, signature: str) -> dict:
        try:
            result = await self._rpc_call(
                "getSignatureStatuses",
                [[signature], {"searchTransactionHistory": True}],
            )
            statuses = result.get("result", {}).get("value", [])
            if statuses and statuses[0]:
                s = statuses[0]
                return {
                    "confirmed": s.get("err") is None,
                    "slot": s.get("slot", 0),
                    "err": s.get("err"),
                }
            return {"confirmed": False, "slot": 0, "err": "not_found"}
        except Exception as e:
            return {"confirmed": False, "slot": 0, "err": str(e)}

    # ── Trade execution ───────────────────────────────────────────────

    def _build_trade_payload(self, action: str, mint: str, amount,
                              denominated_in_quote: bool, slippage_pct: float,
                              priority_fee: float) -> dict:
        """Build the common trade payload dict."""
        payload = {
            "action": action,
            "mint": mint,
            "amount": amount,
            "denominatedInQuote": "true" if denominated_in_quote else "false",
            "slippage": slippage_pct,  # PumpAPI expects percent (e.g. 20 = 20%)
            "priorityFee": priority_fee,
        }

        # Jito tip (optional explicit)
        if config.JITO_ENABLED and config.JITO_TIP_SOL >= 0.0002:
            payload["jitoTip"] = config.JITO_TIP_SOL
        # else: priorityFee >= 0.00023 auto-splits to Jito

        return payload

    async def buy(self, mint: str, sol_amount: float,
                  max_slippage_pct: float, price: float,
                  liquidity: float) -> ExecutionResult:
        """Execute a real BUY via PumpAPI Trade API."""
        result = ExecutionResult(mint=mint, action="buy")
        start = time.time()

        try:
            # Expected tokens (for slippage comparison)
            result.expected_token_amount = sol_amount / price if price > 0 else 0

            # Slippage in percent (PumpAPI expects e.g. 20 for 20%)
            slippage_pct = max_slippage_pct * 100

            payload = self._build_trade_payload(
                "buy", mint, sol_amount, True, slippage_pct, config.PRIORITY_FEE_SOL
            )

            if self._mode == "lightning":
                exec_result = await self._execute_lightning(payload, result)
            else:
                exec_result = await self._execute_local(payload, result)

        except Exception as e:
            result.success = False
            result.failed = True
            result.error = str(e)
            logger.error(f"Buy error: {e}", exc_info=True)

        result.latency_ms = (time.time() - start) * 1000
        self.record_execution(result)
        return result

    async def sell(self, mint: str, token_amount: float,
                   max_slippage_pct: float, price: float,
                   liquidity: float) -> ExecutionResult:
        """Execute a real SELL via PumpAPI Trade API."""
        result = ExecutionResult(mint=mint, action="sell")
        start = time.time()

        try:
            # Verify balance first
            actual_balance = await self.get_token_balance(mint)
            if actual_balance <= 0:
                result.success = False
                result.failed = True
                result.error = "No tokens to sell (balance=0)"
                result.latency_ms = (time.time() - start) * 1000
                self.record_execution(result)
                return result

            sell_amount = min(token_amount, actual_balance)
            # Use "100%" if selling all (closes ATA, refunds rent)
            if abs(sell_amount - actual_balance) < actual_balance * 0.001:
                sell_amount_str = "100%"
            else:
                sell_amount_str = sell_amount

            result.expected_token_amount = sell_amount if isinstance(sell_amount, float) else actual_balance

            slippage_pct = max_slippage_pct * 100

            payload = self._build_trade_payload(
                "sell", mint, sell_amount_str, False, slippage_pct, config.PRIORITY_FEE_SOL
            )

            if self._mode == "lightning":
                exec_result = await self._execute_lightning(payload, result)
            else:
                exec_result = await self._execute_local(payload, result)

        except Exception as e:
            result.success = False
            result.failed = True
            result.error = str(e)
            logger.error(f"Sell error: {e}", exc_info=True)

        result.latency_ms = (time.time() - start) * 1000
        self.record_execution(result)
        return result

    # ── Lightning mode ────────────────────────────────────────────────

    async def _execute_lightning(self, payload: dict,
                                  result: ExecutionResult) -> ExecutionResult:
        """
        Lightning: send apiKey + trade params, PumpAPI signs+broadcasts.
        Response: {"signature": "...", "err": "", "timestamp": ..., "trades": [...]}
        """
        payload["apiKey"] = self._api_key

        # guaranteedDelivery for confirmation
        payload["guaranteedDelivery"] = "true"

        async with self._http.post(PUMPAPI_TRADE_URL, json=payload) as resp:
            resp_text = await resp.text()

        try:
            data = orjson.loads(resp_text.encode())
        except Exception:
            result.success = False
            result.failed = True
            result.error = f"Invalid response: {resp_text[:200]}"
            logger.error(result.error)
            return result

        # Check for error
        err = data.get("err", "")
        signature = data.get("signature", "")
        trades = data.get("trades", [])

        if err:
            result.success = False
            result.failed = True
            result.error = f"PumpAPI error: {err}"
            result.signature = signature
            logger.error(result.error)
            return result

        if not signature:
            result.success = False
            result.failed = True
            result.error = "No signature in response"
            return result

        # Duplicate check
        if signature in self._sent_signatures:
            result.success = False
            result.failed = True
            result.error = f"DUPLICATE_TX: {signature[:20]}"
            return result
        self._sent_signatures.add(signature)

        result.signature = signature
        result.confirmed = True  # guaranteedDelivery=true means confirmed
        result.success = True

        # Parse trade info
        if trades:
            trade = trades[0]
            result.price = 0  # will be computed from balance diff

        # Costs
        result.priority_fee_paid = payload.get("priorityFee", config.PRIORITY_FEE_SOL)
        result.base_tx_fee = config.BASE_TX_FEE_SOL
        if config.JITO_ENABLED:
            result.jito_tip_paid = payload.get("jitoTip", 0)

        # For Lightning mode, we get actual amounts from balance diff
        # or from the stream events (our own buy/sell events on the mint)
        # For now, set estimated values — they'll be updated by stream events
        sol_amount = payload.get("amount", 0)
        if isinstance(sol_amount, (int, float)):
            if payload["action"] == "buy":
                result.sol_amount = float(sol_amount)
                result.pump_fee_paid = float(sol_amount) * config.PUMP_FEE_RATE
            else:
                # For sell, we'll get the actual SOL from stream event
                result.pump_fee_paid = 0  # updated later

        logger.info(
            f"{'📈 BUY' if payload['action'] == 'buy' else '📉 SELL'} "
            f"LIGHTNING CONFIRMED | {signature[:20]}.. | "
            f"mint={payload['mint'][:12]}.."
        )

        return result

    # ── Local mode ────────────────────────────────────────────────────

    async def _execute_local(self, payload: dict,
                              result: ExecutionResult) -> ExecutionResult:
        """
        Local mode: send publicKey + trade params, get unsigned tx,
        sign locally, broadcast to Solana RPC.
        """
        payload["publicKey"] = self._public_key
        # Remove any private key fields (safety)
        payload.pop("privateKey", None)
        payload.pop("apiKey", None)

        # Request unsigned transaction
        async with self._http.post(PUMPAPI_TRADE_URL, json=payload) as resp:
            raw_bytes = await resp.read()
            logger.debug(f"PumpAPI response: {resp.status} bytes={len(raw_bytes)}")

        if not raw_bytes:
            result.success = False
            result.failed = True
            result.error = "Empty response from PumpAPI"
            logger.error(result.error)
            return result

        # Try to parse as JSON first (could be Jito bundle = array of base64 txs)
        try:
            b64_txs = orjson.loads(raw_bytes)
            if isinstance(b64_txs, list):
                # Jito bundle — multiple transactions
                return await self._execute_local_jito(b64_txs, payload, result)
        except Exception:
            pass  # Not JSON — it's raw transaction bytes (single tx)

        # Single transaction — raw VersionedTransaction bytes
        try:
            tx = VersionedTransaction.from_bytes(raw_bytes)
        except Exception as e:
            result.success = False
            result.failed = True
            result.error = f"Failed to deserialize tx: {e}"
            return result

        # Sign locally
        required_signers = list(tx.message.account_keys)[:tx.message.header.num_required_signatures]
        signatures = list(tx.signatures)

        if self._keypair.pubkey() in required_signers:
            signer_index = required_signers.index(self._keypair.pubkey())
            signatures[signer_index] = self._keypair.sign_message(
                to_bytes_versioned(tx.message)
            )

        signed_tx = VersionedTransaction.populate(tx.message, signatures)
        sig_str = str(signed_tx.signatures[0])

        # Duplicate check
        if sig_str in self._sent_signatures:
            result.success = False
            result.failed = True
            result.error = f"DUPLICATE_TX: {sig_str[:20]}"
            return result

        # Broadcast via RPC
        tx_bytes = bytes(signed_tx)
        tx_b64 = base64.b64encode(tx_bytes).decode("ascii")

        rpc_payload = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "sendTransaction",
            "params": [
                tx_b64,
                {"encoding": "base64", "preflightCommitment": "confirmed"},
            ],
        }

        async with self._rpc_http.post(
            config.SOLANA_RPC_URL,
            json=rpc_payload,
            headers={"Content-Type": "application/json"},
        ) as resp:
            rpc_data = orjson.loads(await resp.read())

        if "error" in rpc_data:
            result.success = False
            result.failed = True
            result.error = f"RPC error: {rpc_data['error']}"
            logger.error(result.error)
            return result

        tx_signature = rpc_data.get("result", "")
        if not tx_signature:
            result.success = False
            result.failed = True
            result.error = "No signature from RPC"
            return result

        self._sent_signatures.add(tx_signature)
        result.signature = tx_signature

        logger.info(
            f"📤 TX SENT (Local) | {tx_signature[:20]}.. | "
            f"action={payload['action']} mint={payload['mint'][:12]}.."
        )

        # Wait for confirmation
        confirmed = await self._wait_confirmation(tx_signature)
        result.confirmed = confirmed
        result.success = confirmed

        if confirmed:
            logger.info(f"✅ TX CONFIRMED | {tx_signature[:20]}..")
        else:
            result.failed = True
            result.error = "Transaction not confirmed within timeout"
            logger.warning(f"❌ TX NOT CONFIRMED | {tx_signature[:20]}..")

        # Costs
        result.priority_fee_paid = payload.get("priorityFee", config.PRIORITY_FEE_SOL)
        result.base_tx_fee = config.BASE_TX_FEE_SOL
        sol_amount = payload.get("amount", 0)
        if isinstance(sol_amount, (int, float)) and payload["action"] == "buy":
            result.sol_amount = float(sol_amount)
            result.pump_fee_paid = float(sol_amount) * config.PUMP_FEE_RATE

        return result

    async def _execute_local_jito(self, b64_txs: list, payload: dict,
                                   result: ExecutionResult) -> ExecutionResult:
        """Handle Jito bundle (multiple base64 transactions)."""
        jito_uuid = os.environ.get("JITO_UUID", "")
        if not jito_uuid:
            result.success = False
            result.failed = True
            result.error = "Jito bundle received but no JITO_UUID configured"
            return result

        signed_b64 = []
        all_sigs = []

        for b64_tx in b64_txs:
            tx_bytes = base64.b64decode(b64_tx)
            tx = VersionedTransaction.from_bytes(tx_bytes)

            required = list(tx.message.account_keys)[:tx.message.header.num_required_signatures]
            sigs = list(tx.signatures)

            if self._keypair.pubkey() in required:
                idx = required.index(self._keypair.pubkey())
                sigs[idx] = self._keypair.sign_message(to_bytes_versioned(tx.message))

            signed_tx = VersionedTransaction.populate(tx.message, sigs)
            all_sigs.append(str(signed_tx.signatures[0]))
            signed_b64.append(base64.b64encode(bytes(signed_tx)).decode("ascii"))

        # Send bundle to Jito
        jito_url = f"https://mainnet.block-engine.jito.wtf:443/api/v1/bundles?uuid={jito_uuid}"
        jito_payload = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "sendBundle",
            "params": [signed_b64, {"encoding": "base64"}],
        }

        async with self._http.post(
            jito_url, json=jito_payload,
            headers={"Content-Type": "application/json"},
        ) as resp:
            jito_data = orjson.loads(await resp.read())

        if "error" in jito_data:
            result.success = False
            result.failed = True
            result.error = f"Jito error: {jito_data['error']}"
            return result

        # Use first signature
        if all_sigs:
            result.signature = all_sigs[0]
            self._sent_signatures.update(all_sigs)

        # Wait for confirmation of first tx
        confirmed = await self._wait_confirmation(all_sigs[0]) if all_sigs else False
        result.confirmed = confirmed
        result.success = confirmed

        if confirmed:
            logger.info(f"✅ JITO BUNDLE CONFIRMED | {all_sigs[0][:20]}..")
        else:
            result.failed = True
            result.error = "Jito bundle not confirmed"

        result.priority_fee_paid = payload.get("priorityFee", config.PRIORITY_FEE_SOL)
        result.base_tx_fee = config.BASE_TX_FEE_SOL
        result.jito_tip_paid = config.JITO_TIP_SOL if config.JITO_ENABLED else 0

        return result

    async def _wait_confirmation(self, signature: str,
                                 timeout: float = 30.0) -> bool:
        """Poll RPC for transaction confirmation."""
        start = time.time()
        while time.time() - start < timeout:
            try:
                status = await self.check_tx_status(signature)
                if status["confirmed"]:
                    return True
                if status.get("err") and status["err"] != "not_found":
                    logger.error(f"TX failed: {status['err']}")
                    return False
            except Exception as e:
                logger.warning(f"Confirmation check error: {e}")
            await asyncio.sleep(1.5)

        return False
