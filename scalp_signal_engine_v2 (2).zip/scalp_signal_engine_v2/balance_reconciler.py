"""
Balance Reconciler — Compares internal position state with actual blockchain state.
Detects discrepancies between what we think we have and what's really on-chain.
"""
import asyncio
import logging
import time
from dataclasses import dataclass, field
from typing import Optional

import config
from execution_interface import BaseExecutor

logger = logging.getLogger("reconciler")


@dataclass
class Discrepancy:
    mint: str
    field: str            # "sol_balance", "token_balance"
    internal_value: float
    blockchain_value: float
    difference: float
    pct_difference: float
    timestamp: float = 0.0
    resolved: bool = False


class BalanceReconciler:
    """Periodically compares internal state with blockchain state."""

    def __init__(self, executor: BaseExecutor):
        self.executor = executor
        self._discrepancies: list[Discrepancy] = []
        self._last_check: float = 0.0
        self._running: bool = False
        self._check_count: int = 0
        self._mismatch_count: int = 0

    async def reconcile(self, internal_positions: dict) -> list[Discrepancy]:
        """
        Compare internal position state with blockchain.
        internal_positions: {mint: {"tokens": float, "sol_spent": float}}
        Returns list of discrepancies found.
        """
        found = []
        self._check_count += 1

        # Check SOL balance
        try:
            actual_sol = await self.executor.get_sol_balance()
        except Exception as e:
            logger.error(f"Reconciliation: SOL balance check failed: {e}")
            actual_sol = None

        # Check each position's token balance
        for mint, pos_data in internal_positions.items():
            internal_tokens = pos_data.get("tokens", 0)
            if internal_tokens <= 0:
                continue

            try:
                actual_tokens = await self.executor.get_token_balance(mint)
            except Exception as e:
                logger.error(f"Reconciliation: token balance check failed for {mint[:12]}: {e}")
                continue

            diff = internal_tokens - actual_tokens
            pct_diff = abs(diff) / max(internal_tokens, 0.001)

            if pct_diff > config.BALANCE_MISMATCH_THRESHOLD_PCT:
                disc = Discrepancy(
                    mint=mint,
                    field="token_balance",
                    internal_value=internal_tokens,
                    blockchain_value=actual_tokens,
                    difference=diff,
                    pct_difference=pct_diff,
                    timestamp=time.time(),
                )
                found.append(disc)
                self._mismatch_count += 1
                logger.warning(
                    f"⚠️  BALANCE MISMATCH: {mint[:12]}.. "
                    f"internal={internal_tokens:.2f} "
                    f"chain={actual_tokens:.2f} "
                    f"diff={diff:+.2f} ({pct_diff:.1%})"
                )

        self._discrepancies.extend(found)
        self._last_check = time.time()
        return found

    async def run_periodic(self, get_positions_fn, interval: float = None):
        """Run periodic reconciliation in background."""
        if interval is None:
            interval = config.RECONCILIATION_INTERVAL_SEC
        self._running = True

        while self._running:
            await asyncio.sleep(interval)
            try:
                positions = get_positions_fn()
                discrepancies = await self.reconcile(positions)
                if discrepancies:
                    logger.warning(f"Reconciliation found {len(discrepancies)} mismatches")
            except Exception as e:
                logger.error(f"Reconciliation error: {e}")

    def stop(self):
        self._running = False

    def get_discrepancies(self, unresolved_only: bool = True) -> list[Discrepancy]:
        if unresolved_only:
            return [d for d in self._discrepancies if not d.resolved]
        return self._discrepancies

    @property
    def stats(self) -> dict:
        return {
            "checks": self._check_count,
            "mismatches": self._mismatch_count,
            "unresolved": len(self.get_discrepancies(unresolved_only=True)),
            "last_check": self._last_check,
        }
