#!/usr/bin/env python3
"""
Quick smoke test — verifies all core components with synthetic data.
"""
import asyncio
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import time
import config
from feature_engine import FeatureEngine
from entry_engine import EntryEngine
from exit_engine import ExitEngine
from pnl_simulator import PnLSimulator
from position_manager import PositionManager
from signal_analyzer import SignalAnalyzer
from mint_recorder import MintRecorder
from latency import LatencyTracker


def test_feature_engine():
    """Test feature computation with synthetic events."""
    print("=" * 50)
    print("TEST: Feature Engine")
    print("=" * 50)

    fe = FeatureEngine()
    mint = "TestMint123456789"

    # Simulate a series of buy events
    base_ts = int(time.time() * 1000)
    events = [
        {"mint": mint, "action": "create", "timestamp": base_ts,
         "price": 1e-7, "marketCapQuote": 10000, "tokenAmount": 1000000,
         "quoteAmount": 0.1, "vQuoteInBondingCurve": 10.0,
         "tradersInvolved": {"creator_wallet": {}}, "txSigner": "creator_wallet",
         "supply": 1e9, "poolFeeRate": 0.0125, "pool": "pump"},
    ]

    # Add buy events over 30 seconds
    for i in range(20):
        ts = base_ts + (i + 1) * 1500  # 1.5s apart
        events.append({
            "mint": mint, "action": "buy", "timestamp": ts,
            "price": 1e-7 * (1 + i * 0.02),  # price increasing
            "marketCapQuote": 15000 + i * 500,
            "tokenAmount": 500000 + i * 10000,
            "quoteAmount": 0.5 + i * 0.1,
            "vQuoteInBondingCurve": 10.0 + i * 0.5,
            "tradersInvolved": {f"buyer_{i % 8}": {}},
            "poolFeeRate": 0.0125, "pool": "pump",
            "breakdown": [
                {"action": "buy", "trader": f"buyer_{i % 8}",
                 "tokenAmount": 500000 + i * 10000, "quoteAmount": 0.5 + i * 0.1}
            ],
        })

    # Add a couple sell events
    for i in range(3):
        ts = base_ts + 32000 + i * 2000
        events.append({
            "mint": mint, "action": "sell", "timestamp": ts,
            "price": 1e-7 * 1.35,
            "marketCapQuote": 18000,
            "tokenAmount": 200000,
            "quoteAmount": 0.3,
            "vQuoteInBondingCurve": 18.0,
            "tradersInvolved": {f"seller_{i}": {}},
            "poolFeeRate": 0.0125, "pool": "pump",
        })

    features = None
    for event in events:
        features = fe.update_from_event(event)

    assert features is not None, "Features should be computed"
    assert features.price > 0, f"Price should be > 0, got {features.price}"
    assert features.buy_count > 0, f"Buy count should be > 0"
    assert features.unique_buyers > 0, f"Unique buyers should be > 0"
    assert features.market_cap > 0, f"MC should be > 0, got {features.market_cap}"

    print(f"  Price: {features.price:.2e}")
    print(f"  MC: {features.market_cap:.0f} (zone: {features.mc_zone})")
    print(f"  Buy/Sell Ratio: {features.buy_sell_ratio:.2f}")
    print(f"  Buy Count: {features.buy_count}")
    print(f"  Sell Count: {features.sell_count}")
    print(f"  Volume 10s: {features.volume_10s:.2f}")
    print(f"  Vol Acceleration: {features.volume_acceleration:.3f}")
    print(f"  Unique Buyers: {features.unique_buyers}")
    print(f"  New Buyer Velocity: {features.new_buyer_velocity:.2f}")
    print(f"  Liquidity: {features.liquidity:.1f}")
    print(f"  Slippage: {features.estimated_slippage:.4f}")
    print(f"  Consecutive Buys: {features.consecutive_buys}")
    print(f"  Consecutive Sells: {features.consecutive_sells}")
    print(f"  Wallet Concentration: {features.wallet_concentration:.2f}")
    print(f"  Compact: {features.compact_str()}")
    print("  ✅ Feature Engine PASSED\n")


def test_entry_engine():
    """Test deterministic entry filter."""
    print("=" * 50)
    print("TEST: Entry Engine (Deterministic Filter)")
    print("=" * 50)

    from feature_engine import MintFeatures

    # Good candidate
    good = MintFeatures(
        mint="test", price=1e-7, market_cap=17000,
        buy_sell_ratio=3.5, volume_acceleration=1.2,
        new_buyer_velocity=2.0, consecutive_buys=5,
        price_change_5s=0.05, liquidity=15.0,
        estimated_slippage=0.01, wallet_concentration=0.3,
        pool_fee_rate=0.0125, tx_velocity=2.0, unique_buyers=8,
    )

    # Bad candidate
    bad = MintFeatures(
        mint="test2", price=1e-7, market_cap=5000,
        buy_sell_ratio=0.5, volume_acceleration=-0.5,
        new_buyer_velocity=0.1, consecutive_buys=0,
        price_change_5s=-0.02, liquidity=2.0,
        estimated_slippage=0.08, wallet_concentration=0.8,
        pool_fee_rate=0.0125, tx_velocity=0.3, unique_buyers=2,
    )

    # Test without Qwen (deterministic only)
    engine = EntryEngine(None)

    # Good candidate
    is_cand, score, reasons = engine.deterministic_filter(good)
    print(f"  Good candidate: is_candidate={is_cand}, score={score:.3f}")
    print(f"    Reasons: {reasons}")
    assert is_cand, "Good candidate should pass filter"
    assert score > 0.4, f"Score should be > 0.4, got {score}"

    # Bad candidate
    is_cand, score, reasons = engine.deterministic_filter(bad)
    print(f"  Bad candidate: is_candidate={is_cand}, score={score:.3f}")
    print(f"    Reasons: {reasons}")
    assert not is_cand, "Bad candidate should fail filter"

    print("  ✅ Entry Engine PASSED\n")


def test_pnl_simulator():
    """Test PnL computation."""
    print("=" * 50)
    print("TEST: PnL Simulator")
    print("=" * 50)

    sim = PnLSimulator()

    # Entry at MC=17000, price=1.7e-7
    entry = sim.compute_entry(
        sol_amount=0.1, price=1.7e-7, liquidity=15.0, mc=17000,
    )
    print(f"  Entry:")
    print(f"    SOL spent: {entry['sol_spent']:.4f}")
    print(f"    Tokens received: {entry['tokens_received']:.2f}")
    print(f"    Slippage: {entry['slippage_pct']:.4f}")
    print(f"    Costs: {entry['costs'].total:.6f} SOL")
    print(f"      Pump fee: {entry['costs'].pump_fee:.6f}")
    print(f"      Priority: {entry['costs'].priority_fee:.6f}")
    print(f"      Jito:     {entry['costs'].jito_tip:.6f}")
    print(f"      ATA:      {entry['costs'].ata_rent:.6f}")

    # Exit at +20% price
    exit_price = 1.7e-7 * 1.20
    pnl = sim.compute_exit(
        tokens=entry["tokens_received"],
        price=exit_price, liquidity=20.0, mc=20400,
        entry_info=entry,
    )
    pnl.hold_time_sec = 45.0

    print(f"\n  Exit:")
    print(f"    SOL received: {pnl.exit_sol:.6f}")
    print(f"    Gross PnL: {pnl.gross_pnl:+.6f} SOL")
    print(f"    Entry Costs: -{pnl.entry_costs.total:.6f} SOL")
    print(f"    Exit Costs:  -{pnl.exit_costs.total:.6f} SOL")
    print(f"    NET PnL: {pnl.net_pnl:+.6f} SOL")
    print(f"    ROI: {pnl.roi:+.2%}")

    assert pnl.gross_pnl > 0, "Gross PnL should be positive for +20% price"
    assert pnl.net_pnl < pnl.gross_pnl, "NET should be less than gross due to costs"

    # Summary
    summary = sim.get_summary()
    print(f"\n  Summary: {summary}")
    print("  ✅ PnL Simulator PASSED\n")


def test_exit_engine():
    """Test exit decisions."""
    print("=" * 50)
    print("TEST: Exit Engine")
    print("=" * 50)

    from feature_engine import MintFeatures

    engine = ExitEngine()

    # Scenario 1: Strong momentum — should HOLD
    strong = MintFeatures(
        mint="test", price=2e-7, market_cap=20000,
        buy_sell_ratio=3.0, volume_acceleration=0.8,
        price_change_5s=0.08, consecutive_sells=0,
        liquidity_change=0.1, new_buyer_velocity=2.0,
        unique_buyers=5, whale_activity=0.1,
        estimated_slippage=0.01, sell_volume=1.0, buy_volume=3.0,
    )
    sig = engine.evaluate(strong, entry_price=1.7e-7, entry_liquidity=15.0,
                         hold_time=30.0, current_pnl_pct=0.15)
    print(f"  Strong momentum: {sig.action} (score={sig.score:.2f})")
    print(f"    Reasons: {sig.reasons}")
    assert sig.action == "HOLD", f"Should HOLD on strong momentum, got {sig.action}"

    # Scenario 2: Sell pressure + momentum reversal — should SELL
    weak = MintFeatures(
        mint="test2", price=1.5e-7, market_cap=15000,
        buy_sell_ratio=0.4, volume_acceleration=-0.5,
        price_change_5s=-0.05, consecutive_sells=5,
        liquidity_change=-0.25, new_buyer_velocity=0.05,
        unique_buyers=1, whale_activity=0.4,
        estimated_slippage=0.03, sell_volume=5.0, buy_volume=2.0,
    )
    sig = engine.evaluate(weak, entry_price=1.7e-7, entry_liquidity=15.0,
                         hold_time=60.0, current_pnl_pct=-0.08)
    print(f"  Weak market: {sig.action} (score={sig.score:.2f})")
    print(f"    Reasons: {sig.reasons}")
    assert sig.action == "SELL", f"Should SELL on weak market, got {sig.action}"

    print("  ✅ Exit Engine PASSED\n")


def test_mint_recorder():
    """Test mint lifecycle recording."""
    print("=" * 50)
    print("TEST: Mint Recorder")
    print("=" * 50)

    recorder = MintRecorder()

    events = [
        {"mint": "abc123", "action": "create", "timestamp": int(time.time() * 1000),
         "name": "TestCoin", "symbol": "TEST", "poolId": "pool1", "pool": "pump",
         "txSigner": "creator1", "supply": 1e9, "decimals": 6,
         "price": 1e-7, "marketCapQuote": 10000},
        {"mint": "abc123", "action": "buy", "timestamp": int(time.time() * 1000) + 5000,
         "price": 1.1e-7, "marketCapQuote": 11000,
         "tokenAmount": 500000, "quoteAmount": 0.5,
         "tradersInvolved": {"buyer1": {}},
         "breakdown": [{"action": "buy", "trader": "buyer1",
                       "tokenAmount": 500000, "quoteAmount": 0.5}]},
    ]

    async def test():
        for ev in events:
            await recorder.record_event(ev)
        lc = recorder.get_mint("abc123")
        assert lc is not None, "Mint should be recorded"
        assert lc.name == "TestCoin"
        assert lc.symbol == "TEST"
        assert len(lc.trade_history) >= 1
        print(f"  Mint: {lc.mint}")
        print(f"  Name: {lc.name} ({lc.symbol})")
        print(f"  Events: {len(lc.events)}")
        print(f"  Trades: {len(lc.trade_history)}")
        print(f"  Price history: {len(lc.price_history)} points")

        # Save and load
        await recorder.save_mint("abc123")
        loaded = MintRecorder.load_mint("abc123")
        assert loaded is not None, "Should load saved mint"
        print(f"  Saved and loaded successfully")
        print("  ✅ Mint Recorder PASSED\n")

    asyncio.run(test())


def test_signal_analyzer():
    """Test signal analysis."""
    print("=" * 50)
    print("TEST: Signal Analyzer")
    print("=" * 50)

    analyzer = SignalAnalyzer()

    # Add synthetic trade records
    for i in range(50):
        bsr = 1.0 + (i % 5) * 0.5
        va = -0.5 + (i % 4) * 0.5
        liq = 3.0 + (i % 6) * 3.0
        # Higher BSR and VA tend to be profitable
        pnl = 0.001 * (bsr - 1.5) + 0.0005 * va + (0.002 if liq > 10 else -0.001)
        pnl += (i % 3 - 1) * 0.001  # noise

        analyzer.record_trade(
            entry_features={
                "buy_sell_ratio": bsr,
                "volume_acceleration": va,
                "liquidity": liq,
                "new_buyer_velocity": 1.0 + (i % 3),
                "consecutive_buys": i % 6,
                "estimated_slippage": 0.01 + (i % 4) * 0.01,
                "wallet_concentration": 0.2 + (i % 5) * 0.1,
                "price_change_5s": 0.01 * (i % 5),
                "unique_buyers": 3 + (i % 8),
            },
            exit_features={},
            net_pnl=pnl,
            roi=pnl / 0.1,
        )

    analyses = analyzer.analyze_all()
    print(f"  Analyzed {len(analyses)} features")
    for name, results in analyses.items():
        if results:
            best = max(results, key=lambda r: r.avg_pnl)
            print(f"  {name}: best threshold {best.direction}{best.threshold:.2f} "
                  f"→ WR={best.win_rate:.0%} avg={best.avg_pnl:+.5f}")

    combos = analyzer.analyze_combinations()
    print(f"  Tested {len(combos)} combinations")
    for c in combos:
        print(f"    {c.feature_name}: trades={c.trades} WR={c.win_rate:.0%} avg={c.avg_pnl:+.5f}")

    print("  ✅ Signal Analyzer PASSED\n")


if __name__ == "__main__":
    print("\n🧪 SCALP SIGNAL ENGINE — SMOKE TESTS\n")
    test_feature_engine()
    test_entry_engine()
    test_pnl_simulator()
    test_exit_engine()
    test_mint_recorder()
    test_signal_analyzer()
    print("\n✅ ALL TESTS PASSED!")
