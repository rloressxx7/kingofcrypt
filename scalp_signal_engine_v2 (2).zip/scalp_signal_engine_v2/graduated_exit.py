"""
Graduated Exit Engine — Time-based rapid partial selling.
Modeled after wallet: 2CQgjcdNEo7WtbQLpJTAVcC3Ga61pNvRDTgP5grzctFG

Strategy (from on-chain analysis):
  - After entry, immediately start selling in 4 equal chunks
  - Each chunk sold ~5 seconds apart
  - 25% → 25% → 25% → 25% (remaining + close ATA)
  - NO profit target waiting — sell immediately and continuously
  - Emergency/stop-loss → sell ALL remaining instantly

This matches the trader's actual on-chain behavior:
  Sell 1.26 SOL → Sell 0.68 SOL → Sell 0.52 SOL (closeAccount)
  All within 1-2 minutes of buying.
"""
import logging
import time
from dataclasses import dataclass
from enum import Enum
from typing import Optional

logger = logging.getLogger("grad_exit")


class ExitPhase(int, Enum):
    WAITING = 0     # Position just opened, waiting for first sell
    CHUNK1 = 1      # Sold 25%
    CHUNK2 = 2      # Sold 50% total
    CHUNK3 = 3      # Sold 75% total
    CHUNK4 = 4      # Sold 100% (fully exited, ATA closed)


@dataclass
class GradState:
    """Tracks graduated exit state for one position."""
    mint: str
    phase: ExitPhase = ExitPhase.WAITING
    original_tokens: float = 0.0
    remaining_tokens: float = 0.0
    total_sol_received: float = 0.0
    entry_time: float = 0.0
    last_sell_time: float = 0.0
    sell_count: int = 0
    
    @property
    def sold_pct(self) -> float:
        if self.original_tokens <= 0:
            return 0.0
        return 1.0 - (self.remaining_tokens / self.original_tokens)
    
    @property
    def is_done(self) -> bool:
        return self.phase == ExitPhase.CHUNK4 or self.remaining_tokens <= 0


# ── Configuration ──────────────────────────────────────────────────────
SELL_INTERVAL_SEC = 5       # Seconds between each chunk sell
CHUNK_PCT = 0.25            # Sell 25% per chunk
NUM_CHUNKS = 4              # 4 chunks = 100%
FIRST_SELL_DELAY_SEC = 3    # First sell after 3 seconds from entry


class GradExitManager:
    """Manages time-based graduated exits."""
    
    def __init__(self):
        self._states: dict[str, GradState] = {}
        self._total_sells = 0
    
    def register(self, mint: str, token_amount: float, entry_time: float = None):
        """Register a new position for graduated selling."""
        now = entry_time or time.time()
        self._states[mint] = GradState(
            mint=mint,
            original_tokens=token_amount,
            remaining_tokens=token_amount,
            entry_time=now,
            last_sell_time=now,
        )
        logger.info(
            f"📊 GRAD REGISTERED: {mint[:12]}.. "
            f"tokens={token_amount:.2f} | "
            f"will sell {NUM_CHUNKS}x{CHUNK_PCT:.0%} every {SELL_INTERVAL_SEC}s"
        )
    
    def should_sell(self, mint: str, now: float = None) -> Optional[dict]:
        """
        Check if it's time to sell the next chunk.
        
        Returns:
            dict with sell info if should sell, None otherwise.
            {
                "phase": ExitPhase,
                "sell_tokens": float,
                "is_final": bool,  # True if this is the last chunk
                "reason": str,
            }
        """
        state = self._states.get(mint)
        if not state or state.is_done:
            return None
        
        now = now or time.time()
        next_phase = ExitPhase(state.phase + 1)
        
        # First sell: wait FIRST_SELL_DELAY_SEC after entry
        if state.phase == ExitPhase.WAITING:
            if now - state.entry_time < FIRST_SELL_DELAY_SEC:
                return None  # Not yet time
        else:
            # Subsequent sells: wait SELL_INTERVAL_SEC between sells
            if now - state.last_sell_time < SELL_INTERVAL_SEC:
                return None  # Not yet time
        
        # Calculate how many tokens to sell
        if next_phase == ExitPhase.CHUNK4:
            # Final chunk: sell ALL remaining
            sell_tokens = state.remaining_tokens
            is_final = True
        else:
            # Regular chunk: sell CHUNK_PCT of original
            sell_tokens = state.original_tokens * CHUNK_PCT
            sell_tokens = min(sell_tokens, state.remaining_tokens)
            is_final = False
        
        reason = f"chunk{next_phase.value}_time={now - state.entry_time:.0f}s"
        
        logger.info(
            f"💰 GRAD SELL #{next_phase.value}: {mint[:12]}.. "
            f"sell={sell_tokens:.2f} tokens ({CHUNK_PCT:.0%}) | "
            f"remaining_after={state.remaining_tokens - sell_tokens:.2f} | "
            f"final={is_final} | {reason}"
        )
        
        return {
            "phase": next_phase,
            "sell_tokens": sell_tokens,
            "is_final": is_final,
            "reason": reason,
        }
    
    def record_sell(self, mint: str, phase: ExitPhase, 
                    tokens_sold: float, sol_received: float):
        """Record a completed chunk sell."""
        state = self._states.get(mint)
        if not state:
            return
        
        state.remaining_tokens -= tokens_sold
        state.total_sol_received += sol_received
        state.phase = phase
        state.last_sell_time = time.time()
        state.sell_count += 1
        self._total_sells += 1
        
        logger.info(
            f"✅ CHUNK {phase.value}/4 SOLD: {mint[:12]}.. "
            f"sold={tokens_sold:.2f} SOL={sol_received:.4f} | "
            f"remaining={state.remaining_tokens:.2f} ({state.sold_pct:.0%} sold) | "
            f"total_SOL={state.total_sol_received:.4f}"
        )
    
    def force_sell_all(self, mint: str) -> Optional[dict]:
        """Emergency: sell ALL remaining tokens immediately."""
        state = self._states.get(mint)
        if not state or state.is_done:
            return None
        
        if state.remaining_tokens <= 0:
            return None
        
        sell_tokens = state.remaining_tokens
        
        logger.info(
            f"🚨 FORCE SELL ALL: {mint[:12]}.. "
            f"sell={sell_tokens:.2f} tokens (already sold {state.sold_pct:.0%})"
        )
        
        return {
            "phase": ExitPhase.CHUNK4,
            "sell_tokens": sell_tokens,
            "is_final": True,
            "reason": "force_sell_all",
        }
    
    def get_state(self, mint: str) -> Optional[GradState]:
        return self._states.get(mint)
    
    def cleanup(self, mint: str):
        self._states.pop(mint, None)
    
    @property
    def stats(self) -> dict:
        active = sum(1 for s in self._states.values() if not s.is_done)
        done = sum(1 for s in self._states.values() if s.is_done)
        return {
            "active_grad_positions": active,
            "completed_grad_exits": done,
            "total_chunk_sells": self._total_sells,
        }
