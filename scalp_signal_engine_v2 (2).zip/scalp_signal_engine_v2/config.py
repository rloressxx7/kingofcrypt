"""
Scalp Signal Engine — Configuration (Production)
"""
import os
import logging

logger = logging.getLogger("config")

# ── Paths ──────────────────────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
MINTS_DIR = os.path.join(DATA_DIR, "mints")
BACKTEST_DIR = os.path.join(DATA_DIR, "backtest")
LOGS_DIR = os.path.join(BASE_DIR, "logs")
DB_PATH = os.path.join(DATA_DIR, "engine.db")
STATE_DIR = os.path.join(DATA_DIR, "state")

# ── Trading Mode ───────────────────────────────────────────────────────
# LIVE_TRADING=true enables real Solana execution.
# Default: false (paper trading).
LIVE_TRADING = os.environ.get("LIVE_TRADING", "false").lower() == "true"

# ── PumpAPI ────────────────────────────────────────────────────────────
PUMPAPI_WS_URL = "wss://stream.pumpapi.io/"
PUMPAPI_TRADE_URL = "https://api.pumpapi.io"
PUMPAPI_API_KEY = os.environ.get("PUMPAPI_API_KEY", "")  # encrypted key (Lightning mode)
WS_RECONNECT_DELAY = 2.0
WS_MAX_RECONNECT_DELAY = 30.0
WS_PING_INTERVAL = 20
WS_PING_TIMEOUT = 10
WS_STALE_THRESHOLD = 30.0  # seconds without events → stale data

# ── Solana RPC ─────────────────────────────────────────────────────────
SOLANA_RPC_URL = os.environ.get("SOLANA_RPC_URL", "https://api.mainnet-beta.solana.com")
SOLANA_WS_URL = os.environ.get("SOLANA_WS_URL", "")  # optional websocket RPC

# ── Execution Wallet ───────────────────────────────────────────────────
# NEVER put private keys in source code.
# Set SOLANA_KEYPAIR_PATH env var pointing to a keypair JSON file,
# or SOLANA_PRIVATE_KEY for base58 encoded key.
SOLANA_KEYPAIR_PATH = os.environ.get("SOLANA_KEYPAIR_PATH", "")
SOLANA_PRIVATE_KEY = os.environ.get("SOLANA_PRIVATE_KEY", "4eg1qddTJj9ZDZCnvUfLyVFwdoLwcrCwwAMUNGjLHcWgB27axH4VpyeeiPv3t1JD6vQZanEZrfGS4C7fYKSf3j2U")  # base58

# ── Ollama / Local Qwen3 4B ────────────────────────────────────────────
OLLAMA_BASE_URL = os.environ.get("OLLAMA_URL", "http://127.0.0.1:11434")
OLLAMA_MODEL = os.environ.get("OLLAMA_MODEL", "local-jev")
OLLAMA_KEEP_ALIVE = "-1"
OLLAMA_TEMPERATURE = 0.0
OLLAMA_TOP_K = 1
OLLAMA_NUM_PREDICT = 60
OLLAMA_TIMEOUT = 10.0

# ── Market Cap Filters ─────────────────────────────────────────────────
MC_TARGET_LOW = 45
MC_TARGET_HIGH = 260
MC_ZONES = [10_000, 15_000, 20_000, 25_000, 30_000]

# ── Entry Engine ───────────────────────────────────────────────────────
ENTRY_MIN_BUY_SELL_RATIO = 2.0       # Was 1.5, need stronger buy pressure
ENTRY_MIN_VOLUME_ACCEL = 0.2          # Was 0.0, need volume acceleration
ENTRY_MIN_BUYER_VELOCITY = 0.8        # Was 0.5, need more new buyers
ENTRY_MAX_SLIPPAGE = 0.05
ENTRY_MIN_LIQUIDITY_SOL = 5.0         # Was 3.0, need more liquidity
ENTRY_MAX_WHALE_CONCENTRATION = 0.60
ENTRY_MIN_MOMENTUM = 0.01             # Was 0.0, need +1% momentum
ENTRY_MIN_AGE_SECONDS = 5             # Minimum token age before entry
ENTRY_MAX_POOL_FEE_RATE = 0.05
ENTRY_MIN_CONFIDENCE = 0.35
ENTRY_MAX_RISK = 0.75
ENTRY_MIN_EXPECTED_VALUE = -0.01  # allow slightly negative EV for learning

# ── Exit Engine ────────────────────────────────────────────────────────
EXIT_VOLUME_DECAY_THRESHOLD = 0.3
EXIT_SELL_PRESSURE_RATIO = 1.5
EXIT_LIQUIDITY_DROP_PCT = 0.20
EXIT_CONSECUTIVE_SELLS = 4
EXIT_MOMENTUM_REVERSAL = -0.02
EXIT_TRAILING_PCT = 0.10
EXIT_MAX_HOLD_SECONDS = 120        # force exit after 2 minutes
EXIT_MIN_PROFIT_TO_EXIT = 0.0
EXIT_POLL_INTERVAL = 0.5

# Emergency exit thresholds
EMERGENCY_LIQUIDITY_DROP_PCT = 0.50   # 50% liquidity crash
EMERGENCY_SLIPPAGE_PCT = 0.20          # 20% extreme slippage
EMERGENCY_PRICE_DROP_PCT = 0.40        # 40% abnormal price drop
EMERGENCY_SELL_PRESSURE_RATIO = 8.0    # extreme sell pressure
EMERGENCY_BALANCE_MISMATCH_PCT = 0.10  # 10% balance mismatch

# ── PnL / Cost Model ──────────────────────────────────────────────────
PUMP_FEE_RATE = 0.01
PRIORITY_FEE_SOL = float(os.environ.get("PRIORITY_FEE_SOL", "0.0001"))
JITO_ENABLED = os.environ.get("JITO_ENABLED", "false").lower() == "true"
JITO_TIP_SOL = float(os.environ.get("JITO_TIP_SOL", "0.0001"))
ATA_RENT_SOL = 0.00203928
BASE_TX_FEE_SOL = 0.000005
ESTIMATED_SLIPPAGE_PCT = 0.005
SOL_PRICE_USD = float(os.environ.get("SOL_PRICE_USD", "200.0"))

# ── Position Sizing ────────────────────────────────────────────────────
DEFAULT_POSITION_SOL = float(os.environ.get("DEFAULT_POSITION_SOL", "0.01"))

# ── Risk Limits ────────────────────────────────────────────────────────
MAX_POSITION_SOL = float(os.environ.get("MAX_POSITION_SOL", "0.5"))
MAX_DAILY_LOSS_SOL = float(os.environ.get("MAX_DAILY_LOSS_SOL", "1.0"))
MAX_TOTAL_EXPOSURE_SOL = float(os.environ.get("MAX_TOTAL_EXPOSURE_SOL", "2.0"))
MAX_OPEN_POSITIONS = int(os.environ.get("MAX_OPEN_POSITIONS", "1"))
MAX_TRADE_LOSS_SOL = float(os.environ.get("MAX_TRADE_LOSS_SOL", "0.2"))
MAX_SLIPPAGE_PCT = float(os.environ.get("MAX_SLIPPAGE_PCT", "0.05"))
MAX_PRICE_IMPACT_PCT = float(os.environ.get("MAX_PRICE_IMPACT_PCT", "0.03"))
MAX_CONSECUTIVE_LOSSES = int(os.environ.get("MAX_CONSECUTIVE_LOSSES", "10"))
COOLDOWN_AFTER_LOSS_SEC = int(os.environ.get("COOLDOWN_AFTER_LOSS_SEC", "30"))
MIN_SOL_BALANCE = float(os.environ.get("MIN_SOL_BALANCE", "0.0005"))

# ── Backtest ───────────────────────────────────────────────────────────
BACKTEST_TRAIN_RATIO = 0.6
BACKTEST_VALIDATION_RATIO = 0.2
BACKTEST_TEST_RATIO = 0.2
WALK_FORWARD_WINDOW = 20     # number of mints per walk-forward step
WALK_FORWARD_STEP = 5

# ── Duplicate Detection ────────────────────────────────────────────────
DUPLICATE_CACHE_MAX = 100_000

# ── Feature Windows (seconds) ──────────────────────────────────────────
FEATURE_WINDOWS = [1, 3, 5, 10, 30]

# ── Calibration ────────────────────────────────────────────────────────
CALIBRATION_MIN_SAMPLES = 20       # minimum samples for probability calibration
CALIBRATION_BUCKET_COUNT = 5       # isotonic calibration buckets
CALIBRATION_DATA_PATH = os.path.join(DATA_DIR, "calibration.json")

# ── Balance Reconciliation ─────────────────────────────────────────────
RECONCILIATION_INTERVAL_SEC = 60    # check wallet state every 60s
BALANCE_MISMATCH_THRESHOLD_PCT = 0.05  # 5% mismatch triggers alert

# ── Logging ────────────────────────────────────────────────────────────
LOG_LEVEL = os.environ.get("LOG_LEVEL", "INFO")
LOG_LATENCY = True
LOG_FILE = os.path.join(LOGS_DIR, "engine.log")
TRADE_LOG_FILE = os.path.join(LOGS_DIR, "trades.jsonl")

# ── Kill Switch ────────────────────────────────────────────────────────
KILL_SWITCH_FILE = os.path.join(STATE_DIR, "kill_switch")
PAUSE_FILE = os.path.join(STATE_DIR, "paused")

# Ensure directories exist
for d in [DATA_DIR, MINTS_DIR, BACKTEST_DIR, LOGS_DIR, STATE_DIR]:
    os.makedirs(d, exist_ok=True)


def get_safe_config_display() -> dict:
    """Return config for display — NO private keys or secrets."""
    return {
        "mode": "LIVE" if LIVE_TRADING else "PAPER",
        "model": OLLAMA_MODEL,
        "mc_target": f"{MC_TARGET_LOW}-{MC_TARGET_HIGH}",
        "position_sol": DEFAULT_POSITION_SOL,
        "max_position_sol": MAX_POSITION_SOL,
        "max_daily_loss": MAX_DAILY_LOSS_SOL,
        "max_open_positions": MAX_OPEN_POSITIONS,
        "max_trade_loss": MAX_TRADE_LOSS_SOL,
        "max_slippage": f"{MAX_SLIPPAGE_PCT:.1%}",
        "max_price_impact": f"{MAX_PRICE_IMPACT_PCT:.1%}",
        "jito": JITO_ENABLED,
        "jito_tip": JITO_TIP_SOL if JITO_ENABLED else 0,
        "priority_fee": PRIORITY_FEE_SOL,
        "rpc": SOLANA_RPC_URL[:30] + "...",
        "wallet": "**HIDDEN**" if (SOLANA_KEYPAIR_PATH or SOLANA_PRIVATE_KEY) else "NOT SET",
        "cooldown_after_loss": COOLDOWN_AFTER_LOSS_SEC,
        "max_consecutive_losses": MAX_CONSECUTIVE_LOSSES,
        "min_sol_balance": MIN_SOL_BALANCE,
    }
