"""
Latency tracker — measures ms at each pipeline stage.
"""
import time
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class LatencyRecord:
    event_received: float = 0.0
    feature_ready: float = 0.0
    filter_done: float = 0.0
    model_request: float = 0.0
    model_response: float = 0.0
    decision: float = 0.0
    mint: str = ""
    action: str = ""

    @property
    def total_ms(self) -> float:
        if self.event_received and self.decision:
            return (self.decision - self.event_received) * 1000
        return 0.0

    @property
    def feature_ms(self) -> float:
        if self.event_received and self.feature_ready:
            return (self.feature_ready - self.event_received) * 1000
        return 0.0

    @property
    def filter_ms(self) -> float:
        if self.feature_ready and self.filter_done:
            return (self.filter_done - self.feature_ready) * 1000
        return 0.0

    @property
    def model_ms(self) -> float:
        if self.model_request and self.model_response:
            return (self.model_response - self.model_request) * 1000
        return 0.0

    def summary(self) -> str:
        return (
            f"[LATENCY] mint={self.mint[:8]}.. "
            f"total={self.total_ms:.1f}ms "
            f"feat={self.feature_ms:.1f}ms "
            f"filter={self.filter_ms:.1f}ms "
            f"model={self.model_ms:.1f}ms"
        )


class LatencyTracker:
    """Thread-safe latency tracker for recent events."""

    def __init__(self, max_records: int = 1000):
        self._records: list[LatencyRecord] = []
        self._max = max_records

    def new(self) -> LatencyRecord:
        rec = LatencyRecord(event_received=time.time())
        return rec

    def record(self, rec: LatencyRecord):
        self._records.append(rec)
        if len(self._records) > self._max:
            self._records = self._records[-self._max:]

    def stats(self) -> dict:
        if not self._records:
            return {"count": 0}
        totals = [r.total_ms for r in self._records if r.total_ms > 0]
        feats = [r.feature_ms for r in self._records if r.feature_ms > 0]
        models = [r.model_ms for r in self._records if r.model_ms > 0]
        return {
            "count": len(self._records),
            "avg_total_ms": sum(totals) / len(totals) if totals else 0,
            "max_total_ms": max(totals) if totals else 0,
            "avg_feature_ms": sum(feats) / len(feats) if feats else 0,
            "avg_model_ms": sum(models) / len(models) if models else 0,
        }
