"""
Backtest Engine — Replay saved mint data through the full pipeline.
Supports train/validation/test splits and strategy comparison.
"""
import asyncio
import json
import logging
import os
import time
from dataclasses import dataclass, field
from typing import Optional

import orjson

import config
from feature_engine import FeatureEngine, MintFeatures
from entry_engine import EntryEngine
from exit_engine import ExitEngine
from position_manager import PositionManager
from pnl_simulator import PnLSimulator
from qwen_client import QwenClient

logger = logging.getLogger("backtest")


@dataclass
class BacktestResult:
    mint: str
    strategy_name: str
    trades: int = 0
    profitable: int = 0
    losses: int = 0
    total_gross_pnl: float = 0.0
    total_net_pnl: float = 0.0
    total_costs: float = 0.0
    avg_trade: float = 0.0
    median_trade: float = 0.0
    max_drawdown: float = 0.0
    avg_hold_time: float = 0.0
    win_rate: float = 0.0
    best_trade: float = 0.0
    worst_trade: float = 0.0
    split: str = "train"  # train/validation/test

    def to_dict(self) -> dict:
        return self.__dict__

    def summary(self) -> str:
        return (
            f"═══ Backtest: {self.mint[:16]}.. [{self.strategy_name}] ({self.split}) ═══\n"
            f"Trades: {self.trades}\n"
            f"Profitable: {self.profitable} | Losses: {self.losses}\n"
            f"Win Rate: {self.win_rate:.1%}\n"
            f"Total Gross PnL: {self.total_gross_pnl:+.6f} SOL\n"
            f"Total Costs:     -{self.total_costs:.6f} SOL\n"
            f"Total NET PnL:   {self.total_net_pnl:+.6f} SOL\n"
            f"Avg Trade:       {self.avg_trade:+.6f} SOL\n"
            f"Median Trade:    {self.median_trade:+.6f} SOL\n"
            f"Max Drawdown:    {self.max_drawdown:.6f} SOL\n"
            f"Best:            {self.best_trade:+.6f} SOL\n"
            f"Worst:           {self.worst_trade:+.6f} SOL\n"
            f"Avg Hold:        {self.avg_hold_time:.1f}s"
        )


class BacktestEngine:
    """Replays mint lifecycle data through the signal engine."""

    def __init__(self, use_qwen: bool = True):
        self.use_qwen = use_qwen
        self.qwen = QwenClient() if use_qwen else None
        self.feature_engine = FeatureEngine()
        self.entry_engine = EntryEngine(self.qwen) if self.qwen else None
        self.exit_engine = ExitEngine()
        self.pnl_sim = PnLSimulator()
        self.pos_manager: Optional[PositionManager] = None
        self._results: list[BacktestResult] = []

    async def run_mint(self, mint_data: dict, strategy_name: str = "default",
                       split: str = "train") -> BacktestResult:
        """
        Run backtest on a single mint's lifecycle data.
        mint_data: loaded JSON from mint recorder.
        """
        mint = mint_data.get("mint", "unknown")
        logger.info(f"Backtesting mint {mint[:16]}.. strategy={strategy_name} split={split}")

        # Reset engines for fresh run
        self.feature_engine = FeatureEngine()
        self.exit_engine = ExitEngine()
        self.pnl_sim = PnLSimulator()

        if self.use_qwen:
            if not self.qwen:
                self.qwen = QwenClient()
            self.entry_engine = EntryEngine(self.qwen)
        else:
            # Deterministic-only mode
            self.entry_engine = EntryEngine(None)

        self.pos_manager = PositionManager(
            self.entry_engine, self.exit_engine, self.pnl_sim, self.feature_engine
        )

        # Replay events
        events = mint_data.get("events", [])
        trade_history = mint_data.get("trade_history", [])

        # Build synthetic events from trade history for feature engine
        replay_events = []
        for trade in trade_history:
            ts, action, trader, token_amt, quote_amt = trade
            replay_events.append({
                "mint": mint,
                "action": action,
                "timestamp": int(ts * 1000),
                "tradersInvolved": {trader: {}} if trader else {},
                "tokenAmount": token_amt,
                "quoteAmount": quote_amt,
                "price": quote_amt / max(token_amt, 1e-20) if token_amt else 0,
                "marketCapQuote": mint_data.get("events", [{}])[0].get("marketCapQuote", 0) if mint_data.get("events") else 0,
            })

        # If no trade history, use events directly
        if not replay_events:
            for ev in events:
                replay_events.append({
                    "mint": mint,
                    "action": ev.get("action", "buy"),
                    "timestamp": int(ev.get("ts", 0) * 1000),
                    "tradersInvolved": {t: {} for t in ev.get("tradersInvolved", [])},
                    "tokenAmount": ev.get("tokenAmount", 0),
                    "quoteAmount": ev.get("quoteAmount", 0),
                    "price": ev.get("price", 0),
                    "marketCapQuote": ev.get("marketCapQuote", 0),
                    "tokensInPool": ev.get("tokensInPool"),
                    "quoteInPool": ev.get("quoteInPool"),
                    "vTokensInBondingCurve": ev.get("vTokensInBondingCurve"),
                    "vQuoteInBondingCurve": ev.get("vQuoteInBondingCurve"),
                    "poolFeeRate": ev.get("poolFeeRate"),
                    "breakdown": ev.get("breakdown"),
                })

        # Replay each event
        for event in replay_events:
            # Update features
            features = self.feature_engine.update_from_event(event)
            if not features:
                continue

            # Check entry/exit
            await self.pos_manager.on_event(event, features)

        # Force close any remaining positions
        if self.pos_manager.open_positions:
            features_map = {}
            for m in self.pos_manager.open_positions:
                f = self.feature_engine.get_features(m)
                if f:
                    features_map[m] = f
            self.pos_manager.force_close_all(features_map)

        # Compile results
        result = self._compile_result(mint, strategy_name, split)
        self._results.append(result)

        logger.info(f"Backtest complete: {result.summary()}")
        return result

    def _compile_result(self, mint: str, strategy_name: str, split: str) -> BacktestResult:
        """Compile backtest metrics from closed positions."""
        closed = self.pos_manager.closed_positions if self.pos_manager else []
        trades = len(closed)

        if trades == 0:
            return BacktestResult(
                mint=mint, strategy_name=strategy_name, split=split
            )

        net_pnls = [p.pnl_result.net_pnl for p in closed if p.pnl_result]
        gross_pnls = [p.pnl_result.gross_pnl for p in closed if p.pnl_result]
        costs = [p.pnl_result.entry_costs.total + p.pnl_result.exit_costs.total
                 for p in closed if p.pnl_result]
        hold_times = [p.pnl_result.hold_time_sec for p in closed if p.pnl_result]

        profitable = sum(1 for p in net_pnls if p > 0)
        losses = trades - profitable

        # Max drawdown
        cumulative = 0
        peak = 0
        max_dd = 0
        for p in net_pnls:
            cumulative += p
            peak = max(peak, cumulative)
            dd = peak - cumulative
            max_dd = max(max_dd, dd)

        sorted_pnls = sorted(net_pnls)
        median = sorted_pnls[len(sorted_pnls) // 2] if sorted_pnls else 0

        return BacktestResult(
            mint=mint,
            strategy_name=strategy_name,
            trades=trades,
            profitable=profitable,
            losses=losses,
            total_gross_pnl=sum(gross_pnls),
            total_net_pnl=sum(net_pnls),
            total_costs=sum(costs),
            avg_trade=sum(net_pnls) / trades if trades else 0,
            median_trade=median,
            max_drawdown=max_dd,
            avg_hold_time=sum(hold_times) / trades if trades else 0,
            win_rate=profitable / trades if trades else 0,
            best_trade=max(net_pnls) if net_pnls else 0,
            worst_trade=min(net_pnls) if net_pnls else 0,
            split=split,
        )

    async def run_batch(self, mint_files: list[str], strategy_name: str = "default"):
        """Run backtest on multiple mints with train/val/test split."""
        n = len(mint_files)
        train_end = int(n * config.BACKTEST_TRAIN_RATIO)
        val_end = int(n * (config.BACKTEST_TRAIN_RATIO + config.BACKTEST_VALIDATION_RATIO))

        results = {"train": [], "validation": [], "test": []}

        for i, mf in enumerate(mint_files):
            # Determine split
            if i < train_end:
                split = "train"
            elif i < val_end:
                split = "validation"
            else:
                split = "test"

            # Load mint data
            if os.path.isfile(mf):
                with open(mf, "rb") as f:
                    data = orjson.loads(f.read())
            else:
                logger.warning(f"File not found: {mf}")
                continue

            result = await self.run_mint(data, strategy_name, split)
            results[split].append(result)

        # Aggregate per split
        for split_name, split_results in results.items():
            if split_results:
                total_trades = sum(r.trades for r in split_results)
                total_net = sum(r.total_net_pnl for r in split_results)
                total_profitable = sum(r.profitable for r in split_results)
                print(f"\n═══ {split_name.upper()} ({len(split_results)} mints) ═══")
                print(f"  Trades: {total_trades}")
                print(f"  Win Rate: {total_profitable / max(total_trades, 1):.1%}")
                print(f"  Total NET PnL: {total_net:+.6f} SOL")
                print(f"  Avg per mint: {total_net / len(split_results):+.6f} SOL")

        self._results.extend(r for rl in results.values() for r in rl)
        return results

    def get_all_results(self) -> list[BacktestResult]:
        return self._results

    async def close(self):
        if self.qwen:
            await self.qwen.close()


async def run_backtest_cli(mint_path: str = None, strategy: str = "default",
                           use_qwen: bool = True):
    """CLI entry point for backtesting."""
    engine = BacktestEngine(use_qwen=use_qwen)

    if use_qwen:
        await engine.qwen.warmup()

    if mint_path:
        # Single mint backtest
        if os.path.isfile(mint_path):
            with open(mint_path, "rb") as f:
                data = orjson.loads(f.read())
            result = await engine.run_mint(data, strategy)
            print(f"\n{result.summary()}")
        else:
            # Try as mint address
            data = None
            json_path = os.path.join(config.MINTS_DIR, f"{mint_path}.json")
            if os.path.exists(json_path):
                with open(json_path, "rb") as f:
                    data = orjson.loads(f.read())
            if data:
                result = await engine.run_mint(data, strategy)
                print(f"\n{result.summary()}")
            else:
                print(f"Mint data not found: {mint_path}")
    else:
        # Batch backtest on all saved mints
        mint_files = [
            os.path.join(config.MINTS_DIR, f)
            for f in os.listdir(config.MINTS_DIR)
            if f.endswith(".json")
        ]
        if mint_files:
            print(f"Found {len(mint_files)} mint files. Running batch backtest...")
            await engine.run_batch(mint_files, strategy)
        else:
            print(f"No mint files found in {config.MINTS_DIR}")

    await engine.close()
