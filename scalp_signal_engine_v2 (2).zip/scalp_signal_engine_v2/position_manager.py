"""
Position Manager — Manages positions with state machine, MAE/MFE tracking.
States: FLAT → ENTRY_PENDING → OPEN → EXIT_PENDING → CLOSED
        Any state → ERROR (on failure)
"""
import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

import config
from feature_engine import FeatureEngine, MintFeatures
from entry_engine import EntryEngine, EntrySignal
from exit_engine import ExitEngine, ExitSignal
from pnl_simulator import PnLSimulator, PnLResult, TradeCosts
from execution_interface import BaseExecutor, ExecutionResult, BacktestExecutor

logger = logging.getLogger("position")


class PositionState(str, Enum):
    FLAT = "FLAT"
    ENTRY_PENDING = "ENTRY_PENDING"
    OPEN = "OPEN"
    EXIT_PENDING = "EXIT_PENDING"
    CLOSED = "CLOSED"
    ERROR = "ERROR"


@dataclass
class Position:
    mint: str
    state: PositionState = PositionState.FLAT
    entry_time: float = 0.0
    exit_time: float = 0.0
    entry_signal: Optional[EntrySignal] = None
    exit_signal: Optional[ExitSignal] = None
    entry_info: dict = field(default_factory=dict)
    entry_execution: Optional[ExecutionResult] = None
    exit_execution: Optional[ExecutionResult] = None
    pnl_result: Optional[PnLResult] = None
    events_since_entry: int = 0
    # MAE/MFE tracking
    mfe_pct: float = 0.0         # max favorable excursion
    mae_pct: float = 0.0         # max adverse excursion
    peak_price: float = 0.0
    trough_price: float = float("inf")
    entry_price_actual: float = 0.0
    # Error info
    error_msg: str = ""

    @property
    def is_open(self) -> bool:
        return self.state == PositionState.OPEN

    @property
    def hold_time(self) -> float:
        if self.entry_time:
            end = self.exit_time or time.time()
            return end - self.entry_time
        return 0.0


class PositionManager:
    """Manages positions with full state machine."""

    def __init__(self, entry_engine: EntryEngine, exit_engine: ExitEngine,
                 pnl_sim: PnLSimulator, feature_engine: FeatureEngine,
                 executor: Optional[BaseExecutor] = None):
        self.entry_engine = entry_engine
        self.exit_engine = exit_engine
        self.pnl_sim = pnl_sim
        self.feature_engine = feature_engine
        self.executor = executor or BacktestExecutor()
        self._positions: dict[str, Position] = {}
        self._closed: list[Position] = []
        self._risk_manager = None  # set externally

    def set_risk_manager(self, rm):
        self._risk_manager = rm

    @property
    def open_positions(self) -> dict[str, Position]:
        return {m: p for m, p in self._positions.items()
                if p.state in (PositionState.OPEN, PositionState.ENTRY_PENDING)}

    @property
    def closed_positions(self) -> list[Position]:
        return self._closed

    def get_position_data_for_reconciliation(self) -> dict:
        """Get internal position data for balance reconciler."""
        result = {}
        for mint, pos in self._positions.items():
            if pos.state == PositionState.OPEN:
                result[mint] = {
                    "tokens": pos.entry_info.get("tokens_received", 0),
                    "sol_spent": pos.entry_info.get("sol_spent", 0),
                }
        return result

    async def on_event(self, event: dict, features: MintFeatures) -> Optional[str]:
        """Process event for position management."""
        mint = features.mint

        # ── Check existing positions for exit / MAE/MFE update ────────
        if mint in self._positions:
            pos = self._positions[mint]
            if pos.state == PositionState.OPEN:
                return await self._check_exit(mint, features, pos)
            elif pos.state == PositionState.ENTRY_PENDING:
                # Don't process while entry is pending
                return None

        # ── Check for new entry ────────────────────────────────────────
        if mint not in self._positions:
            return await self._check_entry(mint, features)

        return None

    async def _check_entry(self, mint: str, features: MintFeatures) -> Optional[str]:
        """Evaluate and execute entry."""
        signal = await self.entry_engine.evaluate(features)

        if signal.action != "BUY":
            return None

        # ── Risk check ────────────────────────────────────────────────
        if self._risk_manager:
            balance = await self.executor.get_sol_balance()
            allowed, reason = self._risk_manager.can_open_position(
                config.DEFAULT_POSITION_SOL, balance
            )
            if not allowed:
                logger.info(f"🚫 Entry blocked: {reason}")
                return None

        # ── Mark ENTRY_PENDING ────────────────────────────────────────
        pos = Position(mint=mint, state=PositionState.ENTRY_PENDING,
                      entry_signal=signal, entry_time=time.time())
        self._positions[mint] = pos

        logger.info(
            f"📤 ENTRY SUBMITTED | {mint[:12]}.. | MC={features.market_cap:.0f} "
            f"| Score={signal.score:.2f} Conf={signal.confidence:.2f} "
            f"| P5={signal.p5_cal:.2f} P10={signal.p10_cal:.2f} P20={signal.p20_cal:.2f} "
            f"| EV={signal.expected_value:.4f}"
        )

        # ── Execute buy ───────────────────────────────────────────────
        exec_result = await self.executor.buy(
            mint=mint,
            sol_amount=config.DEFAULT_POSITION_SOL,
            max_slippage_pct=config.MAX_SLIPPAGE_PCT,
            price=features.price,
            liquidity=features.liquidity,
        )

        pos.entry_execution = exec_result

        if exec_result.success and exec_result.confirmed:
            # ── CONFIRMED → OPEN ──────────────────────────────────────
            pos.state = PositionState.OPEN
            pos.entry_price_actual = exec_result.price
            pos.peak_price = exec_result.price
            pos.trough_price = exec_result.price

            # Build entry_info from actual execution
            pos.entry_info = {
                "price": exec_result.price,
                "mc": features.market_cap,
                "liquidity": features.liquidity,
                "sol_spent": exec_result.sol_amount + exec_result.total_cost,
                "tokens_received": exec_result.token_amount,
                "costs": TradeCosts(
                    pump_fee=exec_result.pump_fee_paid,
                    priority_fee=exec_result.priority_fee_paid,
                    jito_tip=exec_result.jito_tip_paid,
                    ata_rent=exec_result.ata_rent_paid,
                    base_tx_fee=exec_result.base_tx_fee,
                    slippage_cost=exec_result.sol_amount * exec_result.slippage_actual,
                ),
                "slippage_pct": exec_result.slippage_actual,
            }

            if self._risk_manager:
                self._risk_manager.record_trade_open(exec_result.sol_amount)

            logger.info(
                f"✅ POSITION OPEN | {mint[:12]}.. | "
                f"TX={exec_result.signature[:20]}.. | "
                f"Tokens={exec_result.token_amount:.2f} | "
                f"SOL={exec_result.sol_amount:.4f} | "
                f"Slip={exec_result.slippage_actual:.4f}"
            )

            # Check for execution anomaly (large slippage difference)
            expected = exec_result.expected_token_amount
            actual = exec_result.token_amount
            if expected > 0 and actual > 0:
                fill_ratio = actual / expected
                if fill_ratio < 0.85:
                    logger.warning(
                        f"⚠️  EXECUTION ANOMALY: expected {expected:.2f} tokens, "
                        f"got {actual:.2f} ({fill_ratio:.1%})"
                    )
                    if self._risk_manager:
                        self._risk_manager.record_anomaly(
                            f"Low fill ratio {fill_ratio:.1%} for {mint[:12]}"
                        )

            return "ENTRY"
        else:
            # ── FAILED → back to FLAT ─────────────────────────────────
            pos.state = PositionState.ERROR if exec_result.error else PositionState.FLAT
            pos.error_msg = exec_result.error

            # ALWAYS log failure (not just when total_cost > 0)
            logger.warning(
                f"❌ ENTRY FAILED | {mint[:12]}.. | "
                f"Error: {exec_result.error or 'unknown'} | "
                f"Cost: {exec_result.total_cost:.6f} SOL"
            )
            
            # Remove from positions if completely failed
            if not exec_result.token_amount:
                del self._positions[mint]

            return None

    async def _check_exit(self, mint: str, features: MintFeatures,
                          pos: Position) -> Optional[str]:
        """Check exit conditions and MAE/MFE for open position."""
        pos.events_since_entry += 1

        # ── Update MAE/MFE ────────────────────────────────────────────
        current_price = features.price
        if current_price > 0 and pos.entry_price_actual > 0:
            current_pnl_pct = (current_price - pos.entry_price_actual) / pos.entry_price_actual
        else:
            current_pnl_pct = 0.0

        pos.peak_price = max(pos.peak_price, current_price)
        pos.trough_price = min(pos.trough_price, current_price)

        if pos.entry_price_actual > 0:
            pos.mfe_pct = max(pos.mfe_pct,
                             (pos.peak_price - pos.entry_price_actual) / pos.entry_price_actual)
            pos.mae_pct = min(pos.mae_pct,
                             (pos.trough_price - pos.entry_price_actual) / pos.entry_price_actual)

        # ── Emergency exit check (with grace period) ──────────────────
        # Don't check emergency exit in first 5 seconds to let position stabilize
        if pos.hold_time >= 5.0 and self._is_emergency(features, current_pnl_pct):
            return await self._execute_exit(mint, features, pos, emergency=True)

        # ── Normal exit evaluation ────────────────────────────────────
        signal = self.exit_engine.evaluate(
            features,
            entry_price=pos.entry_price_actual,
            entry_liquidity=pos.entry_info.get("liquidity", 0),
            hold_time=pos.hold_time,
            current_pnl_pct=current_pnl_pct,
            mfe=pos.mfe_pct,
            mae=pos.mae_pct,
        )

        if signal.action == "SELL":
            return await self._execute_exit(mint, features, pos, emergency=False)

        return "CHECK"

    def _is_emergency(self, f: MintFeatures, pnl_pct: float, hold_time: float = 0) -> bool:
        """Check emergency exit conditions."""
        # Don't check emergency in first 5 seconds (let position stabilize)
        if hold_time < 5.0:
            return False
        
        # Liquidity crash
        if f.liquidity_change < -config.EMERGENCY_LIQUIDITY_DROP_PCT:
            return True
        # Extreme slippage
        if f.estimated_slippage > config.EMERGENCY_SLIPPAGE_PCT:
            return True
        # Abnormal price drop
        if pnl_pct < -config.EMERGENCY_PRICE_DROP_PCT:
            return True
        # Extreme sell pressure
        if (f.buy_sell_ratio > 0 and
            f.buy_sell_ratio < 1.0 / config.EMERGENCY_SELL_PRESSURE_RATIO):
            return True
        # Migration happening
        if getattr(f, 'migration_status', '') == 'migrated':
            return True
        return False

    async def _execute_exit(self, mint: str, features: MintFeatures,
                            pos: Position, emergency: bool = False) -> Optional[str]:
        """Execute exit for a position."""
        # ── Mark EXIT_PENDING ─────────────────────────────────────────
        pos.state = PositionState.EXIT_PENDING

        tokens_to_sell = pos.entry_execution.token_amount if pos.entry_execution else 0
        if tokens_to_sell <= 0:
            # Try blockchain balance
            tokens_to_sell = await self.executor.get_token_balance(mint)

        if tokens_to_sell <= 0:
            pos.state = PositionState.ERROR
            pos.error_msg = "No tokens to sell"
            logger.error(f"❌ EXIT FAILED: no tokens for {mint[:12]}..")
            return None

        logger.info(
            f"📤 EXIT {'EMERGENCY ' if emergency else ''}SUBMITTED | {mint[:12]}.. | "
            f"Tokens={tokens_to_sell:.2f} | PnL={features.price / max(pos.entry_price_actual, 1e-20) - 1:.2%}"
        )

        # ── Execute sell ──────────────────────────────────────────────
        exec_result = await self.executor.sell(
            mint=mint,
            token_amount=tokens_to_sell,
            max_slippage_pct=config.MAX_SLIPPAGE_PCT * (2 if emergency else 1),
            price=features.price,
            liquidity=features.liquidity,
        )

        pos.exit_execution = exec_result
        pos.exit_time = time.time()

        if exec_result.success and exec_result.confirmed:
            # ── CONFIRMED → CLOSED ────────────────────────────────────
            pos.state = PositionState.CLOSED

            # Build PnL from actual execution data
            entry_costs = pos.entry_info.get("costs", TradeCosts())
            entry_sol = pos.entry_info.get("sol_spent", 0)
            exit_costs = TradeCosts(
                pump_fee=exec_result.pump_fee_paid,
                priority_fee=exec_result.priority_fee_paid,
                jito_tip=exec_result.jito_tip_paid,
                base_tx_fee=exec_result.base_tx_fee,
                ata_rent=0.0,
                slippage_cost=exec_result.slippage_actual * exec_result.sol_amount,
            )

            gross_pnl = exec_result.sol_amount - entry_sol
            total_costs = entry_costs.total + exit_costs.total
            net_pnl = gross_pnl - total_costs
            roi = net_pnl / max(entry_sol, 0.0001)

            pos.pnl_result = PnLResult(
                entry_price=pos.entry_price_actual,
                entry_mc=pos.entry_info.get("mc", 0),
                entry_liquidity=pos.entry_info.get("liquidity", 0),
                entry_token_amount=pos.entry_execution.token_amount,
                entry_sol=entry_sol,
                exit_price=exec_result.price,
                exit_mc=features.market_cap,
                exit_liquidity=features.liquidity,
                exit_token_amount=exec_result.token_amount,
                exit_sol=exec_result.sol_amount,
                gross_pnl=gross_pnl,
                entry_costs=entry_costs,
                exit_costs=exit_costs,
                net_pnl=net_pnl,
                roi=roi,
                hold_time_sec=pos.hold_time,
                mfe=pos.mfe_pct,
                mae=pos.mae_pct,
            )

            self._closed.append(pos)
            self.exit_engine.cleanup(mint)

            if self._risk_manager:
                self._risk_manager.record_trade_close(net_pnl, entry_sol)

            emoji = "🟢" if net_pnl >= 0 else "🔴"
            logger.info(
                f"{emoji} POSITION CLOSED | {mint[:12]}.. | "
                f"TX={exec_result.signature[:20]}.. | "
                f"NET={net_pnl:+.6f} SOL | ROI={roi:+.2%} | "
                f"MFE={pos.mfe_pct:+.2%} MAE={pos.mae_pct:+.2%} | "
                f"Hold={pos.hold_time:.0f}s"
            )
            return "EXIT"
        else:
            # ── EXIT FAILED → back to OPEN ────────────────────────────
            pos.state = PositionState.OPEN
            pos.error_msg = exec_result.error
            logger.warning(
                f"❌ EXIT FAILED | {mint[:12]}.. | "
                f"Error: {exec_result.error} | Reverting to OPEN"
            )
            return None

    def force_close_all(self, features_map: dict[str, MintFeatures]):
        """Force close all positions (for shutdown)."""
        for mint, pos in list(self._positions.items()):
            if pos.state != PositionState.OPEN:
                continue
            f = features_map.get(mint)
            if f and pos.entry_info:
                pnl = self.pnl_sim.compute_exit(
                    tokens=pos.entry_info.get("tokens_received", 0),
                    price=f.price,
                    liquidity=f.liquidity,
                    mc=f.market_cap,
                    entry_info=pos.entry_info,
                )
                pnl.hold_time_sec = pos.hold_time
                pnl.mfe = pos.mfe_pct
                pnl.mae = pos.mae_pct
                pos.pnl_result = pnl
                pos.state = PositionState.CLOSED
                pos.exit_time = time.time()
                self._closed.append(pos)

    def get_report(self, mint: str) -> Optional[str]:
        """Generate detailed report for a position."""
        pos = self._positions.get(mint)
        if not pos or not pos.pnl_result:
            # Check closed
            for cp in self._closed:
                if cp.mint == mint and cp.pnl_result:
                    pos = cp
                    break
        if not pos or not pos.pnl_result:
            return None

        pnl = pos.pnl_result
        sig = pos.entry_signal

        lines = [
            f"═══ MINT: {mint} ═══",
            f"State: {pos.state.value}",
            f"",
            f"Entry:",
            f"  MC: ${pnl.entry_mc:,.0f}",
            f"  Liquidity: {pnl.entry_liquidity:.1f} SOL",
            f"  Price: {pnl.entry_price:.2e}",
        ]
        if sig:
            lines += [
                f"",
                f"Entry Signal:",
                f"  Score: {sig.score:.2f}",
                f"  Confidence: {sig.confidence:.2f}",
                f"  Risk: {sig.risk:.2f}",
                f"  P5: {sig.p5_cal:.2f} (raw={sig.p5_raw:.2f})",
                f"  P10: {sig.p10_cal:.2f} (raw={sig.p10_raw:.2f})",
                f"  P20: {sig.p20_cal:.2f} (raw={sig.p20_raw:.2f})",
                f"  EV: {sig.expected_value:.4f}",
            ]
        if pos.entry_execution:
            lines += [
                f"",
                f"Entry TX: {pos.entry_execution.signature[:40]}",
                f"  Actual tokens: {pos.entry_execution.token_amount:.2f}",
                f"  Actual SOL: {pos.entry_execution.sol_amount:.6f}",
                f"  Slippage: {pos.entry_execution.slippage_actual:.4f}",
            ]
        lines += [
            f"",
            f"Exit:",
            f"  MC: ${pnl.exit_mc:,.0f}",
            f"  Price: {pnl.exit_price:.2e}",
        ]
        if pos.exit_execution:
            lines.append(f"  TX: {pos.exit_execution.signature[:40]}")
        lines += [
            f"",
            f"MFE: {pos.mfe_pct:+.2%}",
            f"MAE: {pos.mae_pct:+.2%}",
            f"",
            f"Gross PnL: {pnl.gross_pnl:+.6f} SOL",
            f"Entry Costs: -{pnl.entry_costs.total:.6f} SOL",
            f"  Pump Fee:   {pnl.entry_costs.pump_fee:.6f}",
            f"  Priority:   {pnl.entry_costs.priority_fee:.6f}",
            f"  Jito Tip:   {pnl.entry_costs.jito_tip:.6f}",
            f"  ATA Rent:   {pnl.entry_costs.ata_rent:.6f}",
            f"  Slippage:   {pnl.entry_costs.slippage_cost:.6f}",
            f"Exit Costs:  -{pnl.exit_costs.total:.6f} SOL",
            f"",
            f"NET PnL: {pnl.net_pnl:+.6f} SOL",
            f"ROI: {pnl.roi:+.2%}",
            f"Hold Time: {pnl.hold_time_sec:.1f}s",
        ]
        return "\n".join(lines)
