"""
PnL Simulator — Realistic profit/loss computation with all costs.
Computes gross PnL, fees, slippage, priority fees, rent, net PnL.
"""
import logging
from dataclasses import dataclass
from typing import Optional

import config

logger = logging.getLogger("pnl")


@dataclass
class TradeCosts:
    """All costs associated with a trade."""
    pump_fee: float = 0.0          # 1% pump.fun fee
    priority_fee: float = 0.0      # priority fee in SOL
    jito_tip: float = 0.0          # Jito tip in SOL
    ata_rent: float = 0.0          # ATA rent (only on first buy)
    base_tx_fee: float = 0.0       # base Solana tx fee
    slippage_cost: float = 0.0     # estimated slippage cost
    failed_tx_cost: float = 0.0    # cost of failed transactions

    @property
    def total(self) -> float:
        return (self.pump_fee + self.priority_fee + self.jito_tip +
                self.ata_rent + self.base_tx_fee + self.slippage_cost +
                self.failed_tx_cost)


@dataclass
class PnLResult:
    """Complete PnL breakdown for a trade."""
    entry_price: float = 0.0
    entry_mc: float = 0.0
    entry_liquidity: float = 0.0
    entry_token_amount: float = 0.0
    entry_sol: float = 0.0
    exit_price: float = 0.0
    exit_mc: float = 0.0
    exit_liquidity: float = 0.0
    exit_token_amount: float = 0.0
    exit_sol: float = 0.0
    gross_pnl: float = 0.0
    entry_costs: TradeCosts = None
    exit_costs: TradeCosts = None
    net_pnl: float = 0.0
    roi: float = 0.0
    hold_time_sec: float = 0.0
    mfe: float = 0.0         # max favorable excursion %
    mae: float = 0.0         # max adverse excursion %

    def __post_init__(self):
        if self.entry_costs is None:
            self.entry_costs = TradeCosts()
        if self.exit_costs is None:
            self.exit_costs = TradeCosts()

    def to_dict(self) -> dict:
        return {
            "entry": {
                "price": self.entry_price,
                "mc": self.entry_mc,
                "liquidity": self.entry_liquidity,
                "token_amount": self.entry_token_amount,
                "sol": self.entry_sol,
            },
            "exit": {
                "price": self.exit_price,
                "mc": self.exit_mc,
                "liquidity": self.exit_liquidity,
                "token_amount": self.exit_token_amount,
                "sol": self.exit_sol,
            },
            "gross_pnl": self.gross_pnl,
            "entry_costs": self.entry_costs.total,
            "exit_costs": self.exit_costs.total,
            "total_costs": self.entry_costs.total + self.exit_costs.total,
            "net_pnl": self.net_pnl,
            "roi": self.roi,
            "hold_time_sec": self.hold_time_sec,
            "mfe": self.mfe,
            "mae": self.mae,
        }

    def summary(self) -> str:
        return (
            f"Entry: MC={self.entry_mc:.0f} Liq={self.entry_liquidity:.1f} "
            f"SOL={self.entry_sol:.4f} Tokens={self.entry_token_amount:.2f}\n"
            f"Exit:  MC={self.exit_mc:.0f} Liq={self.exit_liquidity:.1f} "
            f"SOL={self.exit_sol:.4f}\n"
            f"Gross PnL: {self.gross_pnl:+.6f} SOL\n"
            f"Entry Costs: -{self.entry_costs.total:.6f} SOL\n"
            f"Exit Costs:  -{self.exit_costs.total:.6f} SOL\n"
            f"NET PnL: {self.net_pnl:+.6f} SOL\n"
            f"ROI: {self.roi:+.2%}\n"
            f"Hold: {self.hold_time_sec:.1f}s"
        )


class PnLSimulator:
    """Computes realistic PnL for paper trades."""

    def __init__(self):
        self._trades: list[PnLResult] = []

    def compute_entry(self, sol_amount: float, price: float,
                      liquidity: float, mc: float,
                      is_first_buy: bool = True) -> dict:
        """
        Compute entry details.
        Returns: entry info dict with token amount and costs.
        """
        # Slippage estimation based on trade size vs liquidity
        if liquidity > 0:
            slippage_pct = min(sol_amount / (liquidity * 2), 0.10)
        else:
            slippage_pct = config.ESTIMATED_SLIPPAGE_PCT

        # Effective price after slippage
        effective_price = price * (1 + slippage_pct)

        # Token amount received
        if effective_price > 0:
            tokens_received = sol_amount / effective_price
        else:
            tokens_received = 0

        # Costs
        costs = TradeCosts(
            pump_fee=sol_amount * config.PUMP_FEE_RATE,
            priority_fee=config.PRIORITY_FEE_SOL,
            jito_tip=config.JITO_TIP_SOL,
            ata_rent=config.ATA_RENT_SOL if is_first_buy else 0.0,
            base_tx_fee=config.BASE_TX_FEE_SOL,
            slippage_cost=sol_amount * slippage_pct,
        )

        return {
            "price": price,
            "effective_price": effective_price,
            "mc": mc,
            "liquidity": liquidity,
            "sol_spent": sol_amount,
            "tokens_received": tokens_received,
            "costs": costs,
            "slippage_pct": slippage_pct,
        }

    def compute_exit(self, tokens: float, price: float,
                     liquidity: float, mc: float,
                     entry_info: dict) -> PnLResult:
        """
        Compute exit and full PnL.
        """
        # Slippage on exit
        if liquidity > 0:
            # Estimate SOL value of tokens
            est_sol_value = tokens * price
            slippage_pct = min(est_sol_value / (liquidity * 2), 0.10)
        else:
            slippage_pct = config.ESTIMATED_SLIPPAGE_PCT

        effective_price = price * (1 - slippage_pct)
        sol_received = tokens * effective_price

        # Exit costs
        exit_costs = TradeCosts(
            pump_fee=sol_received * config.PUMP_FEE_RATE,
            priority_fee=config.PRIORITY_FEE_SOL,
            jito_tip=config.JITO_TIP_SOL,
            base_tx_fee=config.BASE_TX_FEE_SOL,
            slippage_cost=tokens * price * slippage_pct,
        )

        # Build result
        entry_costs = entry_info.get("costs", TradeCosts())
        entry_sol = entry_info.get("sol_spent", 0)

        gross_pnl = sol_received - entry_sol
        total_costs = entry_costs.total + exit_costs.total
        net_pnl = gross_pnl - total_costs
        roi = net_pnl / max(entry_sol, 0.0001) if entry_sol > 0 else 0

        result = PnLResult(
            entry_price=entry_info.get("price", 0),
            entry_mc=entry_info.get("mc", 0),
            entry_liquidity=entry_info.get("liquidity", 0),
            entry_token_amount=entry_info.get("tokens_received", 0),
            entry_sol=entry_sol,
            exit_price=price,
            exit_mc=mc,
            exit_liquidity=liquidity,
            exit_token_amount=tokens,
            exit_sol=sol_received,
            gross_pnl=gross_pnl,
            entry_costs=entry_costs,
            exit_costs=exit_costs,
            net_pnl=net_pnl,
            roi=roi,
        )

        self._trades.append(result)
        return result

    def get_trade_history(self) -> list[PnLResult]:
        return self._trades

    def get_summary(self) -> dict:
        if not self._trades:
            return {"trades": 0}

        net_pnls = [t.net_pnl for t in self._trades]
        gross_pnls = [t.gross_pnl for t in self._trades]
        rois = [t.roi for t in self._trades]
        total_costs = [t.entry_costs.total + t.exit_costs.total for t in self._trades]

        profitable = sum(1 for p in net_pnls if p > 0)
        losses = sum(1 for p in net_pnls if p <= 0)

        # Max drawdown
        cumulative = 0
        peak = 0
        max_dd = 0
        for p in net_pnls:
            cumulative += p
            peak = max(peak, cumulative)
            dd = peak - cumulative
            max_dd = max(max_dd, dd)

        # Sort for median
        sorted_pnls = sorted(net_pnls)
        n = len(sorted_pnls)
        median_pnl = sorted_pnls[n // 2] if n > 0 else 0

        mfe_list = [t.mfe for t in self._trades]
        mae_list = [t.mae for t in self._trades]
        hold_times = [t.hold_time_sec for t in self._trades]

        return {
            "trades": len(self._trades),
            "profitable": profitable,
            "losses": losses,
            "win_rate": profitable / max(len(self._trades), 1),
            "total_gross_pnl": sum(gross_pnls),
            "total_net_pnl": sum(net_pnls),
            "total_costs": sum(total_costs),
            "avg_trade": sum(net_pnls) / n if n else 0,
            "median_trade": median_pnl,
            "max_drawdown": max_dd,
            "avg_roi": sum(rois) / n if n else 0,
            "best_trade": max(net_pnls) if net_pnls else 0,
            "worst_trade": min(net_pnls) if net_pnls else 0,
            "avg_mfe": sum(mfe_list) / n if n else 0,
            "avg_mae": sum(mae_list) / n if n else 0,
            "avg_hold_time": sum(hold_times) / n if n else 0,
            "expectancy": (profitable / max(n, 1)) * (sum(p for p in net_pnls if p > 0) / max(profitable, 1))
                         - (losses / max(n, 1)) * abs(sum(p for p in net_pnls if p <= 0) / max(losses, 1)),
        }
