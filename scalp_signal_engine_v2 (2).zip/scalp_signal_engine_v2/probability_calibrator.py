"""
Probability Calibrator — Historical calibration for p5/p10/p20 probabilities.
Uses isotonic regression and bucket calibration to ensure model outputs
correspond to actual historical outcomes.
"""
import json
import logging
import os
import time
from collections import defaultdict
from dataclasses import dataclass
from typing import Optional

import numpy as np

import config

logger = logging.getLogger("calibrator")


@dataclass
class CalibrationRecord:
    """Single record of predicted vs actual outcome."""
    timestamp: float
    mint: str
    feature_hash: str       # compact representation of feature state
    predicted_p5: float     # model's p5 prediction
    predicted_p10: float    # model's p10 prediction
    predicted_p20: float    # model's p20 prediction
    actual_p5: bool         # did price reach +5%?
    actual_p10: bool        # did price reach +10%?
    actual_p20: bool        # did price reach +20%?
    max_up_pct: float       # max upward move after entry
    max_down_pct: float     # max downward move after entry
    actual_exit_pnl: float  # realized PnL%


class ProbabilityCalibrator:
    """Calibrates model probability outputs using historical data."""

    def __init__(self):
        self._records: list[CalibrationRecord] = []
        self._calibration_maps: dict[str, dict] = {
            "p5": {},   # bucket -> {predicted_avg, actual_rate, count}
            "p10": {},
            "p20": {},
        }
        self._isotonic_maps: dict[str, list] = {
            "p5": [],   # [(predicted, actual)] sorted pairs for isotonic
            "p10": [],
            "p20": [],
        }
        self._load_calibration()

    def _load_calibration(self):
        """Load saved calibration data."""
        path = config.CALIBRATION_DATA_PATH
        if os.path.exists(path):
            try:
                with open(path, "r") as f:
                    data = json.load(f)
                self._calibration_maps = data.get("maps", self._calibration_maps)
                self._isotonic_maps = data.get("isotonic", self._isotonic_maps)
                logger.info(f"Loaded calibration data from {path}")
            except Exception as e:
                logger.warning(f"Failed to load calibration: {e}")

    def save_calibration(self):
        """Save calibration data to disk."""
        path = config.CALIBRATION_DATA_PATH
        data = {
            "maps": self._calibration_maps,
            "isotonic": self._isotonic_maps,
            "updated": time.time(),
        }
        with open(path, "w") as f:
            json.dump(data, f, indent=2)

    def record_outcome(self, mint: str, features_str: str,
                       predicted_p5: float, predicted_p10: float,
                       predicted_p20: float, max_up_pct: float,
                       max_down_pct: float, exit_pnl: float):
        """Record a trade outcome for calibration."""
        rec = CalibrationRecord(
            timestamp=time.time(),
            mint=mint,
            feature_hash=features_str[:50],
            predicted_p5=predicted_p5,
            predicted_p10=predicted_p10,
            predicted_p20=predicted_p20,
            actual_p5=max_up_pct >= 0.05,
            actual_p10=max_up_pct >= 0.10,
            actual_p20=max_up_pct >= 0.20,
            max_up_pct=max_up_pct,
            max_down_pct=max_down_pct,
            actual_exit_pnl=exit_pnl,
        )
        self._records.append(rec)

        # Update isotonic maps
        self._isotonic_maps["p5"].append((predicted_p5, 1.0 if rec.actual_p5 else 0.0))
        self._isotonic_maps["p10"].append((predicted_p10, 1.0 if rec.actual_p10 else 0.0))
        self._isotonic_maps["p20"].append((predicted_p20, 1.0 if rec.actual_p20 else 0.0))

    def recalibrate(self):
        """Rebuild calibration maps from all records."""
        if len(self._records) < config.CALIBRATION_MIN_SAMPLES:
            logger.info(
                f"Not enough samples for calibration "
                f"({len(self._records)} < {config.CALIBRATION_MIN_SAMPLES})"
            )
            return

        for target in ["p5", "p10", "p20"]:
            pairs = self._isotonic_maps.get(target, [])
            if len(pairs) < config.CALIBRATION_MIN_SAMPLES:
                continue

            # Sort by predicted
            pairs_sorted = sorted(pairs, key=lambda x: x[0])

            # Bucket calibration
            n_buckets = config.CALIBRATION_BUCKET_COUNT
            bucket_size = max(1, len(pairs_sorted) // n_buckets)
            buckets = {}

            for i in range(0, len(pairs_sorted), bucket_size):
                chunk = pairs_sorted[i:i + bucket_size]
                if not chunk:
                    continue
                pred_avg = np.mean([p[0] for p in chunk])
                actual_rate = np.mean([p[1] for p in chunk])
                bucket_key = f"{i // bucket_size}"
                buckets[bucket_key] = {
                    "predicted_avg": float(pred_avg),
                    "actual_rate": float(actual_rate),
                    "count": len(chunk),
                    "pred_range": [float(chunk[0][0]), float(chunk[-1][0])],
                }

            self._calibration_maps[target] = buckets

        self.save_calibration()
        logger.info(f"Calibration updated with {len(self._records)} records")

    def calibrate_probability(self, target: str, raw_probability: float) -> tuple[float, float]:
        """
        Calibrate a raw probability from the model.
        Returns: (calibrated_probability, confidence_in_calibration)
        """
        buckets = self._calibration_maps.get(target, {})
        if not buckets:
            # No calibration data — return raw with low confidence
            return raw_probability, 0.0

        # Find the bucket this probability falls in
        best_bucket = None
        best_dist = float("inf")

        for key, bucket in buckets.items():
            pred_range = bucket.get("pred_range", [0, 1])
            mid = (pred_range[0] + pred_range[1]) / 2
            dist = abs(raw_probability - mid)
            if dist < best_dist:
                best_dist = dist
                best_bucket = bucket

        if best_bucket and best_bucket.get("count", 0) >= 5:
            calibrated = best_bucket["actual_rate"]
            # Confidence based on sample count
            confidence = min(best_bucket["count"] / 50.0, 1.0)
            return calibrated, confidence

        return raw_probability, 0.0

    def calibrate_all(self, p5: float, p10: float, p20: float) -> dict:
        """Calibrate all three probabilities."""
        cal_p5, conf_p5 = self.calibrate_probability("p5", p5)
        cal_p10, conf_p10 = self.calibrate_probability("p10", p10)
        cal_p20, conf_p20 = self.calibrate_probability("p20", p20)

        return {
            "p5_raw": p5, "p5_cal": cal_p5, "p5_conf": conf_p5,
            "p10_raw": p10, "p10_cal": cal_p10, "p10_conf": conf_p10,
            "p20_raw": p20, "p20_cal": cal_p20, "p20_conf": conf_p20,
            "calibration_samples": len(self._records),
        }

    def compute_expected_value(self, cal_probs: dict, position_sol: float,
                                avg_loss_pct: float = -0.08) -> float:
        """
        Compute expected value for an entry decision.
        Uses calibrated probabilities and historical return distribution.
        """
        p5 = cal_probs.get("p5_cal", 0)
        p10 = cal_probs.get("p10_cal", 0)
        p20 = cal_probs.get("p20_cal", 0)
        conf = min(cal_probs.get("p5_conf", 0), cal_probs.get("p10_conf", 0),
                   cal_probs.get("p20_conf", 0))

        if conf < 0.3:
            # Not enough calibration data — conservative EV
            return 0.0

        # Expected gains from each target
        ev_gain = (p5 * 0.05 + (p10 - p5) * 0.10 + (p20 - p10) * 0.20) * position_sol

        # Expected loss (probability of not reaching +5% times average loss)
        p_loss = 1.0 - p5
        ev_loss = p_loss * avg_loss_pct * position_sol

        # Fees (approximate)
        fees = position_sol * (config.PUMP_FEE_RATE * 2 + config.ESTIMATED_SLIPPAGE_PCT * 2)

        ev = ev_gain + ev_loss - fees

        # Scale by calibration confidence
        ev *= conf

        return ev

    def get_calibration_report(self) -> str:
        """Generate calibration quality report."""
        lines = ["═══ PROBABILITY CALIBRATION REPORT ═══"]
        lines.append(f"Total records: {len(self._records)}")
        lines.append("")

        for target in ["p5", "p10", "p20"]:
            buckets = self._calibration_maps.get(target, {})
            lines.append(f"── {target} ──")
            if not buckets:
                lines.append("  No calibration data")
                continue
            lines.append(f"  {'Bucket':>8} {'Predicted':>10} {'Actual':>10} {'Count':>7} {'Error':>8}")
            for key in sorted(buckets.keys(), key=int):
                b = buckets[key]
                error = abs(b["predicted_avg"] - b["actual_rate"])
                lines.append(
                    f"  {key:>8} {b['predicted_avg']:>10.3f} "
                    f"{b['actual_rate']:>10.3f} {b['count']:>7} {error:>8.3f}"
                )
            lines.append("")

        return "\n".join(lines)

    @property
    def stats(self) -> dict:
        return {
            "records": len(self._records),
            "calibrated": bool(self._calibration_maps.get("p5")),
            "p5_buckets": len(self._calibration_maps.get("p5", {})),
            "p10_buckets": len(self._calibration_maps.get("p10", {})),
            "p20_buckets": len(self._calibration_maps.get("p20", {})),
        }
