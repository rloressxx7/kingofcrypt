"""
Live Mode — Production paper/live trading engine.
Pipeline: Stream → Feature → Entry → Risk → Execute → Position → Exit → Execute → PnL
"""
import asyncio
import logging
import os
import time
from typing import Optional

import config
from stream import PumpStream
from mint_recorder import MintRecorder
from feature_engine import FeatureEngine
from entry_engine import EntryEngine
from exit_engine import ExitEngine
from position_manager import PositionManager
from pnl_simulator import PnLSimulator
from qwen_client import QwenClient
from signal_analyzer import SignalAnalyzer
from probability_calibrator import ProbabilityCalibrator
from latency import LatencyTracker
from graduated_exit import GradExitManager
from risk_manager import RiskManager
from execution_interface import BacktestExecutor, ExecutionMode
from balance_reconciler import BalanceReconciler

logger = logging.getLogger("live")


class LiveEngine:
    """Full production trading engine."""

    def __init__(self, use_qwen: bool = True, live_trading: bool = None):
        self.use_qwen = use_qwen
        self.live_trading = live_trading if live_trading is not None else config.LIVE_TRADING

        # Core components
        self.qwen = QwenClient() if use_qwen else None
        self.calibrator = ProbabilityCalibrator()
        self.risk_manager = RiskManager()
        self.stream = PumpStream(on_event=self._on_event)
        self.recorder = MintRecorder()
        self.feature_engine = FeatureEngine()
        self.entry_engine = EntryEngine(self.qwen, self.calibrator)
        self.exit_engine = ExitEngine()
        self.pnl_sim = PnLSimulator()
        self.analyzer = SignalAnalyzer()
        self.latency_tracker = LatencyTracker()
        self.grad_exit_mgr = GradExitManager()

        # Executor (paper or live)
        if self.live_trading:
            try:
                from real_executor import RealExecutor
                self.executor = RealExecutor()
            except ImportError:
                logger.error("real_executor not available — falling back to paper trading")
                self.executor = BacktestExecutor()
                self.live_trading = False
        else:
            self.executor = BacktestExecutor()

        self.pos_manager = PositionManager(
            self.entry_engine, self.exit_engine, self.pnl_sim,
            self.feature_engine, self.executor
        )
        self.pos_manager.set_risk_manager(self.risk_manager)
        self.reconciler = BalanceReconciler(self.executor)

        self._running = False
        self._event_count = 0
        self._start_time = 0.0
        self._last_event_time = 0.0

    async def _on_event(self, event: dict):
        """Process a single event from the stream."""
        lat = self.latency_tracker.new()
        self._event_count += 1
        self._last_event_time = time.time()

        mint = event.get("mint")
        if not mint:
            return

        # 1. Record
        await self.recorder.record_event(event)

        # 2. Features
        features = self.feature_engine.update_from_event(event)
        if not features:
            return
        lat.feature_ready = time.time()
        lat.mint = mint

        # 3. Entry/Exit check
        action = await self.pos_manager.on_event(event, features)
        lat.decision = time.time()

        if action == "ENTRY":
            lat.action = "ENTRY"
        elif action == "EXIT":
            lat.action = "EXIT"
            # Record for calibration and analysis
            pos = self.pos_manager._positions.get(mint)
            if not pos:
                # Check closed
                for cp in self.pos_manager.closed_positions:
                    if cp.mint == mint:
                        pos = cp
                        break
            if pos and pos.pnl_result and pos.entry_signal:
                sig = pos.entry_signal
                self.calibrator.record_outcome(
                    mint=mint,
                    features_str=features.compact_str(),
                    predicted_p5=sig.p5_raw,
                    predicted_p10=sig.p10_raw,
                    predicted_p20=sig.p20_raw,
                    max_up_pct=pos.mfe_pct,
                    max_down_pct=pos.mae_pct,
                    exit_pnl=pos.pnl_result.roi,
                )
                self.analyzer.record_trade(
                    entry_features=self.feature_engine.get_features(mint).to_dict()
                        if self.feature_engine.get_features(mint) else {},
                    exit_features=features.to_dict(),
                    net_pnl=pos.pnl_result.net_pnl,
                    roi=pos.pnl_result.roi,
                )
            self.feature_engine.cleanup(mint)

        # Record latency
        if config.LOG_LATENCY and action:
            self.latency_tracker.record(lat)

        # Stale data check
        if self._last_event_time and time.time() - self._last_event_time > config.WS_STALE_THRESHOLD:
            self.risk_manager.set_stream_connected(False)

        # Periodic stats
        if self._event_count % 500 == 0:
            self._print_stats()

    def _print_stats(self):
        elapsed = time.time() - self._start_time
        rate = self._event_count / max(elapsed, 1)
        open_count = len(self.pos_manager.open_positions)
        closed_count = len(self.pos_manager.closed_positions)
        pnl = self.pnl_sim.get_summary()
        risk = self.risk_manager.get_status()

        mode = "🔴 LIVE" if self.live_trading else "📝 PAPER"
        logger.info(
            f"{mode} | Events: {self._event_count} ({rate:.1f}/s) | "
            f"Open: {open_count} | Closed: {closed_count} | "
            f"NET PnL: {pnl.get('total_net_pnl', 0):+.6f} SOL | "
            f"Win: {pnl.get('profitable', 0)}/{pnl.get('trades', 0)} | "
            f"Daily: {risk['daily_pnl']}"
        )

        if self.qwen:
            qs = self.qwen.stats
            logger.info(
                f"🤖 QWEN: calls={qs['calls']} avg={qs['avg_latency_ms']:.0f}ms "
                f"errors={qs['errors']}"
            )

        cs = self.calibrator.stats
        if cs["records"] > 0:
            logger.info(
                f"📊 CAL: records={cs['records']} "
                f"calibrated={cs['calibrated']}"
            )

    async def start(self):
        """Start the live engine."""
        # ── Print startup banner ──────────────────────────────────────
        safe_config = config.get_safe_config_display()
        print("\n" + "=" * 60)
        print("  🎯 SCALP SIGNAL ENGINE — PRODUCTION")
        print("=" * 60)
        for key, val in safe_config.items():
            print(f"  {key:>24}: {val}")
        print("=" * 60 + "\n")

        logger.info("Starting engine...")

        # Initialize executor
        if self.live_trading and hasattr(self.executor, 'initialize'):
            try:
                await self.executor.initialize()
            except Exception as e:
                logger.error(f"Executor init failed: {e}")
                logger.info("Falling back to paper trading")
                self.executor = BacktestExecutor()
                self.live_trading = False

        # Warm up Qwen
        if self.use_qwen and self.qwen:
            success = await self.qwen.warmup()
            if not success:
                logger.warning("Qwen warmup failed — running without model")
                self.use_qwen = False
                self.entry_engine = EntryEngine(None, self.calibrator)

        self._running = True
        self._start_time = time.time()
        self.risk_manager.set_stream_connected(True)

        # Start background tasks
        asyncio.create_task(self._periodic_tasks())
        asyncio.create_task(self._periodic_exit_check())
        if self.live_trading:
            asyncio.create_task(self._reconciliation_loop())

        # Start stream (blocks)
        await self.stream.run()

    async def _periodic_tasks(self):
        """Background: cleanup, recalibrate, stats."""
        while self._running:
            await asyncio.sleep(60)
            self.recorder.cleanup_old(max_age_seconds=1800)

            # Recalibrate if enough data
            if len(self.calibrator._records) > config.CALIBRATION_MIN_SAMPLES:
                self.calibrator.recalibrate()

            # Check stale data
            if self._last_event_time:
                stale = time.time() - self._last_event_time > config.WS_STALE_THRESHOLD
                self.risk_manager.set_stream_connected(not stale)

            self._print_stats()

    async def _periodic_exit_check(self):
        """Periodically check ALL open positions for exit signals.
        
        Critical: exit engine only runs when events arrive for a mint.
        If a mint goes quiet (no new events), the position stays open forever
        without this periodic check.
        """
        while self._running:
            await asyncio.sleep(2)  # Check every 2 seconds
            
            # Get all open positions
            open_pos = self.pos_manager.open_positions
            if not open_pos:
                continue
            
            for mint, pos in open_pos.items():
                try:
                    # Get features from cache
                    features = self.feature_engine.get_features(mint)
                    if not features:
                        logger.debug(f"⏰ PERIODIC: {mint[:12]}.. no features cached")
                        continue
                    
                    # Calculate current PnL
                    if pos.entry_price_actual > 0 and features.price > 0:
                        pnl_pct = (features.price - pos.entry_price_actual) / pos.entry_price_actual
                    else:
                        pnl_pct = 0.0
                    
                    hold = pos.hold_time
                    
                    # ── GRADUATED EXIT (time-based rapid chunk selling) ──
                    # Strategy: sell 25% every 5 seconds (4 chunks total)
                    grad_state = self.grad_exit_mgr.get_state(mint)
                    if not grad_state:
                        # Register position for graduated selling
                        token_amount = pos.entry_info.get("tokens_received", 0)
                        if token_amount > 0:
                            self.grad_exit_mgr.register(mint, token_amount, pos.entry_time)
                            grad_state = self.grad_exit_mgr.get_state(mint)
                    
                    if grad_state and not grad_state.is_done:
                        # Check if it's time to sell next chunk
                        now = time.time()
                        sell_action = self.grad_exit_mgr.should_sell(mint, now)
                        
                        if sell_action:
                            phase = sell_action["phase"]
                            sell_tokens = sell_action["sell_tokens"]
                            is_final = sell_action["is_final"]
                            reason = sell_action["reason"]
                            
                            logger.info(
                                f"💰 CHUNK SELL {phase.value}/4: {mint[:12]}.. "
                                f"sell={sell_tokens:.2f} tokens | "
                                f"pnl={pnl_pct:+.2%} | {reason}"
                            )
                            
                            # Execute partial sell
                            exec_result = await self.executor.sell(
                                mint=mint,
                                token_amount=sell_tokens,
                                max_slippage_pct=config.MAX_SLIPPAGE_PCT,
                                price=features.price,
                                liquidity=features.liquidity,
                            )
                            
                            if exec_result.success:
                                # Record the chunk sell
                                self.grad_exit_mgr.record_sell(
                                    mint=mint,
                                    phase=phase,
                                    tokens_sold=sell_tokens,
                                    sol_received=exec_result.sol_amount,
                                )
                                
                                # Update position's remaining tokens
                                pos.token_amount = grad_state.remaining_tokens
                                
                                # If final chunk (CHUNK4), close position
                                if is_final:
                                    pos.is_closed = True
                                    pos.exit_time = time.time()
                                    pos.exit_price = exec_result.price
                                    pos.exit_reason = "graduated_complete"
                                    
                                    # Record in PnL simulator
                                    self.pnl_sim.record_trade(
                                        entry_price=pos.entry_price_actual,
                                        exit_price=exec_result.price,
                                        entry_time=pos.entry_time,
                                        exit_time=pos.exit_time,
                                        position_size_sol=pos.entry_info.get("sol_amount", 0),
                                        fees_paid=exec_result.total_fees,
                                        slippage_paid=exec_result.slippage_sol,
                                    )
                                    
                                    logger.info(
                                        f"✅ POSITION CLOSED (Graduated 4/4): {mint[:12]}.. "
                                        f"all chunks sold"
                                    )
                                    
                                    # Cleanup
                                    self.grad_exit_mgr.cleanup(mint)
                                
                                continue  # Skip regular exit check this cycle
                    
                    # ── REGULAR EXIT CHECK (emergency/stop-loss) ──
                    logger.info(
                        f"⏰ PERIODIC CHECK: {mint[:12]}.. "
                        f"hold={hold:.0f}s pnl={pnl_pct:+.2%} "
                        f"mfe={pos.mfe_pct:+.2%} mae={pos.mae_pct:+.2%} "
                        f"events={pos.events_since_entry} "
                        f"sold={grad_state.sold_pct:.0% if grad_state else 0:.0%} "
                        f"price={features.price:.10f}"
                    )
                    
                    # Check exit conditions
                    action = await self.pos_manager._check_exit(mint, features, pos)
                    
                    if action == "EXIT":
                        logger.info(f"🚪 PERIODIC EXIT: {mint[:12]}.. triggered")
                        # If graduated exit in progress, sell remaining
                        if grad_state and not grad_state.is_fully_exited:
                            remaining = grad_state.remaining_token_amount
                            if remaining > 0:
                                logger.info(
                                    f"🚪 SELLING REMAINING: {mint[:12]}.. "
                                    f"{remaining:.2f} tokens"
                                )
                                await self.executor.sell(
                                    mint=mint,
                                    token_amount=remaining,
                                    max_slippage_pct=config.MAX_SLIPPAGE_PCT,
                                    price=features.price,
                                    liquidity=features.liquidity,
                                )
                                self.grad_exit_mgr.cleanup(mint)
                    elif action == "CHECK":
                        # Evaluate and log what exit engine says
                        signal = self.exit_engine.evaluate(
                            features,
                            entry_price=pos.entry_price_actual,
                            entry_liquidity=pos.entry_info.get("liquidity", 0),
                            hold_time=pos.hold_time,
                            current_pnl_pct=pnl_pct,
                            mfe=pos.mfe_pct,
                            mae=pos.mae_pct,
                        )
                        logger.info(
                            f"   EXIT_EVAL: {mint[:12]}.. "
                            f"action={signal.action} score={signal.score:.2f} "
                            f"reasons={signal.reasons}"
                        )
                        
                except Exception as e:
                    logger.debug(f"Periodic exit check error for {mint[:12]}: {e}")

    async def _reconciliation_loop(self):
        """Periodic balance reconciliation."""
        while self._running:
            await asyncio.sleep(config.RECONCILIATION_INTERVAL_SEC)
            try:
                positions = self.pos_manager.get_position_data_for_reconciliation()
                if positions:
                    discrepancies = await self.reconciler.reconcile(positions)
                    if discrepancies:
                        for d in discrepancies:
                            self.risk_manager.record_anomaly(
                                f"Balance mismatch: {d.mint[:12]} "
                                f"{d.field} diff={d.difference:+.2f} ({d.pct_difference:.1%})"
                            )
            except Exception as e:
                logger.error(f"Reconciliation error: {e}")

    async def stop(self):
        """Graceful shutdown."""
        logger.info("Stopping engine...")
        self._running = False
        self.stream.stop()

        # Force close positions
        features_map = {}
        for mint in self.pos_manager.open_positions:
            f = self.feature_engine.get_features(mint)
            if f:
                features_map[mint] = f
        self.pos_manager.force_close_all(features_map)

        # Save state
        for mint in self.recorder.get_active_mints():
            await self.recorder.save_mint(mint)
        self.calibrator.save_calibration()

        # Print final report
        self._print_final_report()

        if self.qwen:
            await self.qwen.close()
        await self.executor.close()

    def _print_final_report(self):
        print("\n" + "=" * 60)
        print("  SESSION REPORT")
        print("=" * 60)
        summary = self.pnl_sim.get_summary()
        print(f"\n  Mode: {'LIVE' if self.live_trading else 'PAPER'}")
        print(f"  Signals: {self.entry_engine.stats['signals_evaluated']}")
        print(f"  Trades: {summary.get('trades', 0)}")
        print(f"  Profitable: {summary.get('profitable', 0)}")
        print(f"  Losses: {summary.get('losses', 0)}")
        print(f"  Win Rate: {summary.get('win_rate', 0):.1%}")
        print(f"  Expectancy: {summary.get('expectancy', 0):+.6f} SOL")
        print(f"")
        print(f"  Total Gross PnL: {summary.get('total_gross_pnl', 0):+.6f} SOL")
        print(f"  Total Costs:     -{summary.get('total_costs', 0):.6f} SOL")
        print(f"  Total NET PnL:   {summary.get('total_net_pnl', 0):+.6f} SOL")
        print(f"  Avg Trade:       {summary.get('avg_trade', 0):+.6f} SOL")
        print(f"  Median Trade:    {summary.get('median_trade', 0):+.6f} SOL")
        print(f"  Max Drawdown:    {summary.get('max_drawdown', 0):.6f} SOL")
        print(f"  Avg MFE:         {summary.get('avg_mfe', 0):+.2%}")
        print(f"  Avg MAE:         {summary.get('avg_mae', 0):+.2%}")

        if self.qwen:
            qs = self.qwen.stats
            print(f"\n  Qwen: {qs['calls']} calls, avg {qs['avg_latency_ms']:.0f}ms")

        cs = self.calibrator.stats
        print(f"  Calibration: {cs['records']} records")

        rs = self.risk_manager.get_status()
        print(f"  Risk: kill={rs['kill_switch']} emergency={rs['emergency']}")
        print("=" * 60)


async def run_live(use_qwen: bool = True, live_trading: bool = None):
    engine = LiveEngine(use_qwen=use_qwen, live_trading=live_trading)
    try:
        await engine.start()
    except KeyboardInterrupt:
        await engine.stop()
    except Exception as e:
        logger.error(f"Engine error: {e}", exc_info=True)
        await engine.stop()
