#!/usr/bin/env python3
"""
Demo: Qwen + Wallet Entegrasyonu
Bu script Qwen modelinin nasıl çalıştığını ve wallet kurulumunu gösterir.
"""
import asyncio
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from qwen_client import QwenClient
from feature_engine import MintFeatures
import config


async def demo_qwen():
    """Qwen modelinin nasıl çalıştığını göster."""
    print("=" * 70)
    print("🤖 QWEN3 4B MODELİ — NASIL ÇALIŞIYOR")
    print("=" * 70)
    
    print(f"\n📡 Ollama Endpoint: {config.OLLAMA_BASE_URL}")
    print(f"📦 Model: {config.OLLAMA_MODEL}")
    print(f"🔥 Keep Alive: {config.OLLAMA_KEEP_ALIVE} (sürekli bellekte)")
    print(f"🌡️  Temperature: {config.OLLAMA_TEMPERATURE} (deterministic)")
    print(f"🎯 Top K: {config.OLLAMA_TOP_K}")
    print(f"📝 Max Tokens: {config.OLLAMA_NUM_PREDICT}")
    
    # Create sample features
    print("\n" + "-" * 70)
    print("📊 ÖRNEK FEATURE SETİ (Mint: TestToken123)")
    print("-" * 70)
    
    features = MintFeatures(
        mint="TestToken123",
        price=1.35e-7,
        price_change_1s=0.000,
        price_change_5s=0.007,
        price_change_10s=0.012,
        volume_1s=0,
        volume_5s=1.2,
        volume_10s=7.8,
        volume_acceleration=0.85,
        buy_sell_ratio=3.5,
        buy_count=17,
        sell_count=3,
        consecutive_buys=5,
        consecutive_sells=0,
        unique_buyers=8,
        unique_sellers=3,
        new_buyer_velocity=2.1,
        wallet_concentration=0.17,
        whale_activity=0.085,
        liquidity=18.0,
        liquidity_change=0.565,
        estimated_slippage=0.0056,
        market_cap=18000,
        pool_fee_rate=0.0125,
        age_seconds=36,
        tx_velocity=0.67,
        mayhem_mode=False,
        migration_status="",
        burned_liquidity_pct=85.0,
    )
    
    compact = features.compact_str()
    print(f"\n📤 QWEN'E GÖNDERİLEN INPUT (compact format):")
    print(f"   {compact}")
    print(f"\n   Uzunluk: {len(compact)} karakter (~40 token)")
    
    # Call Qwen
    print("\n" + "-" * 70)
    print("🧠 QWEN ÇIKTISI")
    print("-" * 70)
    
    qwen = QwenClient()
    try:
        result = await qwen.ask(compact)
        
        if result:
            print(f"\n✅ Response alındı ({result['latency_ms']:.0f}ms)")
            print(f"\n📋 Raw Output:")
            print(f"   {result}")
            
            print(f"\n🎯 KARAR:")
            print(f"   Action:     {result['a']}")
            print(f"   Confidence: {result['c']:.2f} (model güveni, win rate DEĞİL)")
            print(f"   Risk:       {result['r']:.2f}")
            
            print(f"\n📊 CALIBRATED PROBABILITIES:")
            print(f"   P(+5%):  {result['p5']:.2f} (ham model çıktısı)")
            print(f"   P(+10%): {result['p10']:.2f}")
            print(f"   P(+20%): {result['p20']:.2f}")
            
            print(f"\n⚠️  ÖNEMLİ:")
            print(f"   • 'c' değeri win probability DEĞİLDİR")
            print(f"   • p5/p10/p20 değerleri historical calibration ile")
            print(f"     desteklenmedikçe probability olarak kullanılmaz")
            print(f"   • ProbabilityCalibrator bu değerleri geçmiş verilerle")
            print(f"     karşılaştırarak gerçek probability üretir")
        else:
            print("\n❌ Qwen'den response alınamadı")
            print("   Ollama çalışıyor mu? Model yüklü mü?")
    
    except Exception as e:
        print(f"\n❌ Hata: {e}")
    
    await qwen.close()
    
    print("\n" + "=" * 70)


def demo_wallet_setup():
    """Wallet kurulumunu göster."""
    print("\n" + "=" * 70)
    print("🔐 WALLET KURULUMU — PRIVATE KEY")
    print("=" * 70)
    
    print("\n📌 YÖNTEM 1: Environment Variable (Önerilen)")
    print("-" * 70)
    print("""
# Base58 encoded private key (Phantom/Solflare export)
export SOLANA_PRIVATE_KEY="5K8n...your_base58_key...XyZ"

# Çalıştırma
python3 main.py live --live-trading
""")
    
    print("\n📌 YÖNTEM 2: Keypair JSON File")
    print("-" * 70)
    print("""
# Solana CLI ile oluşturulan keypair
export SOLANA_KEYPAIR_PATH="/home/user/.config/solana/id.json"

# Çalıştırma
python3 main.py live --live-trading
""")
    
    print("\n📌 YÖNTEM 3: PumpAPI API Key (Lightning Mode)")
    print("-" * 70)
    print("""
# PumpAPI'nin encrypted key'i (private key göndermezsin)
export PUMPAPI_API_KEY="encrypted_key_from_pumpapi"

# Çalıştırma (en hızlı, PumpAPI imzalar)
python3 main.py live --live-trading
""")
    
    print("\n⚠️  GÜVENLİK UYARILARI:")
    print("-" * 70)
    print("""
❌ ASLA private key'i source code'a yazma
❌ ASLA private key'i log'lama
❌ ASLA private key'i git'e commit'leme
✅ Her zaman environment variable kullan
✅ .env dosyasını .gitignore'a ekle
✅ Production'da PUMPAPI_API_KEY kullan (private key PumpAPI'ye gitmez)
""")
    
    print("\n🔧 ÖRNEK .env DOSYASI:")
    print("-" * 70)
    print("""
# .env (BUNU .gitignore'A EKLE!)
SOLANA_PRIVATE_KEY=5K8n...your_base58_key...XyZ
PUMPAPI_API_KEY=encrypted_key_here
LIVE_TRADING=true
OLLAMA_URL=http://127.0.0.1:11434
OLLAMA_MODEL=local-jev
""")
    
    print("\n📊 MEVCUT DURUM:")
    print("-" * 70)
    print(f"  SOLANA_PRIVATE_KEY: {'✅ SET' if config.SOLANA_PRIVATE_KEY else '❌ NOT SET'}")
    print(f"  SOLANA_KEYPAIR:     {'✅ SET' if config.SOLANA_KEYPAIR_PATH else '❌ NOT SET'}")
    print(f"  PUMPAPI_API_KEY:    {'✅ SET' if config.PUMPAPI_API_KEY else '❌ NOT SET'}")
    print(f"  LIVE_TRADING:       {'✅ ENABLED' if config.LIVE_TRADING else '⚠️  DISABLED (paper mode)'}")
    
    print("\n" + "=" * 70)


async def main():
    """Ana demo."""
    print("\n" + "🎯" * 35)
    print("SCALP SIGNAL ENGINE — QWEN + WALLET DEMO")
    print("🎯" * 35 + "\n")
    
    await demo_qwen()
    demo_wallet_setup()
    
    print("\n" + "✅" * 35)
    print("DEMO TAMAMLANDI")
    print("✅" * 35 + "\n")


if __name__ == "__main__":
    asyncio.run(main())
