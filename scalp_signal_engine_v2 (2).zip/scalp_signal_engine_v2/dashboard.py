"""
Dashboard — HTML report generator for trade results.
"""
import json
import os
import time
from typing import Optional

import config
from pnl_simulator import PnLSimulator
from position_manager import PositionManager
from signal_analyzer import SignalAnalyzer


def generate_report(pos_manager: PositionManager, pnl_sim: PnLSimulator,
                    analyzer: SignalAnalyzer, stream_stats: dict = None,
                    qwen_stats: dict = None, latency_stats: dict = None) -> str:
    """Generate an HTML dashboard report."""

    summary = pnl_sim.get_summary()
    closed = pos_manager.closed_positions

    # Build trade rows
    trade_rows = []
    for pos in closed[-50:]:  # last 50 trades
        if not pos.pnl_result:
            continue
        pnl = pos.pnl_result
        color = "#4caf50" if pnl.net_pnl >= 0 else "#f44336"
        trade_rows.append(f"""
        <tr>
            <td>{pos.mint[:12]}..</td>
            <td>${pnl.entry_mc:,.0f}</td>
            <td>${pnl.exit_mc:,.0f}</td>
            <td>{pnl.entry_sol:.4f}</td>
            <td>{pnl.exit_sol:.4f}</td>
            <td>{pnl.gross_pnl:+.6f}</td>
            <td>-{pnl.entry_costs.total + pnl.exit_costs.total:.6f}</td>
            <td style="color:{color};font-weight:bold">{pnl.net_pnl:+.6f}</td>
            <td style="color:{color}">{pnl.roi:+.2%}</td>
            <td>{pnl.hold_time_sec:.0f}s</td>
        </tr>""")

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Scalp Signal Engine — Report</title>
<style>
body {{ font-family: 'Segoe UI', system-ui, sans-serif; background: #0d1117; color: #c9d1d9; margin: 0; padding: 20px; }}
.container {{ max-width: 1200px; margin: 0 auto; }}
h1 {{ color: #58a6ff; border-bottom: 1px solid #21262d; padding-bottom: 10px; }}
h2 {{ color: #8b949e; margin-top: 30px; }}
.stats-grid {{ display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 15px; margin: 20px 0; }}
.stat-card {{ background: #161b22; border: 1px solid #21262d; border-radius: 8px; padding: 15px; }}
.stat-label {{ color: #8b949e; font-size: 12px; text-transform: uppercase; }}
.stat-value {{ font-size: 24px; font-weight: bold; margin-top: 5px; }}
.positive {{ color: #3fb950; }}
.negative {{ color: #f85149; }}
.neutral {{ color: #58a6ff; }}
table {{ width: 100%; border-collapse: collapse; margin: 20px 0; font-size: 13px; }}
th {{ background: #161b22; color: #8b949e; padding: 10px; text-align: left; border-bottom: 1px solid #21262d; }}
td {{ padding: 8px 10px; border-bottom: 1px solid #21262d; }}
tr:hover {{ background: #161b22; }}
.info-row {{ display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #21262d; }}
.info-label {{ color: #8b949e; }}
.timestamp {{ color: #8b949e; font-size: 12px; }}
</style>
</head>
<body>
<div class="container">
<h1>🎯 Scalp Signal Engine — Session Report</h1>
<p class="timestamp">Generated: {time.strftime('%Y-%m-%d %H:%M:%S')}</p>

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-label">Total Trades</div>
        <div class="stat-value neutral">{summary.get('trades', 0)}</div>
    </div>
    <div class="stat-card">
        <div class="stat-label">Win Rate</div>
        <div class="stat-value {('positive' if summary.get('win_rate', 0) > 0.5 else 'negative')}">
            {summary.get('win_rate', 0):.1%}
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-label">Total NET PnL</div>
        <div class="stat-value {('positive' if summary.get('total_net_pnl', 0) >= 0 else 'negative')}">
            {summary.get('total_net_pnl', 0):+.4f} SOL
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-label">Total Costs</div>
        <div class="stat-value negative">-{summary.get('total_costs', 0):.4f} SOL</div>
    </div>
    <div class="stat-card">
        <div class="stat-label">Avg Trade</div>
        <div class="stat-value {('positive' if summary.get('avg_trade', 0) >= 0 else 'negative')}">
            {summary.get('avg_trade', 0):+.4f} SOL
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-label">Max Drawdown</div>
        <div class="stat-value negative">{summary.get('max_drawdown', 0):.4f} SOL</div>
    </div>
    <div class="stat-card">
        <div class="stat-label">Best Trade</div>
        <div class="stat-value positive">{summary.get('best_trade', 0):+.4f} SOL</div>
    </div>
    <div class="stat-card">
        <div class="stat-label">Worst Trade</div>
        <div class="stat-value negative">{summary.get('worst_trade', 0):+.4f} SOL</div>
    </div>
</div>

<h2>📋 Trade History (last 50)</h2>
<table>
<thead>
<tr>
    <th>Mint</th>
    <th>Entry MC</th>
    <th>Exit MC</th>
    <th>Entry SOL</th>
    <th>Exit SOL</th>
    <th>Gross PnL</th>
    <th>Costs</th>
    <th>NET PnL</th>
    <th>ROI</th>
    <th>Hold</th>
</tr>
</thead>
<tbody>
{''.join(trade_rows) if trade_rows else '<tr><td colspan="10" style="text-align:center;color:#8b949e">No trades yet</td></tr>'}
</tbody>
</table>

<h2>📊 System Info</h2>
<div class="stat-card" style="max-width:400px">
    <div class="info-row"><span class="info-label">MC Target Zone</span><span>{config.MC_TARGET_LOW}-{config.MC_TARGET_HIGH}</span></div>
    <div class="info-row"><span class="info-label">Position Size</span><span>{config.DEFAULT_POSITION_SOL} SOL</span></div>
    <div class="info-row"><span class="info-label">Pump Fee Rate</span><span>{config.PUMP_FEE_RATE:.1%}</span></div>
    <div class="info-row"><span class="info-label">Priority Fee</span><span>{config.PRIORITY_FEE_SOL} SOL</span></div>
    <div class="info-row"><span class="info-label">Jito Tip</span><span>{config.JITO_TIP_SOL} SOL</span></div>
    <div class="info-row"><span class="info-label">Model</span><span>{config.OLLAMA_MODEL}</span></div>
</div>

</div>
</body>
</html>"""

    return html


def save_report(html: str, filename: str = "report.html"):
    """Save report to file."""
    path = os.path.join(config.DATA_DIR, filename)
    with open(path, "w") as f:
        f.write(html)
    return path
