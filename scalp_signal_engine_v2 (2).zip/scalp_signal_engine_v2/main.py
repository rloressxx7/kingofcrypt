#!/usr/bin/env python3
"""
Scalp Signal Engine — Main Entry Point (Production)

Commands:
    python main.py live [--no-qwen] [--paper]    Live/paper trading
    python main.py backtest [mint_path]           Backtest saved mints
    python main.py analyze                        Signal analysis
    python main.py stream [--max-events N]        Debug stream
    python main.py record <mint>                  Record a specific mint
    python main.py status                         Show system status
    python main.py positions                      Show open positions
    python main.py pnl                            Show PnL summary
    python main.py kill                           Activate kill switch
    python main.py resume                         Deactivate kill switch
    python main.py calibrate                      Recalibrate probabilities
"""
import argparse
import asyncio
import logging
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import config


def setup_logging(level: str = "INFO"):
    fmt = "%(asctime)s [%(name)s] %(levelname)s: %(message)s"
    datefmt = "%H:%M:%S"

    # Console handler — use errors='replace' for Windows cp1254
    console = logging.StreamHandler(sys.stdout)
    console.stream = open(1, mode="w", encoding="utf-8", errors="replace", closefd=False)

    handlers = [console]

    # File handler — always UTF-8
    try:
        fh = logging.FileHandler(config.LOG_FILE, mode="a", encoding="utf-8")
        handlers.append(fh)
    except Exception:
        pass

    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format=fmt, datefmt=datefmt, handlers=handlers,
    )


async def cmd_live(args):
    from live_mode import run_live
    use_qwen = not args.no_qwen
    live = not args.paper
    if live and not config.LIVE_TRADING:
        print("⚠️  LIVE_TRADING env var is not set to 'true'.")
        print("   Use: export LIVE_TRADING=true")
        print("   Or add --paper flag for paper trading.")
        if not args.force:
            print("   Add --force to override and run live anyway.")
            return
    await run_live(use_qwen=use_qwen, live_trading=live)


async def cmd_backtest(args):
    from backtest import run_backtest_cli
    use_qwen = not args.no_qwen
    await run_backtest_cli(
        mint_path=args.mint, strategy=args.strategy, use_qwen=use_qwen
    )


async def cmd_analyze(args):
    from signal_analyzer import SignalAnalyzer
    analyzer = SignalAnalyzer()
    bt_dir = config.BACKTEST_DIR
    if os.path.exists(bt_dir):
        import orjson
        for f in os.listdir(bt_dir):
            if f.endswith(".json"):
                with open(os.path.join(bt_dir, f), "rb") as fh:
                    data = orjson.loads(fh.read())
                    for trade in data.get("trades", []):
                        analyzer.record_trade(
                            entry_features=trade.get("entry_features", {}),
                            exit_features=trade.get("exit_features", {}),
                            net_pnl=trade.get("net_pnl", 0),
                            roi=trade.get("roi", 0),
                        )
    analyzer.print_report()


async def cmd_stream(args):
    from stream import PumpStream
    count = 0

    async def on_event(event):
        nonlocal count
        count += 1
        action = event.get("action", "?")
        mint = event.get("mint", "?")[:12]
        price = event.get("price", 0)
        mc = event.get("marketCapQuote", 0)
        pool = event.get("pool", "?")
        print(f"[{count:>6}] {action:<12} {mint}.. MC={mc:>10.0f} "
              f"Price={price:.2e} Pool={pool}")
        if args.max_events and count >= args.max_events:
            raise KeyboardInterrupt

    stream = PumpStream(on_event=on_event)
    try:
        await stream.run()
    except KeyboardInterrupt:
        print(f"\nStreamed {count} events.")


async def cmd_record(args):
    from stream import PumpStream
    from mint_recorder import MintRecorder
    recorder = MintRecorder()
    target = args.mint
    count = 0
    print(f"Recording mint: {target}")

    async def on_event(event):
        nonlocal count
        if event.get("mint") == target:
            count += 1
            await recorder.record_event(event)
            print(f"  [{count:>4}] {event.get('action', '?')}")

    stream = PumpStream(on_event=on_event)
    try:
        await stream.run()
    except KeyboardInterrupt:
        print(f"\nRecorded {count} events")
        await recorder.save_mint(target)


def cmd_status(args):
    """Show current system status."""
    from risk_manager import RiskManager
    rm = RiskManager()
    status = rm.get_status()
    safe = config.get_safe_config_display()

    print("\n" + "=" * 50)
    print("  SYSTEM STATUS")
    print("=" * 50)
    for k, v in safe.items():
        print(f"  {k:>24}: {v}")
    print("-" * 50)
    for k, v in status.items():
        if k != "limits":
            print(f"  {k:>24}: {v}")
    if "limits" in status:
        print("-" * 50)
        for k, v in status["limits"].items():
            print(f"  {k:>24}: {v}")
    print("=" * 50)


def cmd_positions(args):
    """Show open positions (from saved state)."""
    state_file = os.path.join(config.STATE_DIR, "positions.json")
    if os.path.exists(state_file):
        import orjson
        with open(state_file, "rb") as f:
            data = orjson.loads(f.read())
        positions = data.get("open", [])
        if positions:
            print(f"\n  Open Positions: {len(positions)}")
            for p in positions:
                print(f"    {p.get('mint', '?')[:16]}.. "
                      f"state={p.get('state')} "
                      f"SOL={p.get('sol', 0):.4f}")
        else:
            print("\n  No open positions.")
    else:
        print("\n  No position state file found.")


def cmd_pnl(args):
    """Show PnL summary from trade log."""
    trade_log = config.TRADE_LOG_FILE
    if os.path.exists(trade_log):
        import orjson
        trades = []
        with open(trade_log, "r") as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        trades.append(orjson.loads(line))
                    except Exception:
                        pass
        if trades:
            net_pnls = [t.get("net_pnl", 0) for t in trades]
            profitable = sum(1 for p in net_pnls if p > 0)
            print(f"\n  Trades: {len(trades)}")
            print(f"  Win Rate: {profitable / len(trades):.1%}")
            print(f"  Total NET PnL: {sum(net_pnls):+.6f} SOL")
            print(f"  Avg: {sum(net_pnls) / len(net_pnls):+.6f} SOL")
        else:
            print("\n  No trade records.")
    else:
        print("\n  No trade log found.")


def cmd_kill(args):
    """Activate kill switch."""
    os.makedirs(config.STATE_DIR, exist_ok=True)
    with open(config.KILL_SWITCH_FILE, "w") as f:
        import time
        f.write(f"activated={time.time()}\nreason=manual\n")
    print("⛔ KILL SWITCH ACTIVATED")
    print("   New entries are blocked.")
    print("   Use 'python main.py resume' to deactivate.")


def cmd_resume(args):
    """Deactivate kill switch."""
    if os.path.exists(config.KILL_SWITCH_FILE):
        os.remove(config.KILL_SWITCH_FILE)
        print("✅ Kill switch deactivated.")
    else:
        print("Kill switch was not active.")


def cmd_calibrate(args):
    """Recalibrate probabilities."""
    from probability_calibrator import ProbabilityCalibrator
    cal = ProbabilityCalibrator()
    cal.recalibrate()
    print(cal.get_calibration_report())


def main():
    parser = argparse.ArgumentParser(
        description="Scalp Signal Engine — Production Trading System"
    )
    parser.add_argument("--log-level", default="INFO",
                       choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    sub = parser.add_subparsers(dest="command")

    # Live
    p_live = sub.add_parser("live", help="Live/paper trading")
    p_live.add_argument("--no-qwen", action="store_true")
    p_live.add_argument("--paper", action="store_true",
                       help="Force paper trading")
    p_live.add_argument("--force", action="store_true",
                       help="Force live trading without env var")

    # Backtest
    p_bt = sub.add_parser("backtest", help="Backtest")
    p_bt.add_argument("mint", nargs="?", default=None)
    p_bt.add_argument("--strategy", default="default")
    p_bt.add_argument("--no-qwen", action="store_true")

    # Analyze
    sub.add_parser("analyze", help="Signal analysis")

    # Stream
    p_stream = sub.add_parser("stream", help="Debug stream")
    p_stream.add_argument("--max-events", type=int, default=0)

    # Record
    p_rec = sub.add_parser("record", help="Record a mint")
    p_rec.add_argument("mint")

    # Status commands (sync)
    sub.add_parser("status", help="System status")
    sub.add_parser("positions", help="Open positions")
    sub.add_parser("pnl", help="PnL summary")
    sub.add_parser("kill", help="Activate kill switch")
    sub.add_parser("resume", help="Deactivate kill switch")
    sub.add_parser("calibrate", help="Recalibrate probabilities")

    args = parser.parse_args()
    setup_logging(args.log_level)

    if not args.command:
        parser.print_help()
        return

    sync_cmds = {
        "status": cmd_status,
        "positions": cmd_positions,
        "pnl": cmd_pnl,
        "kill": cmd_kill,
        "resume": cmd_resume,
        "calibrate": cmd_calibrate,
    }

    if args.command in sync_cmds:
        sync_cmds[args.command](args)
        return

    async_cmds = {
        "live": cmd_live,
        "backtest": cmd_backtest,
        "analyze": cmd_analyze,
        "stream": cmd_stream,
        "record": cmd_record,
    }

    handler = async_cmds.get(args.command)
    if handler:
        try:
            asyncio.run(handler(args))
        except KeyboardInterrupt:
            print("\nStopped.")


if __name__ == "__main__":
    main()
