"""
Risk Manager — Enforces hard risk limits, kill switch, cooldowns.
"""
import logging
import os
import time
from dataclasses import dataclass, field
from typing import Optional

import config

logger = logging.getLogger("risk")


@dataclass
class RiskState:
    """Current risk tracking state."""
    daily_realized_pnl: float = 0.0
    daily_trade_count: int = 0
    daily_loss_count: int = 0
    consecutive_losses: int = 0
    total_exposure_sol: float = 0.0  # sum of open position SOL
    open_position_count: int = 0
    last_loss_time: float = 0.0
    last_trade_time: float = 0.0
    kill_switch_active: bool = False
    paused: bool = False
    current_day: str = ""  # YYYY-MM-DD for daily reset
    emergency_mode: bool = False
    anomaly_count: int = 0
    rpc_errors: int = 0
    stream_connected: bool = True


class RiskManager:
    """Enforces all risk limits before and during trading."""

    def __init__(self):
        self.state = RiskState()
        self._check_kill_switch_file()
        self._check_pause_file()

    def _check_kill_switch_file(self):
        """Check if kill switch file exists."""
        if os.path.exists(config.KILL_SWITCH_FILE):
            self.state.kill_switch_active = True
            logger.warning("⛔ Kill switch file detected — NO NEW TRADES")

    def _check_pause_file(self):
        """Check if pause file exists."""
        if os.path.exists(config.PAUSE_FILE):
            self.state.paused = True
            logger.warning("⏸️  Pause file detected — trading paused")

    def reset_daily_if_needed(self):
        """Reset daily counters at midnight."""
        today = time.strftime("%Y-%m-%d")
        if self.state.current_day != today:
            if self.state.current_day:
                logger.info(
                    f"📅 Daily reset: PnL={self.state.daily_realized_pnl:+.6f} SOL, "
                    f"Trades={self.state.daily_trade_count}, "
                    f"Losses={self.state.daily_loss_count}"
                )
            self.state.daily_realized_pnl = 0.0
            self.state.daily_trade_count = 0
            self.state.daily_loss_count = 0
            self.state.current_day = today

    def can_open_position(self, sol_amount: float, wallet_balance: float) -> tuple[bool, str]:
        """
        Check all pre-conditions for opening a new position.
        Returns: (allowed, reason)
        """
        self.reset_daily_if_needed()
        self._check_kill_switch_file()
        self._check_pause_file()

        # Kill switch
        if self.state.kill_switch_active:
            return False, "KILL_SWITCH_ACTIVE"

        # Paused
        if self.state.paused:
            return False, "SYSTEM_PAUSED"

        # Emergency mode
        if self.state.emergency_mode:
            return False, "EMERGENCY_MODE"

        # Stream disconnected
        if not self.state.stream_connected:
            return False, "STREAM_DISCONNECTED"

        # Daily loss limit
        if self.state.daily_realized_pnl <= -config.MAX_DAILY_LOSS_SOL:
            return False, f"DAILY_LOSS_LIMIT ({self.state.daily_realized_pnl:+.4f} SOL)"

        # Max open positions
        if self.state.open_position_count >= config.MAX_OPEN_POSITIONS:
            return False, f"MAX_OPEN_POSITIONS ({self.state.open_position_count})"

        # Max total exposure
        if self.state.total_exposure_sol + sol_amount > config.MAX_TOTAL_EXPOSURE_SOL:
            return False, f"MAX_EXPOSURE ({self.state.total_exposure_sol + sol_amount:.4f} > {config.MAX_TOTAL_EXPOSURE_SOL})"

        # Position size limit
        if sol_amount > config.MAX_POSITION_SOL:
            return False, f"MAX_POSITION_SOL ({sol_amount:.4f} > {config.MAX_POSITION_SOL})"

        # Wallet balance
        if wallet_balance < sol_amount + config.MIN_SOL_BALANCE:
            return False, f"INSUFFICIENT_SOL (balance={wallet_balance:.4f}, need={sol_amount + config.MIN_SOL_BALANCE:.4f})"

        # Consecutive loss cooldown
        if self.state.consecutive_losses >= config.MAX_CONSECUTIVE_LOSSES:
            elapsed = time.time() - self.state.last_loss_time
            if elapsed < config.COOLDOWN_AFTER_LOSS_SEC:
                remaining = config.COOLDOWN_AFTER_LOSS_SEC - elapsed
                return False, f"COOLDOWN ({remaining:.0f}s remaining, {self.state.consecutive_losses} losses)"

        # RPC errors
        if self.state.rpc_errors >= 3:
            return False, f"RPC_UNSTABLE ({self.state.rpc_errors} errors)"

        return True, "OK"

    def can_execute_exit(self, mint: str, is_emergency: bool = False) -> tuple[bool, str]:
        """Check if exit execution is allowed."""
        if self.state.kill_switch_active and not is_emergency:
            # Kill switch allows emergency exits
            return True, "KILL_SWITCH_EMERGENCY_EXIT"
        return True, "OK"

    def record_trade_open(self, sol_amount: float):
        """Record that a position was opened."""
        self.state.open_position_count += 1
        self.state.total_exposure_sol += sol_amount
        self.state.daily_trade_count += 1
        self.state.last_trade_time = time.time()

    def record_trade_close(self, net_pnl: float, sol_amount: float):
        """Record that a position was closed."""
        self.state.open_position_count = max(0, self.state.open_position_count - 1)
        self.state.total_exposure_sol = max(0, self.state.total_exposure_sol - sol_amount)
        self.state.daily_realized_pnl += net_pnl

        if net_pnl < 0:
            self.state.consecutive_losses += 1
            self.state.daily_loss_count += 1
            self.state.last_loss_time = time.time()
        else:
            self.state.consecutive_losses = 0

    def record_anomaly(self, description: str):
        """Record an execution anomaly."""
        self.state.anomaly_count += 1
        logger.warning(f"⚠️  ANOMALY #{self.state.anomaly_count}: {description}")
        if self.state.anomaly_count >= 3:
            self.state.emergency_mode = True
            logger.error("🚨 EMERGENCY MODE activated due to repeated anomalies")

    def record_rpc_error(self):
        """Record an RPC error."""
        self.state.rpc_errors += 1

    def clear_rpc_errors(self):
        """Clear RPC error count (on successful RPC call)."""
        self.state.rpc_errors = 0

    def set_stream_connected(self, connected: bool):
        self.state.stream_connected = connected

    def activate_kill_switch(self, reason: str = ""):
        """Activate kill switch."""
        self.state.kill_switch_active = True
        with open(config.KILL_SWITCH_FILE, "w") as f:
            f.write(f"activated={time.time()}\nreason={reason}\n")
        logger.error(f"⛔ KILL SWITCH ACTIVATED: {reason}")

    def deactivate_kill_switch(self):
        """Deactivate kill switch."""
        self.state.kill_switch_active = False
        if os.path.exists(config.KILL_SWITCH_FILE):
            os.remove(config.KILL_SWITCH_FILE)
        logger.info("✅ Kill switch deactivated")

    def activate_emergency(self, reason: str = ""):
        """Enter emergency mode."""
        self.state.emergency_mode = True
        logger.error(f"🚨 EMERGENCY MODE: {reason}")

    def deactivate_emergency(self):
        """Exit emergency mode."""
        self.state.emergency_mode = False
        self.state.anomaly_count = 0
        logger.info("✅ Emergency mode deactivated")

    def check_slippage_limit(self, slippage_pct: float) -> bool:
        """Check if slippage exceeds limit."""
        return slippage_pct <= config.MAX_SLIPPAGE_PCT

    def check_price_impact_limit(self, impact_pct: float) -> bool:
        """Check if price impact exceeds limit."""
        return impact_pct <= config.MAX_PRICE_IMPACT_PCT

    def check_trade_loss_limit(self, estimated_loss: float) -> bool:
        """Check if estimated trade loss exceeds limit."""
        return estimated_loss >= -config.MAX_TRADE_LOSS_SOL

    def get_status(self) -> dict:
        """Return current risk state for display."""
        self.reset_daily_if_needed()
        return {
            "mode": "LIVE" if config.LIVE_TRADING else "PAPER",
            "kill_switch": self.state.kill_switch_active,
            "paused": self.state.paused,
            "emergency": self.state.emergency_mode,
            "stream_connected": self.state.stream_connected,
            "daily_pnl": f"{self.state.daily_realized_pnl:+.6f} SOL",
            "daily_trades": self.state.daily_trade_count,
            "daily_losses": self.state.daily_loss_count,
            "consecutive_losses": self.state.consecutive_losses,
            "open_positions": self.state.open_position_count,
            "total_exposure": f"{self.state.total_exposure_sol:.4f} SOL",
            "anomalies": self.state.anomaly_count,
            "rpc_errors": self.state.rpc_errors,
            "limits": {
                "max_position": config.MAX_POSITION_SOL,
                "max_daily_loss": config.MAX_DAILY_LOSS_SOL,
                "max_exposure": config.MAX_TOTAL_EXPOSURE_SOL,
                "max_open": config.MAX_OPEN_POSITIONS,
                "max_trade_loss": config.MAX_TRADE_LOSS_SOL,
                "max_slippage": f"{config.MAX_SLIPPAGE_PCT:.1%}",
                "max_consecutive_losses": config.MAX_CONSECUTIVE_LOSSES,
            }
        }
