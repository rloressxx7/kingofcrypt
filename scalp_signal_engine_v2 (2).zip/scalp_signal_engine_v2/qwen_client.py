"""
Qwen Client — Interface to local Qwen3 4B model via Ollama.
Sends compact feature strings, gets JSON with action + calibrated probabilities.
"""
import logging
import time
from typing import Optional

import aiohttp
import orjson

import config

logger = logging.getLogger("qwen")


class QwenClient:
    """Async client for local Ollama model."""

    def __init__(self):
        self._session: Optional[aiohttp.ClientSession] = None
        self._call_count = 0
        self._total_latency_ms = 0.0
        self._errors = 0

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=config.OLLAMA_TIMEOUT)
            )
        return self._session

    async def close(self):
        if self._session and not self._session.closed:
            await self._session.close()

    async def warmup(self) -> bool:
        """Send a dummy request to load model into memory."""
        logger.info(f"Warming up model '{config.OLLAMA_MODEL}'...")
        try:
            result = await self.ask("warmup test")
            if result:
                logger.info("Model warmed up successfully")
                return True
        except Exception as e:
            logger.error(f"Warmup failed: {e}")
        return False

    async def ask(self, feature_str: str) -> Optional[dict]:
        """
        Send feature string to Qwen, get JSON decision.
        Expected output:
        {"a":"BUY","c":0.87,"r":0.18,"p5":0.74,"p10":0.68,"p20":0.52}
        """
        body = {
            "model": config.OLLAMA_MODEL,
            "prompt": feature_str,
            "stream": False,
            "think": False,
            "format": "json",
            "options": {
                "temperature": config.OLLAMA_TEMPERATURE,
                "top_k": config.OLLAMA_TOP_K,
                "num_predict": config.OLLAMA_NUM_PREDICT,
            },
        }

        start = time.time()
        try:
            session = await self._get_session()
            url = f"{config.OLLAMA_BASE_URL}/api/generate"
            async with session.post(url, json=body) as resp:
                if resp.status != 200:
                    text = await resp.text()
                    logger.error(f"Ollama error {resp.status}: {text[:200]}")
                    self._errors += 1
                    return None
                data = await resp.read()
                result = orjson.loads(data)
        except aiohttp.ClientError as e:
            logger.error(f"Ollama connection error: {e}")
            self._errors += 1
            return None
        except Exception as e:
            logger.error(f"Ollama request error: {e}")
            self._errors += 1
            return None

        elapsed_ms = (time.time() - start) * 1000
        self._call_count += 1
        self._total_latency_ms += elapsed_ms

        # Parse the response field
        response_text = result.get("response", "")
        if not response_text:
            logger.warning("Empty response from model")
            return None

        try:
            decision = orjson.loads(response_text.encode())
        except Exception:
            logger.warning(f"Failed to parse model response: {response_text[:100]}")
            return None

        if not isinstance(decision, dict):
            return None

        # Validate and extract fields
        action = decision.get("a", "SKIP")
        if action not in ("BUY", "SELL", "WAIT", "SKIP"):
            action = "SKIP"

        # Clamp probabilities to [0, 1]
        def clamp(v, lo=0.0, hi=1.0):
            try:
                return max(lo, min(hi, float(v)))
            except (TypeError, ValueError):
                return 0.0

        return {
            "a": action,
            "c": clamp(decision.get("c", 0.0)),
            "r": clamp(decision.get("r", 0.0)),
            "p5": clamp(decision.get("p5", 0.0)),
            "p10": clamp(decision.get("p10", 0.0)),
            "p20": clamp(decision.get("p20", 0.0)),
            "latency_ms": elapsed_ms,
        }

    @property
    def stats(self) -> dict:
        avg_ms = self._total_latency_ms / max(self._call_count, 1)
        return {
            "calls": self._call_count,
            "errors": self._errors,
            "avg_latency_ms": round(avg_ms, 1),
            "total_latency_ms": round(self._total_latency_ms, 1),
        }
