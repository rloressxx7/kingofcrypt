# Exit Engine Fix Summary

## Problem Identified
Positions were opening but never closing because:
1. **Exit engine only triggered on new events** — if a mint went quiet (no new trades), the position stayed open forever
2. **Exit threshold too high** — required 0.40 score (multiple negative signals)
3. **No time-based safety net** — positions could stay open indefinitely

## Changes Made

### 1. Periodic Exit Check (`live_mode.py`)
- Added `_periodic_exit_check()` task that runs every 2 seconds
- Evaluates ALL open positions regardless of whether new events arrive
- Logs detailed exit evaluation for debugging

```python
async def _periodic_exit_check(self):
    while self._running:
        await asyncio.sleep(2)  # Check every 2 seconds
        for mint, pos in open_pos.items():
            features = self.feature_engine.get_features(mint)
            action = await self.pos_manager._check_exit(mint, features, pos)
```

### 2. Lowered Exit Threshold (`exit_engine.py`)
- Changed SELL threshold: **0.40 → 0.30**
- Changed WAIT threshold: **0.20 → 0.15**
- Makes exits more aggressive for scalping

### 3. Time-Based Safety Exit (`exit_engine.py`)
- Added condition: if position open >30s with PnL < -5%, add +0.25 to exit score
- Prevents holding losing positions too long

### 4. Scalping Timeout (`exit_engine.py`)
- After 60 seconds: add +0.20 to exit score
- After 120 seconds (EXIT_MAX_HOLD_SECONDS): add +0.35 (nearly guarantee exit)
- Enforces short holding periods for scalping strategy

### 5. Enhanced Logging (`live_mode.py`)
- Logs every periodic check with: hold time, PnL%, MFE%, MAE%, event count, price
- Logs exit evaluation: action, score, reasons
- Helps debug why positions aren't closing

## Expected Behavior Now

**Test scenario:**
1. Position opens at 20:49:54
2. No new events arrive for that mint
3. At 20:49:56 (2s later): periodic check evaluates position
4. At 20:50:24 (30s): time-based safety exit adds pressure if PnL < -5%
5. At 20:50:54 (60s): scalp timeout adds +0.20 pressure
6. At 20:51:54 (120s): max hold time adds +0.35 (nearly guaranteed exit)

**Exit score examples:**
- Sell pressure (0.20) + momentum reversal (0.12) = 0.32 → **SELL** (was HOLD at 0.40 threshold)
- Volume decay (0.15) + liquidity drop (0.15) = 0.30 → **SELL** (was HOLD)
- Scalp timeout (0.20) + any signal (0.10+) = 0.30+ → **SELL**

## Testing

Run the engine again:
```bash
set LIVE_TRADING=false
python main.py live
```

Watch for these log lines:
- `⏰ PERIODIC CHECK: TL6z.. hold=30s pnl=-2.5%` — periodic check running
- `EXIT_EVAL: TL6z.. action=SELL score=0.32 reasons=[...]` — exit evaluation
- `🚪 PERIODIC EXIT: TL6z.. triggered` — exit executed

Positions should now close within 60-120 seconds even if no events arrive.
