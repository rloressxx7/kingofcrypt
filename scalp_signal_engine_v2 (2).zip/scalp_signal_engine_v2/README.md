# 🎯 Scalp Signal Engine — Production

Pump.fun tokenlerini 15K–20K MC bölgesinde gerçek zamanlı tarayan, dinamik giriş/çıkış yapan ve mainnet Solana execution destekleyen production-grade trading sistemi.

## Pipeline

```
PumpAPI WebSocket
    ↓
Mint Recorder (lifecycle tracking)
    ↓
Feature Engine (30+ features, sliding windows)
    ↓
Deterministic Candidate Filter (12-stage, fast)
    ↓
Qwen3 4B (local-jev, Ollama — only for candidates)
    ↓
Probability Calibrator (isotonic/bucket calibration)
    ↓
Expected Value Calculator
    ↓
Risk Manager (limits, kill switch, cooldown)
    ↓
REAL BUY (Solana mainnet via PumpAPI Trade API)
    ↓
Blockchain Confirmation (wait + verify)
    ↓
Position Manager (FLAT→PENDING→OPEN→EXIT→CLOSED)
    ↓
Dynamic Exit Engine (10+ signals, MFE/MAE, emergency)
    ↓
REAL SELL (confirmed execution)
    ↓
Realized NET PnL (actual execution data)
    ↓
Signal Analyzer + Calibration Update
```

## Dosya Yapısı (21 dosya, ~5300 satır)

| Dosya | Açıklama |
|-------|----------|
| `config.py` | Tüm ayarlar, risk limitleri, env var okuma |
| `stream.py` | PumpAPI WS (reconnect, dedup, stale detection) |
| `mint_recorder.py` | Mint lifecycle kaydı |
| `feature_engine.py` | 35+ feature (safety: mayhem, migration, authorities) |
| `entry_engine.py` | 12-stage filter + Qwen + calibration + EV |
| `exit_engine.py` | 11 sinyal, MFE/MAE, momentum override |
| `qwen_client.py` | Ollama client (p5/p10/p20 output) |
| `position_manager.py` | State machine + MAE/MFE + emergency exit |
| `pnl_simulator.py` | Gerçekçi NET PnL (all costs) |
| `execution_interface.py` | BacktestExecutor + BaseExecutor interface |
| `real_executor.py` | Solana mainnet execution (PumpAPI Trade API) |
| `risk_manager.py` | Limits, kill switch, cooldown, emergency mode |
| `balance_reconciler.py` | Internal vs blockchain state comparison |
| `probability_calibrator.py` | Isotonic/bucket calibration for p5/p10/p20 |
| `backtest.py` | Replay, train/val/test, walk-forward |
| `signal_analyzer.py` | Feature importance + combination analysis |
| `live_mode.py` | Production trading engine |
| `dashboard.py` | HTML report generator |
| `latency.py` | Pipeline stage latency tracking |
| `main.py` | CLI (11 commands) |
| `test_engine.py` | Smoke tests (6 tests) |

## Komutlar

```bash
# Paper trading (default)
python main.py live

# Paper trading (explicit)
python main.py live --paper

# Live mainnet (LIVE_TRADING=true env var gerekli)
export LIVE_TRADING=true
export SOLANA_KEYPAIR_PATH=/path/to/keypair.json
python main.py live

# Backtest
python main.py backtest
python main.py backtest data/mints/MINT.json

# Analyze signals
python main.py analyze

# Status
python main.py status

# Positions
python main.py positions

# PnL
python main.py pnl

# Kill switch
python main.py kill
python main.py resume

# Calibrate
python main.py calibrate

# Debug stream
python main.py stream --max-events 100

# Record mint
python main.py record MINT_ADDRESS
```

## Risk Kontrolleri

| Limit | Varsayılan | Env Var |
|-------|-----------|---------|
| Max Position | 0.5 SOL | `MAX_POSITION_SOL` |
| Max Daily Loss | 1.0 SOL | `MAX_DAILY_LOSS_SOL` |
| Max Exposure | 2.0 SOL | `MAX_TOTAL_EXPOSURE_SOL` |
| Max Open Positions | 3 | `MAX_OPEN_POSITIONS` |
| Max Trade Loss | 0.2 SOL | `MAX_TRADE_LOSS_SOL` |
| Max Slippage | 5% | `MAX_SLIPPAGE_PCT` |
| Max Price Impact | 3% | `MAX_PRICE_IMPACT_PCT` |
| Max Consecutive Losses | 5 | `MAX_CONSECUTIVE_LOSSES` |
| Cooldown After Loss | 60s | `COOLDOWN_AFTER_LOSS_SEC` |
| Min SOL Balance | 0.05 | `MIN_SOL_BALANCE` |

## Execution Güvenlik

- Private key ASLA source code'da değil (env var / keypair file)
- Duplicate transaction engelleme
- Confirmation bekleme (30s timeout)
- Failed tx → position açılmaz
- Partial fill detection
- Balance reconciliation (60s interval)
- Kill switch (file-based, instant)
- Emergency mode (3 anomaly → auto-pause)

## Qwen Output Format

```json
{"a":"BUY","c":0.87,"r":0.18,"p5":0.74,"p10":0.68,"p20":0.52}
```

- `c` = confidence (NOT win probability)
- `p5/p10/p20` = historical calibrated probabilities
- Calibrated values only reported with sufficient data

## Bilinen Riskler

1. PumpAPI Trade API bağlantı kesintisi → tx gönderilemez
2. RPC rate limiting → confirmation timeout
3. Model hallucination → calibration ile azaltılır
4. Flash crash → emergency exit ile korunur
5. MEV/front-running → Jito bundle (opsiyonel)
