"""
Exit Engine — Dynamic exit with MFE/MAE awareness and emergency detection.
"""
import logging
import time
from dataclasses import dataclass
from typing import Optional

import config
from feature_engine import MintFeatures

logger = logging.getLogger("exit")


@dataclass
class ExitSignal:
    mint: str
    action: str          # SELL, HOLD, WAIT
    score: float         # urgency to exit (0-1)
    reasons: list
    unrealized_pnl: float = 0.0
    unrealized_roi: float = 0.0
    is_emergency: bool = False


class ExitEngine:
    """Dynamic exit evaluation for open positions."""

    def __init__(self):
        self._peak_pnl: dict[str, float] = {}
        self._signal_count = 0

    def evaluate(self, f: MintFeatures, entry_price: float,
                 entry_liquidity: float, hold_time: float,
                 current_pnl_pct: float,
                 mfe: float = 0.0, mae: float = 0.0) -> ExitSignal:
        """Evaluate whether to exit a position."""
        reasons = []
        exit_score = 0.0
        mint = f.mint

        # Track peak PnL for trailing stop
        if mint not in self._peak_pnl:
            self._peak_pnl[mint] = current_pnl_pct
        else:
            self._peak_pnl[mint] = max(self._peak_pnl[mint], current_pnl_pct)
        peak = self._peak_pnl[mint]

        # ── 1. Sell pressure reversal ─────────────────────────────────
        if f.buy_sell_ratio > 0 and f.buy_sell_ratio < 1.0 / config.EXIT_SELL_PRESSURE_RATIO:
            exit_score += 0.20
            reasons.append(f"sell_pressure BSR={f.buy_sell_ratio:.2f}")

        # ── 2. Volume decay ───────────────────────────────────────────
        if f.volume_acceleration < -config.EXIT_VOLUME_DECAY_THRESHOLD:
            exit_score += 0.15
            reasons.append(f"vol_decay VA={f.volume_acceleration:.2f}")

        # ── 3. Consecutive sells ──────────────────────────────────────
        if f.consecutive_sells >= config.EXIT_CONSECUTIVE_SELLS:
            exit_score += 0.15
            reasons.append(f"consec_sells={f.consecutive_sells}")

        # ── 4. Momentum reversal ──────────────────────────────────────
        if f.price_change_5s < config.EXIT_MOMENTUM_REVERSAL:
            exit_score += 0.12
            reasons.append(f"mom_reversal pc5={f.price_change_5s:.4f}")

        # ── 5. Liquidity deterioration ────────────────────────────────
        if f.liquidity_change < -config.EXIT_LIQUIDITY_DROP_PCT:
            exit_score += 0.15
            reasons.append(f"liq_drop={f.liquidity_change:.2%}")

        # ── 6. Whale selling ──────────────────────────────────────────
        if f.whale_activity > 0.3 and f.sell_volume > f.buy_volume:
            exit_score += 0.10
            reasons.append(f"whale_selling wh={f.whale_activity:.2f}")

        # ── 7. Buyer exhaustion ───────────────────────────────────────
        if f.new_buyer_velocity < 0.1 and f.unique_buyers < 2:
            exit_score += 0.08
            reasons.append(f"buyer_exhaustion nbv={f.new_buyer_velocity:.2f}")

        # ── 8. Trailing stop from peak ────────────────────────────────
        if peak > 0.05:
            drawdown_from_peak = peak - current_pnl_pct
            if drawdown_from_peak > config.EXIT_TRAILING_PCT:
                exit_score += 0.20
                reasons.append(f"trailing peak={peak:.2%} now={current_pnl_pct:.2%}")

        # ── 9. Max hold time ──────────────────────────────────────────
        if hold_time > config.EXIT_MAX_HOLD_SECONDS:
            exit_score += 0.35  # Nearly guarantee exit
            reasons.append(f"max_hold={hold_time:.0f}s")
        elif hold_time > 60.0:
            # Scalping: after 60s, add significant pressure to exit
            exit_score += 0.20
            reasons.append(f"scalp_timeout={hold_time:.0f}s")

        # ── 10. MFE/MAE-based exit ───────────────────────────────────
        # If MFE was high but we've given back most gains
        if mfe > 0.15 and current_pnl_pct < mfe * 0.3:
            exit_score += 0.15
            reasons.append(f"mfe_giveback MFE={mfe:.2%} now={current_pnl_pct:.2%}")

        # If MAE is severe and we've recovered somewhat — lock in
        if mae < -0.10 and current_pnl_pct > 0:
            exit_score += 0.08
            reasons.append(f"mae_recovery MAE={mae:.2%} now={current_pnl_pct:.2%}")

        # ── 11. Slippage check ────────────────────────────────────────
        if f.estimated_slippage > 0.05 and current_pnl_pct < 0.03:
            reasons.append(f"slip_high slip={f.estimated_slippage:.3f}")

        # ── 12. Time-based safety exit ────────────────────────────────
        # If position is open >30s with negative PnL, exit immediately
        if hold_time > 30.0 and current_pnl_pct < -0.05:
            exit_score += 0.25
            reasons.append(f"time_loss hold={hold_time:.0f}s pnl={current_pnl_pct:.2%}")

        # ── Decision ──────────────────────────────────────────────────
        if exit_score >= 0.30:
            action = "SELL"
        elif exit_score >= 0.15:
            action = "WAIT"
        else:
            action = "HOLD"

        # Strong momentum override
        if (f.price_change_5s > 0.05 and
            f.buy_sell_ratio > 2.0 and
            f.volume_acceleration > 0.5 and
            current_pnl_pct > 0):
            action = "HOLD"
            reasons.append("strong_momentum")

        signal = ExitSignal(
            mint=mint,
            action=action,
            score=exit_score,
            reasons=reasons,
            unrealized_pnl=current_pnl_pct,
            unrealized_roi=current_pnl_pct,
        )

        self._signal_count += 1
        return signal

    def cleanup(self, mint: str):
        self._peak_pnl.pop(mint, None)

    @property
    def stats(self) -> dict:
        return {"exit_signals_evaluated": self._signal_count}
