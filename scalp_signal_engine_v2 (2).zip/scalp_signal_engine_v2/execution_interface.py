"""
Execution Interface — Unified interface for backtest and real execution.
Both BacktestExecutor and RealExecutor implement this interface so
strategy code remains identical.
"""
import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

logger = logging.getLogger("executor")


class ExecutionMode(str, Enum):
    BACKTEST = "backtest"
    PAPER = "paper"
    LIVE = "live"


@dataclass
class ExecutionResult:
    """Result of a buy or sell execution."""
    success: bool = False
    signature: str = ""            # transaction signature
    mint: str = ""
    action: str = ""               # "buy" or "sell"
    sol_amount: float = 0.0        # actual SOL spent/received
    token_amount: float = 0.0      # actual tokens received/sold
    price: float = 0.0             # actual execution price
    expected_token_amount: float = 0.0  # what we expected to get
    slippage_actual: float = 0.0   # actual slippage vs expected
    priority_fee_paid: float = 0.0
    jito_tip_paid: float = 0.0
    pump_fee_paid: float = 0.0
    ata_created: bool = False      # was ATA created in this tx?
    ata_rent_paid: float = 0.0
    ata_closed: bool = False       # was ATA closed (refund)?
    ata_refund: float = 0.0
    base_tx_fee: float = 0.0
    failed: bool = False
    error: str = ""
    confirmed: bool = False        # blockchain confirmed?
    block: int = 0
    timestamp: float = 0.0
    latency_ms: float = 0.0        # total execution latency

    @property
    def total_cost(self) -> float:
        """Total costs paid for this execution."""
        return (self.priority_fee_paid + self.jito_tip_paid +
                self.pump_fee_paid + self.ata_rent_paid +
                self.base_tx_fee)

    def to_dict(self) -> dict:
        return {k: v for k, v in self.__dict__.items()}


class BaseExecutor(ABC):
    """Abstract execution interface."""

    def __init__(self, mode: ExecutionMode):
        self.mode = mode
        self._executions: list[ExecutionResult] = []

    @abstractmethod
    async def buy(self, mint: str, sol_amount: float,
                  max_slippage_pct: float, price: float,
                  liquidity: float) -> ExecutionResult:
        """Execute a buy. Returns execution result."""
        pass

    @abstractmethod
    async def sell(self, mint: str, token_amount: float,
                   max_slippage_pct: float, price: float,
                   liquidity: float) -> ExecutionResult:
        """Execute a sell. Returns execution result."""
        pass

    @abstractmethod
    async def get_sol_balance(self) -> float:
        """Get current SOL balance."""
        pass

    @abstractmethod
    async def get_token_balance(self, mint: str) -> float:
        """Get current token balance for a mint."""
        pass

    @abstractmethod
    async def has_ata(self, mint: str) -> bool:
        """Check if ATA exists for this mint."""
        pass

    @abstractmethod
    async def check_tx_status(self, signature: str) -> dict:
        """Check transaction confirmation status."""
        pass

    @abstractmethod
    async def get_wallet_address(self) -> str:
        """Get wallet public key."""
        pass

    def record_execution(self, result: ExecutionResult):
        self._executions.append(result)

    def get_executions(self) -> list[ExecutionResult]:
        return self._executions

    async def close(self):
        """Cleanup resources."""
        pass


class BacktestExecutor(BaseExecutor):
    """Simulated execution for backtesting. Uses same interface as real."""

    def __init__(self):
        super().__init__(ExecutionMode.BACKTEST)
        self._balances_sol = 100.0  # starting SOL
        self._balances_tokens: dict[str, float] = {}
        self._ata_exists: dict[str, bool] = {}

    async def buy(self, mint: str, sol_amount: float,
                  max_slippage_pct: float, price: float,
                  liquidity: float) -> ExecutionResult:
        import time
        import config

        result = ExecutionResult(mint=mint, action="buy")

        # Check balance
        if self._balances_sol < sol_amount:
            result.success = False
            result.failed = True
            result.error = "Insufficient SOL balance"
            return result

        # Simulate slippage
        if liquidity > 0:
            slippage = min(sol_amount / (liquidity * 2), max_slippage_pct)
        else:
            slippage = config.ESTIMATED_SLIPPAGE_PCT

        effective_price = price * (1 + slippage)
        tokens = sol_amount / effective_price if effective_price > 0 else 0

        # Costs
        pump_fee = sol_amount * config.PUMP_FEE_RATE
        ata_needed = not self._ata_exists.get(mint, False)
        ata_cost = config.ATA_RENT_SOL if ata_needed else 0.0

        total_cost = sol_amount + pump_fee + config.PRIORITY_FEE_SOL + config.BASE_TX_FEE_SOL + ata_cost

        if self._balances_sol < total_cost:
            result.success = False
            result.failed = True
            result.error = "Insufficient SOL for trade + fees"
            return result

        # Execute
        self._balances_sol -= total_cost
        self._balances_tokens[mint] = self._balances_tokens.get(mint, 0) + tokens
        if ata_needed:
            self._ata_exists[mint] = True

        result.success = True
        result.confirmed = True
        result.sol_amount = sol_amount
        result.token_amount = tokens
        result.expected_token_amount = sol_amount / price if price > 0 else 0
        result.slippage_actual = slippage
        result.price = effective_price
        result.pump_fee_paid = pump_fee
        result.priority_fee_paid = config.PRIORITY_FEE_SOL
        result.base_tx_fee = config.BASE_TX_FEE_SOL
        result.ata_created = ata_needed
        result.ata_rent_paid = ata_cost
        result.timestamp = time.time()
        result.signature = f"bt_sim_{len(self._executions):06d}"

        self.record_execution(result)
        return result

    async def sell(self, mint: str, token_amount: float,
                   max_slippage_pct: float, price: float,
                   liquidity: float) -> ExecutionResult:
        import time
        import config

        result = ExecutionResult(mint=mint, action="sell")

        balance = self._balances_tokens.get(mint, 0)
        if balance < token_amount:
            token_amount = balance  # sell what we have
        if token_amount <= 0:
            result.success = False
            result.failed = True
            result.error = "No tokens to sell"
            return result

        # Slippage
        est_value = token_amount * price
        if liquidity > 0:
            slippage = min(est_value / (liquidity * 2), max_slippage_pct)
        else:
            slippage = config.ESTIMATED_SLIPPAGE_PCT

        effective_price = price * (1 - slippage)
        sol_received = token_amount * effective_price

        pump_fee = sol_received * config.PUMP_FEE_RATE
        sol_after_fee = sol_received - pump_fee - config.PRIORITY_FEE_SOL - config.BASE_TX_FEE_SOL

        # ATA close refund (if selling all tokens)
        remaining = balance - token_amount
        ata_close = remaining <= 0 and self._ata_exists.get(mint, False)
        ata_refund = config.ATA_RENT_SOL if ata_close else 0.0

        self._balances_sol += sol_after_fee + ata_refund
        self._balances_tokens[mint] = max(remaining, 0)
        if ata_close:
            self._ata_exists[mint] = False

        result.success = True
        result.confirmed = True
        result.sol_amount = sol_received
        result.token_amount = token_amount
        result.expected_token_amount = token_amount
        result.slippage_actual = slippage
        result.price = effective_price
        result.pump_fee_paid = pump_fee
        result.priority_fee_paid = config.PRIORITY_FEE_SOL
        result.base_tx_fee = config.BASE_TX_FEE_SOL
        result.ata_closed = ata_close
        result.ata_refund = ata_refund
        result.timestamp = time.time()
        result.signature = f"bt_sim_{len(self._executions):06d}"

        self.record_execution(result)
        return result

    async def get_sol_balance(self) -> float:
        return self._balances_sol

    async def get_token_balance(self, mint: str) -> float:
        return self._balances_tokens.get(mint, 0)

    async def has_ata(self, mint: str) -> bool:
        return self._ata_exists.get(mint, False)

    async def check_tx_status(self, signature: str) -> dict:
        return {"confirmed": True, "slot": 0, "err": None}

    async def get_wallet_address(self) -> str:
        return "BacktestWallet"
